<?php

namespace App\Http\Controllers;

use App\Actions\CreateScheduledSmsAction;
use App\Http\Requests\StoreScheduledSmsRequest;
use App\Http\Resources\ScheduledSmsResource;
use App\Jobs\ProcessScheduledSmsJob;
use App\Models\ScheduledSms;
use App\Services\ActivityLogService;
use App\Services\IletibilgiService;
use Carbon\Carbon;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class ScheduledSmsController extends ApiController
{
    protected ActivityLogService $activityLogService;

    public function __construct(ActivityLogService $activityLogService)
    {
        $this->activityLogService = $activityLogService;
    }

    /**
     * Get SMS settings from database for current tenant
     */
    public function getSettings(): JsonResponse
    {
        $tenantId = auth()->user()?->tenant_id;
        $settings = [];
        if ($tenantId) {
            $settings = DB::table('settings')
                ->where('tenant_id', $tenantId)
                ->where('group', 'sms')
                ->pluck('value', 'key')
                ->toArray();
        }

        if (empty($settings['iletibilgi_username']) || empty($settings['iletibilgi_password'])) {
            $fallbackSettings = DB::table('settings')
                ->whereIn('key', ['iletibilgi_username', 'iletibilgi_password', 'iletibilgi_sender', 'iletibilgi_base_url', 'iletibilgi_enabled'])
                ->whereNotNull('value')
                ->where('value', '!=', '')
                ->pluck('value', 'key')
                ->toArray();
            $settings = array_merge($fallbackSettings, array_filter($settings));
        }

        $username = $settings['iletibilgi_username'] ?? '';
        $password = $settings['iletibilgi_password'] ?? '';
        $baseUrl  = $settings['iletibilgi_base_url'] ?? 'https://panel.iletibilgi.com.tr:9588';

        $credit = null;
        $usedCredit = 0;
        $originators = [];

        if ($tenantId) {
            $usedCredit = \App\Models\SmsReport::where('tenant_id', $tenantId)->where('status', 'sent')->count();
        } else {
            $usedCredit = \App\Models\SmsReport::where('status', 'sent')->count();
        }

        if (!empty($username) && !empty($password)) {
            try {
                $service = new IletibilgiService($username, $password, '', $baseUrl);
                $info = $service->getUserInfo();
                if (!empty($info['success']) && isset($info['data'])) {
                    $credit = $info['data']['credit'] ?? null;
                    $originators = $info['data']['originators'] ?? [];
                }
            } catch (\Exception $e) {}
        }

        return $this->success([
            'username'    => $username,
            'password'    => $password,
            'base_url'    => $baseUrl,
            'sender'      => $settings['iletibilgi_sender'] ?? 'AK IRFAN',
            'enabled'     => ($settings['iletibilgi_enabled'] ?? '0') === '1' || ($settings['iletibilgi_enabled'] ?? 'false') === 'true',
            'credit'      => $credit,
            'balance'     => $credit,
            'usedCredit'  => $usedCredit,
            'originators' => $originators,
        ], 'SMS ayarları getirildi.');
    }

    /**
     * Save SMS settings to database for current tenant
     */
    public function saveSettings(Request $request): JsonResponse
    {
        $tenantId = auth()->user()?->tenant_id;
        $validated = $request->validate([
            'username' => 'required|string',
            'password' => 'required|string',
            'base_url' => 'nullable|string',
            'sender' => 'required|string',
            'enabled' => 'nullable',
        ]);

        if ($tenantId) {
            $enabledVal = !empty($validated['enabled']) && ($validated['enabled'] === true || $validated['enabled'] === 'true' || $validated['enabled'] === 1 || $validated['enabled'] === '1') ? '1' : '0';
            $keys = [
                'iletibilgi_username' => trim($validated['username']),
                'iletibilgi_password' => trim($validated['password']),
                'iletibilgi_base_url' => rtrim($validated['base_url'] ?? 'https://panel.iletibilgi.com.tr:9588', '/'),
                'iletibilgi_sender' => trim($validated['sender']),
                'iletibilgi_enabled' => $enabledVal,
                'sms_driver' => 'iletibilgi',
            ];

            foreach ($keys as $key => $val) {
                DB::table('settings')->updateOrInsert(
                    ['tenant_id' => $tenantId, 'key' => $key],
                    ['value' => $val, 'group' => 'sms', 'updated_at' => now(), 'created_at' => now()]
                );
            }
        }

        return $this->success(null, 'SMS API Ayarları başarıyla veritabanına kaydedildi.');
    }

    /**
     * Get user account / credit / remaining SMS info from Iletibilgi API
     */
    public function userInfo(Request $request): JsonResponse
    {
        $tenantId = auth()->user()?->tenant_id;
        $settings = [];
        if ($tenantId) {
            $settings = DB::table('settings')
                ->where('tenant_id', $tenantId)
                ->where('group', 'sms')
                ->pluck('value', 'key')
                ->toArray();
        }

        if (empty($settings['iletibilgi_username']) || empty($settings['iletibilgi_password'])) {
            $fallbackSettings = DB::table('settings')
                ->whereIn('key', ['iletibilgi_username', 'iletibilgi_password', 'iletibilgi_sender', 'iletibilgi_base_url', 'iletibilgi_enabled'])
                ->whereNotNull('value')
                ->where('value', '!=', '')
                ->pluck('value', 'key')
                ->toArray();
            $settings = array_merge($fallbackSettings, array_filter($settings));
        }

        $username = trim($request->input('username') ?: ($settings['iletibilgi_username'] ?? ''));
        $password = trim($request->input('password') ?: ($settings['iletibilgi_password'] ?? ''));
        $baseUrl = trim($request->input('base_url') ?: ($settings['iletibilgi_base_url'] ?? 'https://panel.iletibilgi.com.tr:9588'));

        if (empty($username) || empty($password)) {
            return $this->error('Lütfen önce API kullanıcı adı ve şifre alanlarını girin veya kaydedin.', [], 422);
        }

        $service = new IletibilgiService($username, $password, '', $baseUrl);
        $result = $service->getUserInfo();

        $systemUsedSms = 0;
        if ($tenantId) {
            $systemUsedSms = \App\Models\SmsReport::where('tenant_id', $tenantId)->where('status', 'sent')->count();
        } else {
            $systemUsedSms = \App\Models\SmsReport::where('status', 'sent')->count();
        }

        if ($result['success']) {
            $data = $result['data'];
            $data['usedCredit'] = $systemUsedSms;
            return $this->success($data, 'Kullanıcı ve bakiye bilgileri başarıyla alındı.');
        }

        return $this->error($result['message'] ?? 'Kullanıcı bilgileri alınamadı.', [
            'usedCredit' => $systemUsedSms,
            'details' => $result,
        ], 400);
    }

    /**
     * Test SMS connection (Proxy to bypass browser CORS)
     */
    public function testConnection(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'username' => 'required|string',
            'password' => 'required|string',
            'base_url' => 'nullable|string',
            'sender' => 'required|string',
            'phone' => 'required|string',
            'message' => 'required|string',
        ]);

        $baseUrl = rtrim($validated['base_url'] ?? 'https://panel.iletibilgi.com.tr:9588', '/');
        $username = trim($validated['username']);
        $password = trim($validated['password']);
        $sender = trim($validated['sender']);
        $phone = trim($validated['phone']);
        $message = trim($validated['message']);

        try {
            $response = Http::withBasicAuth($username, $password)
                ->timeout(15)
                ->post("{$baseUrl}/sms/create", [
                    'type' => 1,
                    'sendingType' => 0,
                    'title' => 'EDULEM TEST',
                    'number' => $phone,
                    'sender' => $sender,
                    'content' => $message,
                    'encoding' => 1,
                ]);

            $status = $response->status();
            $data = $response->json();

            if ($response->successful()) {
                $pkgId = data_get($data, 'data.pkgID');
                if ($pkgId) {
                    // Record in ScheduledSms and SmsReport tables so it appears in SMS History
                    $tenantId = auth()->user()?->tenant_id;
                    $userId = auth()->id();

                    $scheduled = ScheduledSms::create([
                        'tenant_id' => $tenantId,
                        'title' => 'Test SMS (' . $phone . ')',
                        'message' => $message,
                        'recipient_phones' => [$phone],
                        'recipient_type' => 'test',
                        'recipient_ids' => [],
                        'scheduled_at' => now(),
                        'sent_at' => now(),
                        'status' => 'completed',
                        'sent_count' => 1,
                        'failed_count' => 0,
                        'created_by' => $userId,
                    ]);

                    \App\Models\SmsReport::create([
                        'tenant_id' => $tenantId,
                        'phone' => $phone,
                        'message' => $message,
                        'status' => 'sent',
                        'message_id' => (string) $pkgId,
                        'sent_at' => now(),
                        'sender_type' => 'test_sms',
                        'sender_id' => $scheduled->id,
                        'created_by' => $userId,
                    ]);

                    return $this->success([
                        'pkgID' => $pkgId,
                        'data' => $data,
                    ], "SMS başarıyla gönderildi! Paket ID: {$pkgId} — Alıcı: {$phone}");
                }

                if (isset($data['err'])) {
                    $errCode = data_get($data, 'err.code', '');
                    $errMsg = $errCode === 'ERR_INVALID_SMS_SENDER'
                        ? "Gönderen Başlığı (\"{$sender}\") İleti Bilgi panelinizde tanımlı/onaylı değil. Lütfen İleti Bilgi hesabınızdaki onaylı başlık adını yazın."
                        : (data_get($data, 'err.message') ?: $errCode ?: 'Bilinmeyen hata');

                    return $this->error("API Hatası: {$errMsg}", $data, 422);
                }

                return $this->success($data, "İstek başarıyla iletildi.");
            }

            $errMsg = data_get($data, 'err.message') ?: $response->body() ?: 'Bağlantı hatası oluştu.';
            return $this->error("İleti Bilgi API Hatası (HTTP {$status}): {$errMsg}", $data ?? [], $status >= 400 && $status < 500 ? $status : 502);
        } catch (\Exception $e) {
            return $this->error("Bağlantı hatası: " . $e->getMessage(), [], 500);
        }
    }

    /**
     * Display a listing of scheduled SMS.
     */
    public function index(): JsonResponse
    {
        Gate::authorize('viewAny', ScheduledSms::class);

        // Cron gecikmesi durumunda fallback: SADECE zamanı gelmiş (scheduled_at <= now) ve bekleyen SMS'leri işle.
        // İleri tarihli planlanmış SMS'lere KESİNLİKLE dokunulmaz! (Türkiye saati Europe/Istanbul baz alınır)
        try {
            $tenantId = auth()->user()?->tenant_id;
            $nowTurkey = Carbon::now('Europe/Istanbul')->format('Y-m-d H:i:s');
            $dueQuery = ScheduledSms::whereIn('status', ['pending', 'processing'])
                ->where('scheduled_at', '<=', $nowTurkey);

            if ($tenantId) {
                $dueQuery->where('tenant_id', $tenantId);
            }

            $dueList = $dueQuery->get();
            foreach ($dueList as $due) {
                $this->dispatchSmsSynchronously($due);
            }
        } catch (\Exception $e) {
            Log::error('index() içinde zamanı gelen SMS işleme hatası', ['error' => $e->getMessage()]);
        }

        $query = ScheduledSms::with(['creator']);

        // Filtreleme
        if (request()->has('status')) {
            $query->where('status', request('status'));
        }

        if (request()->has('scheduled_from')) {
            $query->where('scheduled_at', '>=', request('scheduled_from'));
        }

        if (request()->has('scheduled_to')) {
            $query->where('scheduled_at', '<=', request('scheduled_to'));
        }

        $scheduledSms = $query->latest('id')->paginate(request('per_page', 50));

        // Hesaplamalar
        $stats = [
            'total' => ScheduledSms::count(),
            'pending' => ScheduledSms::where('status', 'pending')->count(),
            'processing' => ScheduledSms::where('status', 'processing')->count(),
            'completed' => ScheduledSms::where('status', 'completed')->count(),
            'failed' => ScheduledSms::where('status', 'failed')->count() + ScheduledSms::where('status', 'cancelled')->count(),
        ];

        return $this->success([
            'scheduled_sms' => ScheduledSmsResource::collection($scheduledSms),
            'statistics' => $stats,
            'pagination' => [
                'current_page' => $scheduledSms->currentPage(),
                'last_page' => $scheduledSms->lastPage(),
                'per_page' => $scheduledSms->perPage(),
                'total' => $scheduledSms->total(),
            ],
        ], 'Planlı SMS\'ler başarıyla listelendi.');
    }

    /**
     * Store a newly created scheduled SMS.
     */
    public function store(StoreScheduledSmsRequest $request, CreateScheduledSmsAction $createAction): JsonResponse
    {
        Gate::authorize('create', ScheduledSms::class);

        $scheduledSms = $createAction->execute($request->validated());
        $freshSms = $scheduledSms->fresh();

        // Eğer kullanıcı ileri bir tarih/saat seçtiyse:
        // SMS bekleyen (pending) durumda kalır, hemen gönderilmez! (Türkiye saati Europe/Istanbul baz alınır)
        $nowTurkey = Carbon::now('Europe/Istanbul');
        $rawScheduled = $freshSms->getAttributes()['scheduled_at'] ?? null;
        $scheduledTime = $rawScheduled ? Carbon::parse($rawScheduled, 'Europe/Istanbul') : null;
        $hasScheduledParam = !empty($request->validated()['scheduled_at']);
        $isFutureScheduled = $hasScheduledParam && $scheduledTime && $scheduledTime->gt($nowTurkey);

        if (!$isFutureScheduled) {
            try {
                $this->dispatchSmsSynchronously($freshSms);
            } catch (\Exception $e) {
                Log::error('store() anında SMS gönderim hatası', ['error' => $e->getMessage()]);
            }

            return $this->success(
                new ScheduledSmsResource($freshSms->fresh()),
                'SMS gönderim işlemi başarıyla başlatıldı.',
                201
            );
        }

        return $this->success(
            new ScheduledSmsResource($freshSms),
            'SMS gönderimi belirlenen tarih ve saat için başarıyla planlandı.',
            201
        );
    }

    /**
     * Tek bir ScheduledSms kaydını senkron olarak gönderir.
     */
    public function dispatchSmsSynchronously(ScheduledSms $scheduledSms): void
    {
        if (!in_array($scheduledSms->status, ['pending', 'processing'])) {
            return;
        }

        // Güvenlik kontrolü: Zamanı henüz gelmemiş ileri tarihli SMS'leri kesinlikle gönderme!
        $nowTurkey = Carbon::now('Europe/Istanbul');
        $rawScheduled = $scheduledSms->getAttributes()['scheduled_at'] ?? null;
        if (!empty($rawScheduled)) {
            $scheduledTime = Carbon::parse($rawScheduled, 'Europe/Istanbul');
            if ($scheduledTime->gt($nowTurkey)) {
                Log::info('dispatchSmsSynchronously atlandı: Zamanı henüz gelmedi', [
                    'id' => $scheduledSms->id,
                    'scheduled_at' => $scheduledTime->toDateTimeString(),
                    'now_turkey' => $nowTurkey->toDateTimeString(),
                ]);
                return;
            }
        }

        $scheduledSms->markAsProcessing();

        // Alıcı telefon numaralarını çöz
        $phones = $this->resolvePhones($scheduledSms);

        Log::info('dispatchSmsSynchronously: alıcılar', [
            'id' => $scheduledSms->id,
            'type' => $scheduledSms->recipient_type,
            'phones' => $phones,
        ]);

        if (empty($phones)) {
            $scheduledSms->markAsFailed('Alıcı telefon numarası bulunamadı.');
            return;
        }

        // SMS servisini oluştur
        $tenantId = $scheduledSms->tenant_id ?: auth()->user()?->tenant_id;
        $settings = [];
        if ($tenantId) {
            $settings = DB::table('settings')
                ->where('tenant_id', $tenantId)
                ->whereIn('key', ['iletibilgi_username', 'iletibilgi_password', 'iletibilgi_sender', 'iletibilgi_base_url'])
                ->pluck('value', 'key')
                ->toArray();
        }

        if (empty($settings['iletibilgi_username']) || empty($settings['iletibilgi_password'])) {
            $fallbackSettings = DB::table('settings')
                ->whereIn('key', ['iletibilgi_username', 'iletibilgi_password', 'iletibilgi_sender', 'iletibilgi_base_url'])
                ->whereNotNull('value')
                ->where('value', '!=', '')
                ->pluck('value', 'key')
                ->toArray();
            $settings = array_merge($fallbackSettings, array_filter($settings));
        }

        $username = $settings['iletibilgi_username'] ?? config('sms.iletibilgi.username') ?? config('sms.username', '');
        $password = $settings['iletibilgi_password'] ?? config('sms.iletibilgi.password') ?? config('sms.password', '');
        $sender   = $settings['iletibilgi_sender']   ?? config('sms.iletibilgi.sender')   ?? config('sms.sender', 'AK IRFAN');
        $baseUrl  = $settings['iletibilgi_base_url']  ?? config('sms.iletibilgi.base_url') ?? 'https://panel.iletibilgi.com.tr:9588';

        if (empty($username) || empty($password)) {
            $scheduledSms->markAsFailed('SMS API kullanıcı adı veya şifresi veritabanında bulunamadı. Lütfen SMS API Ayarları sayfasından bilgilerinizi kaydedin.');
            return;
        }

        $smsService = new IletibilgiService($username, $password, $sender, $baseUrl);
        $result     = $smsService->send($phones, $scheduledSms->message, $scheduledSms->title);

        $phoneList = is_array($phones) ? $phones : [$phones];
        foreach ($phoneList as $phone) {
            \App\Models\SmsReport::create([
                'tenant_id'     => $tenantId,
                'phone'         => $phone,
                'message'       => $scheduledSms->message,
                'status'        => $result['success'] ? 'sent' : 'failed',
                'message_id'    => $result['message_id'] ?? null,
                'error_code'    => $result['error_code'] ?? null,
                'error_message' => $result['success'] ? null : ($result['message'] ?? null),
                'sent_at'       => $result['success'] ? now() : null,
                'sender_type'   => 'scheduled_sms',
                'sender_id'     => $scheduledSms->id,
                'created_by'    => $scheduledSms->created_by,
            ]);
        }

        if ($result['success']) {
            $scheduledSms->markAsSent(count($phoneList), 0);
        } else {
            $scheduledSms->markAsFailed($result['message'] ?? 'SMS gönderilemedi.');
        }
    }

    /**
     * Alıcı telefon numaralarını tiplerine göre döndürür.
     */
    protected function resolvePhones(ScheduledSms $scheduledSms): array
    {
        $phones = [];

        if ($scheduledSms->recipient_type === 'phones') {
            $raw = $scheduledSms->recipient_phones ?? [];
            foreach ($raw as $phone) {
                $cleaned = preg_replace('/[^0-9]/', '', $phone);
                if (strlen($cleaned) === 10) $cleaned = '90' . $cleaned;
                elseif (strlen($cleaned) === 11 && str_starts_with($cleaned, '0')) $cleaned = '9' . $cleaned;
                if (strlen($cleaned) >= 10) $phones[] = $cleaned;
            }
            return array_values(array_unique($phones));
        }

        if ($scheduledSms->recipient_type === 'all') {
            $students = \App\Models\Student::where('tenant_id', $scheduledSms->tenant_id)->with('guardians')->get();
            foreach ($students as $s) {
                if (!empty($s->phone)) $phones[] = $s->phone;
                foreach ($s->guardians as $g) { if (!empty($g->phone)) $phones[] = $g->phone; }
            }
            return array_values(array_unique(array_filter($phones)));
        }

        if ($scheduledSms->recipient_type === 'classroom') {
            $ids = $scheduledSms->recipient_ids ?? [];
            $students = \App\Models\Student::where('tenant_id', $scheduledSms->tenant_id)->whereIn('classroom_id', $ids)->with('guardians')->get();
            foreach ($students as $s) {
                if (!empty($s->phone)) $phones[] = $s->phone;
                foreach ($s->guardians as $g) { if (!empty($g->phone)) $phones[] = $g->phone; }
            }
            return array_values(array_unique(array_filter($phones)));
        }

        if ($scheduledSms->recipient_type === 'students') {
            $ids = $scheduledSms->recipient_ids ?? [];
            $students = \App\Models\Student::where('tenant_id', $scheduledSms->tenant_id)->whereIn('id', $ids)->with('guardians')->get();
            foreach ($students as $s) {
                if (!empty($s->phone)) $phones[] = $s->phone;
                foreach ($s->guardians as $g) { if (!empty($g->phone)) $phones[] = $g->phone; }
            }
            return array_values(array_unique(array_filter($phones)));
        }

        if ($scheduledSms->recipient_type === 'users') {
            $ids = $scheduledSms->recipient_ids ?? [];
            return \App\Models\User::where('tenant_id', $scheduledSms->tenant_id)
                ->whereIn('id', $ids)->whereNotNull('phone')->pluck('phone')->unique()->values()->toArray();
        }

        return [];
    }

    /**
     * Display the specified scheduled SMS.
     */
    public function show(ScheduledSms $scheduledSms): JsonResponse
    {
        Gate::authorize('view', $scheduledSms);

        $scheduledSms->load(['creator']);

        return $this->success(new ScheduledSmsResource($scheduledSms));
    }

    /**
     * Cancel a scheduled SMS.
     */
    public function cancel(ScheduledSms $scheduledSms): JsonResponse
    {
        Gate::authorize('cancel', $scheduledSms);

        if ($scheduledSms->status !== 'pending') {
            return $this->error('Sadece bekleyen SMS\'ler iptal edilebilir.', [], 400);
        }

        $scheduledSms->update(['status' => 'cancelled']);
        $this->activityLogService->logUpdate($scheduledSms);

        return $this->success(new ScheduledSmsResource($scheduledSms), 'Planlı SMS başarıyla iptal edildi.');
    }

    /**
     * Remove the specified scheduled SMS.
     */
    public function destroy(ScheduledSms $scheduledSms): JsonResponse
    {
        Gate::authorize('delete', $scheduledSms);

        $this->activityLogService->logDelete($scheduledSms);

        // İlgili SMS rapor kayıtlarını da temizle
        \App\Models\SmsReport::where('tenant_id', $scheduledSms->tenant_id)
            ->where('sender_id', (string) $scheduledSms->id)
            ->delete();

        $scheduledSms->delete();

        return $this->success(null, 'Planlı SMS başarıyla silindi.');
    }
}
