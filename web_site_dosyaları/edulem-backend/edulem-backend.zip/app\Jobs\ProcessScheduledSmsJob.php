<?php

namespace App\Jobs;

use App\Models\ScheduledSms;
use App\Jobs\SendSmsJob;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;

class ProcessScheduledSmsJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * The number of times the job may be attempted.
     *
     * @var int
     */
    public $tries = 3;

    /**
     * The number of seconds to wait before retrying the job.
     *
     * @var int
     */
    public $backoff = 60;

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle(): void
    {
        try {
            // Gönderilmeye hazır planlı SMS'leri al
            $scheduledSmsList = ScheduledSms::where('status', 'pending')
                ->where('scheduled_at', '<=', now())
                ->get();

            foreach ($scheduledSmsList as $scheduledSms) {
                try {
                    $scheduledSms->markAsProcessing();

                    // Alıcı telefon numaralarını çöz
                    $phones = $this->resolveRecipients($scheduledSms);

                    if (empty($phones)) {
                        $scheduledSms->markAsFailed('Alıcı telefon numarası bulunamadı.');
                        continue;
                    }

                    // SMS gönder
                    $sentCount = 0;
                    $failedCount = 0;

                    foreach ($phones as $phone) {
                        try {
                            SendSmsJob::dispatch(
                                $phone, 
                                $scheduledSms->message, 
                                $scheduledSms->tenant_id,
                                'scheduled_sms',
                                $scheduledSms->id
                            );
                            $sentCount++;
                        } catch (\Exception $e) {
                            Log::error('Planlı SMS gönderim hatası', [
                                'scheduled_sms_id' => $scheduledSms->id,
                                'phone' => $phone,
                                'error' => $e->getMessage(),
                            ]);
                            $failedCount++;
                        }
                    }

                    // Toplu gönderim için bekleme (rate limiting)
                    if (count($phones) > 10) {
                        sleep(1); // 10 SMS'den fazla ise 1 saniye bekle
                    }

                    $scheduledSms->markAsSent($sentCount, $failedCount);

                    Log::info('Planlı SMS başarıyla gönderildi', [
                        'scheduled_sms_id' => $scheduledSms->id,
                        'sent_count' => $sentCount,
                        'failed_count' => $failedCount,
                    ]);

                } catch (\Exception $e) {
                    $scheduledSms->markAsFailed($e->getMessage());
                    Log::error('Planlı SMS işleme hatası', [
                        'scheduled_sms_id' => $scheduledSms->id,
                        'error' => $e->getMessage(),
                        'trace' => $e->getTraceAsString(),
                    ]);
                }
            }

        } catch (\Exception $e) {
            Log::error('ProcessScheduledSmsJob genel hatası', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);

            throw $e;
        }
    }

    /**
     * Resolve recipient phone numbers.
     *
     * @param  \App\Models\ScheduledSms  $scheduledSms
     * @return array
     */
    protected function resolveRecipients(ScheduledSms $scheduledSms): array
    {
        return match ($scheduledSms->recipient_type) {
            'phones' => $scheduledSms->recipient_phones ?? [],
            'students' => $this->getStudentPhones($scheduledSms),
            'guardians' => $this->getGuardianPhones($scheduledSms),
            'users' => $this->getUserPhones($scheduledSms),
            'classroom' => $this->getClassroomPhones($scheduledSms),
            'all' => $this->getAllPhones($scheduledSms),
            default => [],
        };
    }

    /**
     * Get student phone numbers.
     *
     * @param  \App\Models\ScheduledSms  $scheduledSms
     * @return array
     */
    protected function getStudentPhones(ScheduledSms $scheduledSms): array
    {
        $studentIds = $scheduledSms->recipient_ids ?? [];
        
        // Öğrencilerin velilerinin telefonlarını al
        $phones = [];
        $students = \App\Models\Student::where('tenant_id', $scheduledSms->tenant_id)
            ->whereIn('id', $studentIds)
            ->with('guardians')
            ->get();

        foreach ($students as $student) {
            foreach ($student->guardians as $guardian) {
                if ($guardian->phone) {
                    $phones[] = $guardian->phone;
                }
            }
        }

        return array_unique($phones);
    }

    /**
     * Get guardian phone numbers.
     *
     * @param  \App\Models\ScheduledSms  $scheduledSms
     * @return array
     */
    protected function getGuardianPhones(ScheduledSms $scheduledSms): array
    {
        $guardianIds = $scheduledSms->recipient_ids ?? [];
        
        return \App\Models\Guardian::whereIn('id', $guardianIds)
            ->whereNotNull('phone')
            ->pluck('phone')
            ->unique()
            ->toArray();
    }

    /**
     * Get user phone numbers.
     *
     * @param  \App\Models\ScheduledSms  $scheduledSms
     * @return array
     */
    protected function getUserPhones(ScheduledSms $scheduledSms): array
    {
        $userIds = $scheduledSms->recipient_ids ?? [];
        
        // User modelinde phone alanı yoksa, guardian veya student üzerinden alınabilir
        // Şimdilik boş döndürüyoruz, ileride user'a phone eklenebilir
        return [];
    }

    /**
     * Get classroom phone numbers.
     *
     * @param  \App\Models\ScheduledSms  $scheduledSms
     * @return array
     */
    protected function getClassroomPhones(ScheduledSms $scheduledSms): array
    {
        $classroomIds = $scheduledSms->recipient_ids ?? [];
        
        // Sınıftaki öğrencilerin velilerinin telefonlarını al
        $phones = [];
        $students = \App\Models\Student::where('tenant_id', $scheduledSms->tenant_id)
            ->whereIn('classroom_id', $classroomIds)
            ->with('guardians')
            ->get();

        foreach ($students as $student) {
            foreach ($student->guardians as $guardian) {
                if ($guardian->phone) {
                    $phones[] = $guardian->phone;
                }
            }
        }

        return array_unique($phones);
    }

    /**
     * Get all phone numbers (all guardians in tenant).
     *
     * @param  \App\Models\ScheduledSms  $scheduledSms
     * @return array
     */
    protected function getAllPhones(ScheduledSms $scheduledSms): array
    {
        // Tüm öğrencilerin velilerinin telefonlarını al
        $phones = [];
        $students = \App\Models\Student::where('tenant_id', $scheduledSms->tenant_id)
            ->with('guardians')
            ->get();

        foreach ($students as $student) {
            foreach ($student->guardians as $guardian) {
                if ($guardian->phone) {
                    $phones[] = $guardian->phone;
                }
            }
        }

        return array_unique($phones);
    }

    /**
     * Handle a job failure.
     *
     * @param  \Throwable  $exception
     * @return void
     */
    public function failed(\Throwable $exception): void
    {
        Log::error('ProcessScheduledSmsJob kalıcı olarak başarısız oldu', [
            'error' => $exception->getMessage(),
        ]);
    }
}
