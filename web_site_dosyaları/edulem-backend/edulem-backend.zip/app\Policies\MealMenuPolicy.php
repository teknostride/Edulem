<?php

namespace App\Policies;

use App\Models\MealMenu;
use App\Models\User;

class MealMenuPolicy
{
    private array $managementRoles = ['owner', 'Genel Müdür', 'Kampüs Müdürü', 'Müdür', 'Müdür Yardımcısı', 'Öğrenci İşleri'];
    private array $managementRoleIds = [1, 2, 3, 4, 7, 10];

    private function isManagement(User $user): bool
    {
        if (!empty($user->role_id) && in_array((int) $user->role_id, $this->managementRoleIds, true)) {
            return true;
        }
        $roleName = $user->role ? $user->role->name : null;
        return (bool) ($roleName && in_array($roleName, $this->managementRoles, true));
    }

    /**
     * Determine if the user can view any meal menus.
     */
    public function viewAny(User $user): bool
    {
        // Menü listesi kurum içi bir ekrandır; tenant kullanıcısı olan herkes listeyi görebilsin.
        // (İleride daha ince yetki kontrolü gerekirse bu kısım daraltılabilir.)
        if (!empty($user->tenant_id)) {
            return true;
        }

        if ($this->isManagement($user)) {
            return true;
        }

        return $user->hasPermission('academic.read') || $user->is_superadmin;
    }

    /**
     * Determine if the user can view the meal menu.
     */
    public function view(User $user, MealMenu $mealMenu): bool
    {
        if ($user->is_superadmin) {
            return true;
        }

        if ($user->tenant_id !== $mealMenu->tenant_id) {
            return false;
        }

        return $user->hasPermission('academic.read');
    }

    /**
     * Determine if the user can create meal menus.
     */
    public function create(User $user): bool
    {
        if ($this->isManagement($user)) {
            return true;
        }
        return $user->hasPermission('academic.create') || $user->is_superadmin;
    }

    /**
     * Determine if the user can update the meal menu.
     */
    public function update(User $user, MealMenu $mealMenu): bool
    {
        if ($user->is_superadmin) {
            return true;
        }

        if ($this->isManagement($user)) {
            return $user->tenant_id === $mealMenu->tenant_id;
        }

        if ($user->tenant_id !== $mealMenu->tenant_id) {
            return false;
        }

        return $user->hasPermission('academic.update');
    }

    /**
     * Determine if the user can delete the meal menu.
     */
    public function delete(User $user, MealMenu $mealMenu): bool
    {
        if ($user->is_superadmin) {
            return true;
        }

        if ($this->isManagement($user)) {
            return $user->tenant_id === $mealMenu->tenant_id;
        }

        if ($user->tenant_id !== $mealMenu->tenant_id) {
            return false;
        }

        return $user->hasPermission('academic.delete');
    }
}
