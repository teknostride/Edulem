<?php

namespace App\Http\Controllers;

use App\Models\Guardian;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class AuthController extends Controller
{
    /**
     * Login user and create token.
     */
    public function login(Request $request): JsonResponse
    {
        try {
            $email = mb_strtolower(trim((string) $request->input('email')));
            $password = $request->input('password');

            // 1) Personel kullanıcı girişi
            $user = User::whereRaw('LOWER(email) = ?', [$email])->first();
            if ($user && Hash::check($password, $user->password)) {
                if ($user->is_active === false) {
                    return response()->json([
                        'status' => false,
                        'message' => 'Hesabınız askıya alınmıştır.'
                    ], 403);
                }

                $token = $user->createToken('api-token')->plainTextToken;

                return response()->json([
                    'status' => true,
                    'data' => [
                        'user' => [
                            'id' => $user->id,
                            'name' => $user->name,
                            'email' => $user->email,
                            'role' => $user->role ? $user->role->name : null,
                            'role_label' => $user->role ? $user->role->display_name : null,
                        ],
                        'token' => $token,
                    ],
                    'message' => 'Giriş başarılı.'
                ]);
            }

            // 2) Veli (öğrenci portal) girişi
            $guardian = Guardian::query()
                ->whereRaw('LOWER(email) = ?', [$email])
                ->with(['students' => function ($q) {
                    $q->orderBy('guardian_student.created_at')->orderBy('students.id');
                }])
                ->first();

            if ($guardian && Hash::check($password, $guardian->password) && $guardian->is_portal_active) {
                $student = $guardian->students->first();

                if (!$student) {
                    return response()->json([
                        'status' => false,
                        'message' => 'Bu veliye bağlı öğrenci bulunamadı.'
                    ], 404);
                }

                // personal_access_tokens.tokenable_id kolonu integer olduğu için
                // guardian (uuid) yerine bağlı öğrenci üzerinden token üret.
                $token = $student->createToken('api-token')->plainTextToken;
                $guardian->update(['last_login_at' => now()]);

                return response()->json([
                    'status' => true,
                    'data' => [
                        'user' => [
                            'id' => $student->id,
                            'name' => $student->name,
                            'email' => $guardian->email,
                            'school_no' => $student->school_no,
                            'guardian_name' => $guardian->name,
                            'role' => 'student',
                            'role_label' => 'Veli',
                        ],
                        'token' => $token,
                    ],
                    'message' => 'Giriş başarılı.'
                ]);
            }

            return response()->json([
                'status' => false,
                'message' => 'E-posta veya şifre hatalı.'
            ], 401);

        } catch (\Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'Hata: ' . $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ], 500);
        }
    }

    /**
     * Logout user (revoke token).
     */
    public function logout(Request $request): JsonResponse
    {
        $user = $request->user();
        $user->currentAccessToken()->delete();

        return response()->json([
            'status' => true,
            'message' => 'Çıkış başarılı.'
        ]);
    }

    /**
     * Get authenticated user.
     */
    public function me(Request $request): JsonResponse
    {
        $user = $request->user();

        return response()->json([
            'status' => true,
            'data' => [
                'user' => [
                    'id' => $user->id,
                    'name' => $user->name,
                    'email' => $user->email,
                ],
            ],
            'message' => 'Kullanıcı bilgileri getirildi.'
        ]);
    }

    /**
     * Get current user profile (for Profil sayfası).
     */
    public function getProfile(Request $request): JsonResponse
    {
        $user = $request->user();
        $user->load('role');
        $campusIds = array_filter(array_map('intval', (array) ($user->campus_ids ?? [])));
        $campuses = $campusIds ? \App\Models\Campus::whereIn('id', $campusIds)->get(['id', 'name']) : collect();
        $campusName = $campuses->pluck('name')->implode(', ') ?: null;

        return response()->json([
            'status' => true,
            'data' => [
                'id' => $user->id,
                'name' => $user->name,
                'first_name' => $user->first_name,
                'last_name' => $user->last_name,
                'email' => $user->email,
                'phone' => $user->phone,
                'role_name' => $user->role ? $user->role->name : null,
                'role_label' => $user->role ? $user->role->display_name : null,
                'campus_name' => $campusName,
                'created_at' => $user->created_at?->toIso8601String(),
                'updated_at' => $user->updated_at?->toIso8601String(),
            ],
            'message' => 'Profil getirildi.',
        ]);
    }

    /**
     * Update current user profile (ad, soyad, e-posta, telefon, şifre) – veritabanına yazar.
     */
    public function updateProfile(Request $request): JsonResponse
    {
        $user = $request->user();

        $validated = $request->validate([
            'name' => 'sometimes|string|max:255',
            'first_name' => 'nullable|string|max:255',
            'last_name' => 'nullable|string|max:255',
            'email' => 'sometimes|email|unique:users,email,' . $user->id,
            'phone' => 'nullable|string|max:20',
            'current_password' => 'nullable|string',
            'password' => 'nullable|string|min:6|confirmed',
        ], [
            'email.unique' => 'Bu e-posta adresi başka bir kullanıcı tarafından kullanılıyor.',
            'password.min' => 'Şifre en az 6 karakter olmalıdır.',
            'password.confirmed' => 'Şifre tekrarı eşleşmiyor.',
        ]);

        if (!empty($validated['current_password']) && !empty($validated['password'])) {
            if (!Hash::check($validated['current_password'], $user->password)) {
                return response()->json([
                    'status' => false,
                    'message' => 'Mevcut şifre hatalı.',
                ], 422);
            }
            $user->password = Hash::make($validated['password']);
        }
        unset($validated['current_password'], $validated['password'], $validated['password_confirmation']);

        if (isset($validated['first_name']) || isset($validated['last_name'])) {
            $validated['name'] = trim(($validated['first_name'] ?? $user->first_name ?? '') . ' ' . ($validated['last_name'] ?? $user->last_name ?? ''));
        }

        $user->fill($validated);
        $user->save();

        return response()->json([
            'status' => true,
            'data' => [
                'user' => [
                    'id' => $user->id,
                    'name' => $user->name,
                    'email' => $user->email,
                    'role' => $user->role?->name,
                    'role_label' => $user->role?->display_name,
                ],
            ],
            'message' => 'Profil başarıyla güncellendi.',
        ]);
    }
}
