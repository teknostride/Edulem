<?php

namespace App\Policies;

use App\Models\Homework;
use App\Models\User;
use Illuminate\Auth\Access\Response;

class HomeworkPolicy
{
    private array $teacherOnlyRoles = ['Öğretmen', 'Sınıf Öğretmeni', 'Rehberlik', 'guidance', 'Rehber Öğretmen', 'rehber_teacher', 'guidance_teacher', 'teacher'];
    private array $teacherOnlyRoleIds = [5, 6];

    private array $managerRoles = [
        'owner', 'Kurucu', 'Kurum Sahibi', 'institution_owner',
        'Genel Müdür', 'Kampüs Müdürü', 'Müdür', 'Müdür Yardımcısı',
        'general_manager', 'campus_manager', 'school_principal',
    ];

    private function isTeacherOnly(User $user): bool
    {
        if (!empty($user->role_id) && in_array((int) $user->role_id, $this->teacherOnlyRoleIds, true)) {
            return true;
        }

        $roleName = $user->role ? $user->role->name : null;
        return $roleName && in_array($roleName, $this->teacherOnlyRoles, true);
    }

    private function isStudentAffairs(User $user): bool
    {
        $roleName = $user->role ? $user->role->name : null;
        return in_array($roleName, ['Öğrenci İşleri', 'student_affairs'], true);
    }

    private function isManagerRole(User $user): bool
    {
        $roleName = $user->role ? $user->role->name : null;
        return $roleName && in_array($roleName, $this->managerRoles, true);
    }

    /**
     * Determine whether the user can view any models.
     * Öğretmen, Kurucu, Müdür, Müdür Yardımcısı vb. ödev listesini görebilir.
     */
    public function viewAny(User $user): bool
    {
        if ($this->isStudentAffairs($user)) {
            return false;
        }

        if ($user->hasPermission('academic.read')) {
            return true;
        }

        if ($this->isTeacherOnly($user)) {
            return true;
        }
        $roleName = $user->role ? $user->role->name : null;
        return in_array($roleName, [
            'owner', 'Kurucu', 'Kurum Sahibi', 'institution_owner',
            'Genel Müdür', 'Kampüs Müdürü', 'Müdür', 'Müdür Yardımcısı',
            'Öğretmen', 'Sınıf Öğretmeni',
        ], true);
    }

    /**
     * Determine whether the user can view the model.
     */
    public function view(User $user, Homework $homework): bool
    {
        if ($this->isStudentAffairs($user)) {
            return false;
        }

        if ($user->tenant_id !== $homework->tenant_id) {
            return false;
        }

        if ($user->hasPermission('academic.read')) {
            return true;
        }

        if ($this->isManagerRole($user)) {
            return true;
        }

        $isTeacherOnly = $this->isTeacherOnly($user);
        if ($isTeacherOnly) {
            return (int) $homework->teacher_id === (int) $user->id;
        }

        return false;
    }

    /**
     * Determine whether the user can create models.
     */
    public function create(User $user): bool
    {
        if ($this->isStudentAffairs($user)) {
            return false;
        }

        if ($user->hasPermission('academic.create')) {
            return true;
        }

        if ($this->isManagerRole($user)) {
            return true;
        }

        return $this->isTeacherOnly($user);
    }

    /**
     * Determine whether the user can update the model.
     */
    public function update(User $user, Homework $homework): bool
    {
        if ($this->isStudentAffairs($user)) {
            return false;
        }

        if ($user->tenant_id !== $homework->tenant_id) {
            return false;
        }

        if ($this->isManagerRole($user)) {
            return true;
        }

        // Yetkili roller tüm ödevleri güncelleyebilir
        if ($user->hasPermission('academic.update')) {
            $role = $user->role ?? null;
            if ($role && in_array($role->name, ['owner', 'Genel Müdür', 'Kampüs Müdürü', 'Müdür', 'Müdür Yardımcısı', 'general_manager', 'campus_manager', 'school_principal'], true)) {
                return true;
            }
        }

        // Öğretmen sadece kendi ödevlerini güncelleyebilir (permission olmasa da)
        $isTeacherOnly = $this->isTeacherOnly($user);
        if ($isTeacherOnly) {
            return (int) $homework->teacher_id === (int) $user->id;
        }

        return false;
    }

    /**
     * Determine whether the user can delete the model.
     */
    public function delete(User $user, Homework $homework): bool
    {
        if ($this->isStudentAffairs($user)) {
            return false;
        }

        if ($user->tenant_id !== $homework->tenant_id) {
            return false;
        }

        if ($this->isManagerRole($user)) {
            return true;
        }

        if ($user->hasPermission('academic.delete')) {
            $role = $user->role ?? null;
            if ($role && in_array($role->name, ['owner', 'Genel Müdür', 'Kampüs Müdürü', 'Müdür', 'Müdür Yardımcısı', 'general_manager', 'campus_manager', 'school_principal'], true)) {
                return true;
            }
        }

        $isTeacherOnly = $this->isTeacherOnly($user);
        if ($isTeacherOnly) {
            return (int) $homework->teacher_id === (int) $user->id;
        }

        return false;
    }

    /**
     * Determine whether the user can restore the model.
     */
    public function restore(User $user, Homework $homework): bool
    {
        return $this->delete($user, $homework);
    }

    /**
     * Determine whether the user can permanently delete the model.
     */
    public function forceDelete(User $user, Homework $homework): bool
    {
        return $this->delete($user, $homework);
    }
}
