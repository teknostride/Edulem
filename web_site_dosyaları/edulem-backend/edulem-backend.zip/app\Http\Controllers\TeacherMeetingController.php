<?php

namespace App\Http\Controllers;

use App\Models\Classroom;
use App\Models\Schedule;
use App\Models\Student;
use App\Models\TeacherMeeting;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;

class TeacherMeetingController extends ApiController
{
    private const TEACHER_ROLES = ['Öğretmen', 'Sınıf Öğretmeni', 'teacher'];

    private function ensureTeacherUser(Request $request): ?JsonResponse
    {
        $user = $request->user();
        $roleName = $user && $user->role ? $user->role->name : null;

        if (! $this->isTeacherRole($roleName)) {
            return $this->error('Bu endpoint sadece öğretmen kullanıcılar içindir.', [], 403);
        }

        return null;
    }

    private function isTeacherRole(?string $roleName): bool
    {
        return $roleName && in_array($roleName, self::TEACHER_ROLES, true);
    }

    private function teacherAllowedClassroomIds($user): array
    {
        return Schedule::query()
            ->where('tenant_id', $user->tenant_id)
            ->where('teacher_id', $user->id)
            ->whereNotNull('classroom_id')
            ->pluck('classroom_id')
            ->map(fn ($id) => (int) $id)
            ->filter(fn ($id) => $id > 0)
            ->unique()
            ->values()
            ->all();
    }

    /**
     * Görüşme kayıtları listesi (type=meeting, visibility != private)
     */
    public function meetings(Request $request): JsonResponse
    {
        if ($guard = $this->ensureTeacherUser($request)) {
            return $guard;
        }

        $user = $request->user();

        $records = TeacherMeeting::query()
            ->where('tenant_id', $user->tenant_id)
            ->where('teacher_id', $user->id)
            ->where('type', TeacherMeeting::TYPE_MEETING)
            ->where('visibility', '!=', TeacherMeeting::VISIBILITY_PRIVATE)
            ->with(['student.classroom.educationLevel'])
            ->orderByDesc('meeting_date')
            ->orderByDesc('created_at')
            ->get();

        return $this->success([
            'meetings' => $records->map(fn ($m) => $this->formatMeeting($m)),
        ]);
    }

    /**
     * Özel notlar listesi (type=meeting, visibility=private)
     */
    public function privateNotes(Request $request): JsonResponse
    {
        if ($guard = $this->ensureTeacherUser($request)) {
            return $guard;
        }

        $user = $request->user();

        $records = TeacherMeeting::query()
            ->where('tenant_id', $user->tenant_id)
            ->where('teacher_id', $user->id)
            ->where('type', TeacherMeeting::TYPE_MEETING)
            ->where('visibility', TeacherMeeting::VISIBILITY_PRIVATE)
            ->with(['student.classroom.educationLevel'])
            ->orderByDesc('meeting_date')
            ->orderByDesc('created_at')
            ->get();

        return $this->success([
            'notes' => $records->map(fn ($m) => $this->formatMeeting($m)),
        ]);
    }

    /**
     * Randevular listesi (type=appointment)
     */
    public function appointments(Request $request): JsonResponse
    {
        if ($guard = $this->ensureTeacherUser($request)) {
            return $guard;
        }

        $user = $request->user();
        $filter = $request->query('filter', 'today'); // today | upcoming | past

        $query = TeacherMeeting::query()
            ->where('tenant_id', $user->tenant_id)
            ->where('teacher_id', $user->id)
            ->where('type', TeacherMeeting::TYPE_APPOINTMENT)
            ->with(['student.classroom.educationLevel']);

        $today = Carbon::today()->toDateString();

        if ($filter === 'today') {
            $query->whereDate('meeting_date', $today);
        } elseif ($filter === 'upcoming') {
            $query->whereDate('meeting_date', '>', $today);
        } elseif ($filter === 'past') {
            $query->whereDate('meeting_date', '<', $today);
        }

        $records = $query
            ->orderBy('meeting_date')
            ->orderBy('meeting_time')
            ->get();

        return $this->success([
            'appointments' => $records->map(fn ($m) => $this->formatMeeting($m)),
        ]);
    }

    /**
     * Tek kayıt detayı
     */
    public function show(Request $request, int $id): JsonResponse
    {
        if ($guard = $this->ensureTeacherUser($request)) {
            return $guard;
        }

        $user = $request->user();

        $meeting = TeacherMeeting::query()
            ->where('tenant_id', $user->tenant_id)
            ->where('teacher_id', $user->id)
            ->with(['student.classroom.educationLevel'])
            ->find($id);

        if (! $meeting) {
            return $this->error('Kayıt bulunamadı.', [], 404);
        }

        return $this->success([
            'meeting' => $this->formatMeeting($meeting),
        ]);
    }

    /**
     * Yeni görüşme/not/randevu oluştur
     */
    public function store(Request $request): JsonResponse
    {
        if ($guard = $this->ensureTeacherUser($request)) {
            return $guard;
        }

        $user = $request->user();

        $request->validate([
            'type' => 'required|in:meeting,appointment',
            'meeting_with' => 'required|in:student,parent',
            'classroom_id' => 'required|integer|exists:classrooms,id',
            'student_id' => 'required|integer|exists:students,id',
            'title' => 'required_if:type,meeting|string|max:255',
            'content' => 'nullable|string',
            'meeting_date' => 'required|date',
            'meeting_time' => 'nullable|date_format:H:i',
            'visibility' => 'required_if:type,meeting|in:admin_only,teachers_open,public,private',
        ]);

        $classroomId = (int) $request->classroom_id;
        $allowedClassroomIds = $this->teacherAllowedClassroomIds($user);

        if (! in_array($classroomId, $allowedClassroomIds, true)) {
            return $this->error('Bu sınıfa erişim yetkiniz yok.', [], 403);
        }

        $classroom = Classroom::query()
            ->where('tenant_id', $user->tenant_id)
            ->find($classroomId);

        if (! $classroom) {
            return $this->error('Sınıf bulunamadı.', [], 404);
        }

        // Öğrencinin bu tenant'a ait olduğunu ve seçilen sınıfta olduğunu doğrula
        $student = Student::query()
            ->where('tenant_id', $user->tenant_id)
            ->where('classroom_id', $classroomId)
            ->find($request->student_id);

        if (! $student) {
            return $this->error('Öğrenci seçilen sınıfta bulunamadı.', [], 422);
        }

        $data = [
            'tenant_id' => $user->tenant_id,
            'teacher_id' => $user->id,
            'student_id' => $request->student_id,
            'meeting_with' => $request->meeting_with,
            'type' => $request->type,
            'title' => $request->type === 'appointment' ? ($request->title ?? 'Randevu') : $request->title,
            'content' => $request->content,
            'meeting_date' => $request->meeting_date,
            'meeting_time' => $request->meeting_time,
            'visibility' => $request->type === 'appointment' ? 'admin_only' : $request->visibility,
            'status' => 'planned',
        ];

        $meeting = TeacherMeeting::create($data);
        $meeting->load('student.classroom.educationLevel');

        return $this->success([
            'meeting' => $this->formatMeeting($meeting),
        ], 'Kayıt başarıyla oluşturuldu.', 201);
    }

    /**
     * Güncelle
     */
    public function update(Request $request, int $id): JsonResponse
    {
        if ($guard = $this->ensureTeacherUser($request)) {
            return $guard;
        }

        $user = $request->user();

        $meeting = TeacherMeeting::query()
            ->where('tenant_id', $user->tenant_id)
            ->where('teacher_id', $user->id)
            ->find($id);

        if (! $meeting) {
            return $this->error('Kayıt bulunamadı.', [], 404);
        }

        $request->validate([
            'meeting_with' => 'sometimes|in:student,parent',
            'classroom_id' => 'sometimes|integer|exists:classrooms,id',
            'student_id' => 'sometimes|integer|exists:students,id',
            'title' => 'sometimes|string|max:255',
            'content' => 'nullable|string',
            'meeting_date' => 'sometimes|date',
            'meeting_time' => 'nullable|date_format:H:i',
            'visibility' => 'sometimes|in:admin_only,teachers_open,public,private',
            'status' => 'sometimes|in:planned,completed,cancelled',
        ]);

        if ($request->hasAny(['classroom_id', 'student_id'])) {
            if (! $request->filled('classroom_id') || ! $request->filled('student_id')) {
                return $this->error('Sınıf ve öğrenci birlikte gönderilmelidir.', [], 422);
            }

            $classroomId = (int) $request->classroom_id;
            $allowedClassroomIds = $this->teacherAllowedClassroomIds($user);

            if (! in_array($classroomId, $allowedClassroomIds, true)) {
                return $this->error('Bu sınıfa erişim yetkiniz yok.', [], 403);
            }

            $classroom = Classroom::query()
                ->where('tenant_id', $user->tenant_id)
                ->find($classroomId);

            if (! $classroom) {
                return $this->error('Sınıf bulunamadı.', [], 404);
            }

            $student = Student::query()
                ->where('tenant_id', $user->tenant_id)
                ->where('classroom_id', $classroomId)
                ->find($request->student_id);

            if (! $student) {
                return $this->error('Öğrenci seçilen sınıfta bulunamadı.', [], 422);
            }
        }

        $meeting->update($request->only([
            'student_id', 'meeting_with', 'title', 'content', 'meeting_date', 'meeting_time', 'visibility', 'status',
        ]));

        $meeting->load('student.classroom.educationLevel');

        return $this->success([
            'meeting' => $this->formatMeeting($meeting),
        ], 'Kayıt başarıyla güncellendi.');
    }

    /**
     * Sil
     */
    public function destroy(Request $request, int $id): JsonResponse
    {
        if ($guard = $this->ensureTeacherUser($request)) {
            return $guard;
        }

        $user = $request->user();

        $meeting = TeacherMeeting::query()
            ->where('tenant_id', $user->tenant_id)
            ->where('teacher_id', $user->id)
            ->find($id);

        if (! $meeting) {
            return $this->error('Kayıt bulunamadı.', [], 404);
        }

        $meeting->delete();

        return $this->success([], 'Kayıt başarıyla silindi.');
    }

    /**
     * Öğretmenin yetkili sınıfları (randevu modalı için)
     */
    public function classrooms(Request $request): JsonResponse
    {
        if ($guard = $this->ensureTeacherUser($request)) {
            return $guard;
        }

        $user = $request->user();
        $classroomIds = $this->teacherAllowedClassroomIds($user);

        $classrooms = Classroom::query()
            ->where('tenant_id', $user->tenant_id)
            ->whereIn('id', $classroomIds)
            ->with('educationLevel')
            ->orderBy('name')
            ->get()
            ->map(fn ($c) => [
                'id' => $c->id,
                'name' => $c->name,
                'education_level' => $c->educationLevel ? $c->educationLevel->name : null,
            ]);

        return $this->success(['classrooms' => $classrooms]);
    }

    /**
     * Sınıftaki öğrenciler (randevu modalı için)
     */
    public function classroomStudents(Request $request, int $classroomId): JsonResponse
    {
        if ($guard = $this->ensureTeacherUser($request)) {
            return $guard;
        }

        $user = $request->user();
        $allowedIds = $this->teacherAllowedClassroomIds($user);

        if (! in_array($classroomId, $allowedIds, true)) {
            return $this->error('Bu sınıfa erişim yetkiniz yok.', [], 403);
        }

        $students = Student::query()
            ->where('tenant_id', $user->tenant_id)
            ->where('classroom_id', $classroomId)
            ->where('is_active', true)
            ->orderBy('name')
            ->get(['id', 'name', 'school_no', 'classroom_id']);

        return $this->success(['students' => $students]);
    }

    private function formatMeeting(TeacherMeeting $m): array
    {
        $student = $m->student;
        $classroom = $student?->classroom;
        $educationLevel = $classroom?->educationLevel;

        $classroomLabel = null;
        if ($educationLevel && $classroom) {
            $classroomLabel = $educationLevel->name . ' - ' . $classroom->name;
        } elseif ($classroom) {
            $classroomLabel = $classroom->name;
        }

        return [
            'id' => $m->id,
            'type' => $m->type,
            'meeting_with' => $m->meeting_with,
            'title' => $m->title,
            'content' => $m->content,
            'meeting_date' => $m->meeting_date?->format('Y-m-d'),
            'meeting_time' => $m->meeting_time,
            'visibility' => $m->visibility,
            'status' => $m->status,
            'student' => $student ? [
                'id' => $student->id,
                'name' => $student->name,
                'school_no' => $student->school_no,
                'classroom_id' => $student->classroom_id,
            ] : null,
            'classroom_label' => $classroomLabel,
            'created_at' => $m->created_at?->toIso8601String(),
            'updated_at' => $m->updated_at?->toIso8601String(),
        ];
    }
}
