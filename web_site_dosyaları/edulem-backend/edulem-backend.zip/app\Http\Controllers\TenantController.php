<?php

namespace App\Http\Controllers;

use App\Models\Tenant;
use App\Models\Campus;
use App\Models\EducationLevel;
use App\Models\Classroom;
use App\Models\Student;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class TenantController extends ApiController
{
    private function isStudentAffairsRole(?string $roleName): bool
    {
        return in_array($roleName, ['Öğrenci İşleri', 'student_affairs'], true);
    }

    /**
     * Get current tenant profile.
     */
    public function profile(): JsonResponse
    {
        try {
            $user = Auth::user();
            if (!$user) {
                return $this->error('Oturum bulunamadı.', [], 401);
            }
            $roleName = $user->role ? $user->role->name : null;
            if ($this->isStudentAffairsRole($roleName)) {
                return $this->error('Bu modüle erişim yetkiniz yok.', [], 403);
            }

            if (!$user->tenant_id) {
                if ($user->is_superadmin) {
                    return $this->error('Bu sayfa sadece kurum kullanıcıları içindir. Super Admin olarak giriş yaptınız.', [], 404);
                }
                // Geliştirme / tek kurum: sistemde tek kurum varsa bu kullanıcıya ata
                $only = Tenant::first();
                if ($only && Tenant::count() === 1) {
                    $user->update(['tenant_id' => $only->id]);
                } else {
                    return $this->error('Kullanıcıya ait kurum bulunamadı. Lütfen yöneticinizle iletişime geçin.', [], 404);
                }
            }

            $tenant = Tenant::findOrFail($user->tenant_id);
            $studentCount = Student::where('tenant_id', $tenant->id)->count();

            return $this->success([
                'id' => $tenant->id,
                'name' => $tenant->name,
                'domain' => $tenant->domain,
                'is_active' => $tenant->is_active,
                'student_count' => $studentCount,
                'subscription_expires_at' => $tenant->subscription_expires_at,
            ], 'Kurum bilgileri başarıyla getirildi.');
        } catch (\Exception $e) {
            return $this->error('Kurum bilgileri alınırken hata: ' . $e->getMessage(), [], 500);
        }
    }

    /**
     * Update current tenant profile.
     */
    public function updateProfile(Request $request): JsonResponse
    {
        try {
            $user = Auth::user();
            if (!$user || !$user->tenant_id) {
                return $this->error('Kullanıcıya ait kurum bulunamadı.', [], 404);
            }
            $roleName = $user->role ? $user->role->name : null;
            if ($this->isStudentAffairsRole($roleName)) {
                return $this->error('Bu modüle erişim yetkiniz yok.', [], 403);
            }

            $tenant = Tenant::findOrFail($user->tenant_id);

            $validated = $request->validate([
                'name' => 'required|string|max:255',
                'domain' => 'required|string|max:255|unique:tenants,domain,' . $tenant->id,
            ]);

            $tenant->update($validated);

            return $this->success([
                'tenant' => $tenant->fresh()
            ], 'Kurum bilgileri başarıyla güncellendi.');
        } catch (\Exception $e) {
            return $this->error('Kurum bilgileri güncellenemedi: ' . $e->getMessage(), [], 500);
        }
    }

    /**
     * Delete current tenant.
     */
    public function deleteProfile(): JsonResponse
    {
        try {
            $user = Auth::user();
            if (!$user || !$user->tenant_id) {
                return $this->error('Kullanıcıya ait kurum bulunamadı.', [], 404);
            }
            $roleName = $user->role ? $user->role->name : null;
            if ($this->isStudentAffairsRole($roleName)) {
                return $this->error('Bu modüle erişim yetkiniz yok.', [], 403);
            }

            $tenant = Tenant::findOrFail($user->tenant_id);
            
            // Kurum silme işlemi - ilişkili verileri de sil
            $tenant->delete();

            return $this->success([], 'Kurum başarıyla silindi.');
        } catch (\Exception $e) {
            return $this->error('Kurum silinemedi: ' . $e->getMessage(), [], 500);
        }
    }

    /**
     * Get tenant statistics.
     */
    public function statistics(): JsonResponse
    {
        try {
            $user = Auth::user();
            if (!$user) {
                return $this->error('Oturum bulunamadı.', [], 401);
            }
            $roleName = $user->role ? $user->role->name : null;
            if ($this->isStudentAffairsRole($roleName)) {
                return $this->error('Bu modüle erişim yetkiniz yok.', [], 403);
            }
            if (!$user->tenant_id) {
                if ($user->is_superadmin) {
                    return $this->error('Bu sayfa sadece kurum kullanıcıları içindir.', [], 404);
                }
                $only = Tenant::first();
                if ($only && Tenant::count() === 1) {
                    $user->update(['tenant_id' => $only->id]);
                } else {
                    return $this->error('Kullanıcıya ait kurum bulunamadı.', [], 404);
                }
            }

            $tenantId = $user->tenant_id;

            $stats = [
                'campuses' => Campus::where('tenant_id', $tenantId)->count(),
                'education_levels' => EducationLevel::where('tenant_id', $tenantId)->count(),
                'classrooms' => Classroom::where('tenant_id', $tenantId)->count(),
                'students' => Student::where('tenant_id', $tenantId)->count(),
                'teachers' => User::where('tenant_id', $tenantId)
                    ->whereHas('role', function($query) {
                        $query->where('name', 'teacher');
                    })->count(),
                'staff' => User::where('tenant_id', $tenantId)
                    ->whereHas('role', function ($query) {
                        $query->whereNotIn('name', ['student', 'teacher']);
                    })->count(),
            ];

            return $this->success([
                'statistics' => $stats
            ], 'Kurum istatistikleri başarıyla getirildi.');
        } catch (\Exception $e) {
            return $this->error('İstatistikler getirilemedi: ' . $e->getMessage(), [], 500);
        }
    }
}
