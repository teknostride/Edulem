<?php

namespace App\Actions;

use App\Models\ScheduledSms;
use App\Services\ActivityLogService;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class CreateScheduledSmsAction
{
    protected ActivityLogService $activityLogService;

    public function __construct(ActivityLogService $activityLogService)
    {
        $this->activityLogService = $activityLogService;
    }

    /**
     * Execute the action to create a scheduled SMS.
     *
     * @param  array  $smsData
     * @return \App\Models\ScheduledSms
     */
    public function execute(array $smsData): ScheduledSms
    {
        return DB::transaction(function () use ($smsData) {
            $user = Auth::user();
            $tenantId = $user->tenant_id;

            $scheduledSms = ScheduledSms::create([
                'tenant_id' => $tenantId,
                'title' => $smsData['title'] ?? null,
                'message' => $smsData['message'],
                'recipient_phones' => $smsData['recipient_phones'] ?? [],
                'recipient_type' => $smsData['recipient_type'],
                'recipient_ids' => $smsData['recipient_ids'] ?? [],
                'scheduled_at' => $smsData['scheduled_at'],
                'status' => 'pending',
                'created_by' => $user->id,
            ]);

            $this->activityLogService->logCreate($scheduledSms);

            // İlişkileri yükle
            $scheduledSms->load(['creator']);

            return $scheduledSms;
        });
    }
}
