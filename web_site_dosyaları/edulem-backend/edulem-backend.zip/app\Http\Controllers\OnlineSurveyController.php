<?php

namespace App\Http\Controllers;

use App\Actions\CreateOnlineSurveyAction;
use App\Actions\CreateOnlineSurveyQuestionAction;
use App\Actions\CreateOnlineSurveyResponseAction;
use App\Http\Requests\StoreOnlineSurveyRequest;
use App\Http\Requests\StoreOnlineSurveyQuestionRequest;
use App\Http\Requests\StoreOnlineSurveyResponseRequest;
use App\Http\Resources\OnlineSurveyResource;
use App\Http\Resources\OnlineSurveyQuestionResource;
use App\Http\Resources\OnlineSurveyResponseResource;
use App\Models\OnlineSurvey;
use App\Models\OnlineSurveyQuestion;
use App\Models\OnlineSurveyResponse;
use App\Services\ActivityLogService;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Gate;
use Carbon\Carbon;

class OnlineSurveyController extends ApiController
{
    protected ActivityLogService $activityLogService;

    public function __construct(ActivityLogService $activityLogService)
    {
        $this->activityLogService = $activityLogService;
    }

    /**
     * Display a listing of online surveys.
     */
    public function index(): JsonResponse
    {
        Gate::authorize('viewAny', OnlineSurvey::class);

        $query = OnlineSurvey::with(['creator', 'questions']);

        // Filtreleme
        if (request()->has('active_only')) {
            $query->where('is_active', true)
                ->where('start_date', '<=', Carbon::now())
                ->where('end_date', '>=', Carbon::now());
        }

        if (request()->has('required_only')) {
            $query->where('is_required', true);
        }

        if (request()->has('start_date_from')) {
            $query->where('start_date', '>=', request('start_date_from'));
        }

        if (request()->has('start_date_to')) {
            $query->where('start_date', '<=', request('start_date_to'));
        }

        // Sıralama
        $query->orderBy('start_date', 'desc')
            ->orderBy('created_at', 'desc');

        $surveys = $query->paginate(request('per_page', 50));

        return $this->success([
            'surveys' => OnlineSurveyResource::collection($surveys),
            'pagination' => [
                'current_page' => $surveys->currentPage(),
                'last_page' => $surveys->lastPage(),
                'per_page' => $surveys->perPage(),
                'total' => $surveys->total(),
            ],
        ], 'Online anketler başarıyla listelendi.');
    }

    /**
     * Store a newly created online survey.
     */
    public function store(StoreOnlineSurveyRequest $request, CreateOnlineSurveyAction $action): JsonResponse
    {
        Gate::authorize('create', OnlineSurvey::class);

        try {
            $survey = $action->execute($request->validated());

            return $this->success(new OnlineSurveyResource($survey), 'Online anket başarıyla oluşturuldu.', 201);
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), [], 400);
        }
    }

    /**
     * Display the specified online survey.
     */
    public function show(OnlineSurvey $onlineSurvey): JsonResponse
    {
        Gate::authorize('view', $onlineSurvey);

        $onlineSurvey->load(['creator', 'questions', 'responses']);

        return $this->success(new OnlineSurveyResource($onlineSurvey));
    }

    /**
     * Update the specified online survey.
     */
    public function update(StoreOnlineSurveyRequest $request, OnlineSurvey $onlineSurvey): JsonResponse
    {
        Gate::authorize('update', $onlineSurvey);

        try {
            $onlineSurvey->update($request->validated());
            $this->activityLogService->logUpdate($onlineSurvey);

            return $this->success(new OnlineSurveyResource($onlineSurvey->fresh()), 'Online anket başarıyla güncellendi.');
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), [], 400);
        }
    }

    /**
     * Remove the specified online survey.
     */
    public function destroy(OnlineSurvey $onlineSurvey): JsonResponse
    {
        Gate::authorize('delete', $onlineSurvey);

        $this->activityLogService->logDelete($onlineSurvey);
        $onlineSurvey->delete();

        return $this->success(null, 'Online anket başarıyla silindi.');
    }

    /**
     * Add question to survey.
     */
    public function addQuestion(StoreOnlineSurveyQuestionRequest $request, CreateOnlineSurveyQuestionAction $action): JsonResponse
    {
        Gate::authorize('update', OnlineSurvey::findOrFail($request->online_survey_id));

        try {
            $question = $action->execute($request->validated());

            return $this->success(new OnlineSurveyQuestionResource($question), 'Soru başarıyla eklendi.', 201);
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), [], 400);
        }
    }

    /**
     * Update question.
     */
    public function updateQuestion(StoreOnlineSurveyQuestionRequest $request, OnlineSurveyQuestion $onlineSurveyQuestion): JsonResponse
    {
        Gate::authorize('update', $onlineSurveyQuestion->onlineSurvey);

        try {
            $onlineSurveyQuestion->update($request->validated());
            $this->activityLogService->logUpdate($onlineSurveyQuestion);

            // Soru sayısını güncelle
            $survey = $onlineSurveyQuestion->onlineSurvey;
            $survey->update([
                'question_count' => $survey->questions()->count(),
            ]);

            return $this->success(new OnlineSurveyQuestionResource($onlineSurveyQuestion->fresh()), 'Soru başarıyla güncellendi.');
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), [], 400);
        }
    }

    /**
     * Delete question.
     */
    public function deleteQuestion(OnlineSurveyQuestion $onlineSurveyQuestion): JsonResponse
    {
        Gate::authorize('update', $onlineSurveyQuestion->onlineSurvey);

        $survey = $onlineSurveyQuestion->onlineSurvey;
        $this->activityLogService->logDelete($onlineSurveyQuestion);
        $onlineSurveyQuestion->delete();

        // Soru sayısını güncelle
        $survey->update([
            'question_count' => $survey->questions()->count(),
        ]);

        return $this->success(null, 'Soru başarıyla silindi.');
    }

    /**
     * Submit survey response.
     */
    public function submitResponse(StoreOnlineSurveyResponseRequest $request, CreateOnlineSurveyResponseAction $action): JsonResponse
    {
        Gate::authorize('create', OnlineSurveyResponse::class);

        try {
            $response = $action->execute($request->validated());

            return $this->success(new OnlineSurveyResponseResource($response), 'Anket cevabı başarıyla gönderildi.', 201);
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), [], 400);
        }
    }

    /**
     * Get survey statistics.
     */
    public function getStatistics(OnlineSurvey $onlineSurvey): JsonResponse
    {
        Gate::authorize('view', $onlineSurvey);

        $totalResponses = $onlineSurvey->getTotalResponses();
        $anonymousResponses = $onlineSurvey->responses()->where('is_anonymous', true)->count();
        $nonAnonymousResponses = $totalResponses - $anonymousResponses;

        // Cevaplayan türü bazlı istatistikler
        $byRespondentType = $onlineSurvey->responses()
            ->selectRaw('respondent_type, COUNT(*) as count')
            ->whereNotNull('respondent_type')
            ->groupBy('respondent_type')
            ->pluck('count', 'respondent_type');

        return $this->success([
            'total_responses' => $totalResponses,
            'anonymous_responses' => $anonymousResponses,
            'non_anonymous_responses' => $nonAnonymousResponses,
            'by_respondent_type' => $byRespondentType,
            'question_count' => $onlineSurvey->question_count,
        ], 'Anket istatistikleri başarıyla getirildi.');
    }

    /**
     * Get survey analysis (general/individual).
     */
    public function getAnalysis(OnlineSurvey $onlineSurvey): JsonResponse
    {
        Gate::authorize('view', $onlineSurvey);

        $analysisType = request('type', 'general'); // general or individual

        if ($analysisType === 'general') {
            // Genel analiz: Tüm cevapların toplamı
            $responses = $onlineSurvey->responses()->get();
            $questions = $onlineSurvey->questions()->get();
            
            $analysis = [];
            foreach ($questions as $question) {
                $questionAnswers = [];
                foreach ($responses as $response) {
                    $answer = collect($response->answers)->firstWhere('question_id', $question->id);
                    if ($answer) {
                        $questionAnswers[] = $answer;
                    }
                }
                $analysis[] = [
                    'question_id' => $question->id,
                    'question' => $question->question,
                    'question_type' => $question->question_type,
                    'total_answers' => count($questionAnswers),
                    'answers' => $questionAnswers,
                ];
            }

            return $this->success([
                'type' => 'general',
                'analysis' => $analysis,
            ], 'Genel analiz başarıyla getirildi.');
        } else {
            // Bireysel analiz: Her cevaplayan için ayrı analiz
            $responses = $onlineSurvey->responses()
                ->where('is_anonymous', false)
                ->with(['respondent'])
                ->get();

            $individualAnalysis = $responses->map(function ($response) {
                return [
                    'respondent_id' => $response->respondent_id,
                    'respondent' => $response->respondent ? [
                        'id' => $response->respondent->id,
                        'name' => $response->respondent->name,
                    ] : null,
                    'respondent_type' => $response->respondent_type,
                    'answers' => $response->answers,
                    'notes' => $response->notes,
                    'submitted_at' => $response->created_at?->toISOString(),
                ];
            });

            return $this->success([
                'type' => 'individual',
                'analysis' => $individualAnalysis,
            ], 'Bireysel analiz başarıyla getirildi.');
        }
    }
}
