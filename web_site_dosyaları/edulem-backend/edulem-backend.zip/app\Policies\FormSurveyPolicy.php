<?php

namespace App\Policies;

use App\Models\FormSurvey;
use App\Models\User;

class FormSurveyPolicy
{
    /**
     * Determine if the user can view any form surveys.
     */
    public function viewAny(User $user): bool
    {
        return $user->hasPermission('academic.read') || $user->is_superadmin;
    }

    /**
     * Determine if the user can view the form survey.
     */
    public function view(User $user, FormSurvey $formSurvey): bool
    {
        if ($user->is_superadmin) {
            return true;
        }

        if ($user->tenant_id !== $formSurvey->tenant_id) {
            return false;
        }

        return $user->hasPermission('academic.read');
    }

    /**
     * Determine if the user can create form surveys.
     */
    public function create(User $user): bool
    {
        return $user->hasPermission('academic.create') || $user->is_superadmin;
    }

    /**
     * Determine if the user can update the form survey.
     */
    public function update(User $user, FormSurvey $formSurvey): bool
    {
        if ($user->is_superadmin) {
            return true;
        }

        if ($user->tenant_id !== $formSurvey->tenant_id) {
            return false;
        }

        return $user->hasPermission('academic.update');
    }

    /**
     * Determine if the user can delete the form survey.
     */
    public function delete(User $user, FormSurvey $formSurvey): bool
    {
        if ($user->is_superadmin) {
            return true;
        }

        if ($user->tenant_id !== $formSurvey->tenant_id) {
            return false;
        }

        return $user->hasPermission('academic.delete');
    }
}
