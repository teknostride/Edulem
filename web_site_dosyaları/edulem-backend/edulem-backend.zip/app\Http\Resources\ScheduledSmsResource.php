<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;

class ScheduledSmsResource extends ApiResource
{
    /**
     * Get public fields (visible to all authenticated users).
     *
     * @return array<string, mixed>
     */
    protected function getPublicFields(): array
    {
        return [
            'id' => $this->id,
            'title' => $this->title,
            'status' => $this->status,
            'scheduled_at' => $this->scheduled_at->format('Y-m-d H:i:s'),
            'created_at' => $this->created_at->format('Y-m-d H:i:s'),
        ];
    }

    /**
     * Get teacher-specific fields.
     *
     * @return array<string, mixed>
     */
    protected function getTeacherFields(): array
    {
        $fields = $this->getPublicFields();
        $fields['message'] = $this->message;
        $fields['recipient_type'] = $this->recipient_type;
        return $fields;
    }

    /**
     * Get accountant-specific fields.
     *
     * @return array<string, mixed>
     */
    protected function getAccountantFields(): array
    {
        return $this->getPublicFields();
    }

    /**
     * Get all fields (for admin).
     *
     * @return array<string, mixed>
     */
    protected function getAllFields(): array
    {
        $fields = $this->getPublicFields();
        
        if ($this->relationLoaded('creator') && $this->creator) {
            $fields['creator'] = [
                'id' => $this->creator->id,
                'name' => $this->creator->name,
            ];
        }
        
        $fields['message'] = $this->message;
        $fields['recipient_type'] = $this->recipient_type;
        $fields['recipient_phones'] = $this->recipient_phones;
        $fields['recipient_ids'] = $this->recipient_ids;
        $fields['sent_at'] = $this->sent_at?->format('Y-m-d H:i:s');
        $fields['sent_count'] = $this->sent_count;
        $fields['failed_count'] = $this->failed_count;
        $fields['error_message'] = $this->error_message;
        $fields['updated_at'] = $this->updated_at->format('Y-m-d H:i:s');
        
        return $fields;
    }
}
