<?php

namespace App\Http\Controllers;

use App\Actions\CreateMealMenuAction;
use App\Http\Requests\StoreMealMenuRequest;
use App\Http\Requests\StoreMealAttendanceRequest;
use App\Http\Resources\MealMenuResource;
use App\Http\Resources\MealAttendanceResource;
use App\Models\MealMenu;
use App\Models\MealAttendance;
use App\Services\ActivityLogService;
use App\Services\MealMenuService;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Gate;
use Carbon\Carbon;

class MealMenuController extends ApiController
{
    protected ActivityLogService $activityLogService;
    protected MealMenuService $mealMenuService;

    public function __construct(
        ActivityLogService $activityLogService,
        MealMenuService $mealMenuService
    ) {
        $this->activityLogService = $activityLogService;
        $this->mealMenuService = $mealMenuService;
    }

    /**
     * Display a listing of meal menus.
     */
    public function index(): JsonResponse
    {
        Gate::authorize('viewAny', MealMenu::class);

        $query = MealMenu::with(['classroom', 'creator']);

        // Filtreleme
        if (request()->has('menu_date_from')) {
            $query->where('menu_date', '>=', request('menu_date_from'));
        }

        if (request()->has('menu_date_to')) {
            $query->where('menu_date', '<=', request('menu_date_to'));
        }

        if (request()->has('meal_type')) {
            $query->where('meal_type', request('meal_type'));
        }

        if (request()->has('classroom_id')) {
            $query->where('classroom_id', request('classroom_id'));
        }

        if (request()->has('student_id')) {
            $studentId = request('student_id');
            $query->where(function ($q) use ($studentId) {
                $q->whereNull('classroom_id')
                    ->orWhereJsonContains('target_student_ids', $studentId)
                    ->orWhereHas('classroom', function ($classQ) use ($studentId) {
                        $classQ->whereHas('students', function ($studentQ) use ($studentId) {
                            $studentQ->where('students.id', $studentId);
                        });
                    });
            });
        }

        if (request()->has('published_only')) {
            $query->where('is_published', true);
        }

        // Sıralama
        $query->orderBy('menu_date', 'desc')
            ->orderBy('meal_type');

        $menus = $query->paginate(request('per_page', 50));

        return $this->success([
            'menus' => MealMenuResource::collection($menus),
            'pagination' => [
                'current_page' => $menus->currentPage(),
                'last_page' => $menus->lastPage(),
                'per_page' => $menus->perPage(),
                'total' => $menus->total(),
            ],
        ], 'Yemek menüleri başarıyla listelendi.');
    }

    /**
     * Store a newly created meal menu.
     */
    public function store(StoreMealMenuRequest $request, CreateMealMenuAction $action): JsonResponse
    {
        Gate::authorize('create', MealMenu::class);

        try {
            $menu = $action->execute($request->validated());

            return $this->success(new MealMenuResource($menu), 'Yemek menüsü başarıyla oluşturuldu.', 201);
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), [], 400);
        }
    }

    /**
     * Display the specified meal menu.
     */
    public function show(MealMenu $mealMenu): JsonResponse
    {
        Gate::authorize('view', $mealMenu);

        $mealMenu->load(['classroom', 'creator', 'attendances.student']);

        return $this->success(new MealMenuResource($mealMenu));
    }

    /**
     * Update the specified meal menu.
     */
    public function update(StoreMealMenuRequest $request, MealMenu $mealMenu): JsonResponse
    {
        Gate::authorize('update', $mealMenu);

        try {
            $mealMenu->update($request->validated());
            $this->activityLogService->logUpdate($mealMenu);

            return $this->success(new MealMenuResource($mealMenu->fresh()), 'Yemek menüsü başarıyla güncellendi.');
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), [], 400);
        }
    }

    /**
     * Remove the specified meal menu.
     */
    public function destroy(MealMenu $mealMenu): JsonResponse
    {
        Gate::authorize('delete', $mealMenu);

        $this->activityLogService->logDelete($mealMenu);
        $mealMenu->delete();

        return $this->success(null, 'Yemek menüsü başarıyla silindi.');
    }

    /**
     * Copy menu to other classrooms.
     */
    public function copyToClassrooms(MealMenu $mealMenu): JsonResponse
    {
        Gate::authorize('create', MealMenu::class);

        $targetClassroomIds = request('classroom_ids', []);

        if (empty($targetClassroomIds) || !is_array($targetClassroomIds)) {
            return $this->error('Sınıf ID\'leri gereklidir.', [], 400);
        }

        try {
            $copiedMenus = $this->mealMenuService->copyToClassrooms($mealMenu, $targetClassroomIds);

            return $this->success(
                MealMenuResource::collection($copiedMenus),
                count($copiedMenus) . ' sınıfa menü başarıyla kopyalandı.',
                201
            );
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), [], 400);
        }
    }

    /**
     * Record meal attendance.
     */
    public function recordAttendance(StoreMealAttendanceRequest $request): JsonResponse
    {
        Gate::authorize('create', MealAttendance::class);

        try {
            // Duplicate kontrolü
            $existing = MealAttendance::where('meal_menu_id', $request->meal_menu_id)
                ->where('student_id', $request->student_id)
                ->where('attendance_date', $request->attendance_date)
                ->where('meal_type', $request->meal_type)
                ->first();

            if ($existing) {
                // Güncelle
                $existing->update([
                    'status' => $request->status,
                    'notes' => $request->notes ?? null,
                ]);
                $this->activityLogService->logUpdate($existing);

                return $this->success(new MealAttendanceResource($existing->load(['student', 'mealMenu'])), 'Yemek yoklama kaydı başarıyla güncellendi.');
            }

            // Yeni kayıt
            $attendance = MealAttendance::create([
                'meal_menu_id' => $request->meal_menu_id,
                'student_id' => $request->student_id,
                'attendance_date' => $request->attendance_date,
                'meal_type' => $request->meal_type,
                'status' => $request->status,
                'notes' => $request->notes ?? null,
                'recorded_by' => auth()->id(),
            ]);

            $this->activityLogService->logCreate($attendance);

            return $this->success(new MealAttendanceResource($attendance->load(['student', 'mealMenu'])), 'Yemek yoklama kaydı başarıyla oluşturuldu.', 201);
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), [], 400);
        }
    }

    /**
     * Get meal attendance statistics.
     */
    public function getAttendanceStatistics(): JsonResponse
    {
        Gate::authorize('viewAny', MealAttendance::class);

        $dateFrom = request('date_from', Carbon::now()->startOfMonth()->format('Y-m-d'));
        $dateTo = request('date_to', Carbon::now()->endOfMonth()->format('Y-m-d'));
        $mealType = request('meal_type');

        $query = MealAttendance::whereBetween('attendance_date', [$dateFrom, $dateTo]);

        if ($mealType) {
            $query->where('meal_type', $mealType);
        }

        $total = $query->count();
        $present = $query->where('status', 'present')->count();
        $absent = $query->where('status', 'absent')->count();
        $excused = $query->where('status', 'excused')->count();

        $byMealType = MealAttendance::whereBetween('attendance_date', [$dateFrom, $dateTo])
            ->selectRaw('meal_type, COUNT(*) as total, SUM(CASE WHEN status = "present" THEN 1 ELSE 0 END) as present_count')
            ->groupBy('meal_type')
            ->pluck('present_count', 'meal_type');

        return $this->success([
            'period' => [
                'from' => $dateFrom,
                'to' => $dateTo,
            ],
            'total' => $total,
            'present' => $present,
            'absent' => $absent,
            'excused' => $excused,
            'by_meal_type' => $byMealType,
        ], 'Yemek yoklama istatistikleri başarıyla getirildi.');
    }
}
