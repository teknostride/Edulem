<?php

namespace App\Http\Controllers;

use App\Actions\CreateScheduledSmsAction;
use App\Http\Requests\StoreScheduledSmsRequest;
use App\Http\Resources\ScheduledSmsResource;
use App\Models\ScheduledSms;
use App\Services\ActivityLogService;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Gate;

class ScheduledSmsController extends ApiController
{
    protected ActivityLogService $activityLogService;

    public function __construct(ActivityLogService $activityLogService)
    {
        $this->activityLogService = $activityLogService;
    }

    /**
     * Display a listing of scheduled SMS.
     */
    public function index(): JsonResponse
    {
        Gate::authorize('viewAny', ScheduledSms::class);

        $query = ScheduledSms::with(['creator']);

        // Filtreleme
        if (request()->has('status')) {
            $query->where('status', request('status'));
        }

        if (request()->has('scheduled_from')) {
            $query->where('scheduled_at', '>=', request('scheduled_from'));
        }

        if (request()->has('scheduled_to')) {
            $query->where('scheduled_at', '<=', request('scheduled_to'));
        }

        $scheduledSms = $query->latest('scheduled_at')->paginate(request('per_page', 50));

        return $this->success([
            'scheduled_sms' => ScheduledSmsResource::collection($scheduledSms),
            'pagination' => [
                'current_page' => $scheduledSms->currentPage(),
                'last_page' => $scheduledSms->lastPage(),
                'per_page' => $scheduledSms->perPage(),
                'total' => $scheduledSms->total(),
            ],
        ], 'Planlı SMS\'ler başarıyla listelendi.');
    }

    /**
     * Store a newly created scheduled SMS.
     */
    public function store(StoreScheduledSmsRequest $request, CreateScheduledSmsAction $createAction): JsonResponse
    {
        Gate::authorize('create', ScheduledSms::class);

        $scheduledSms = $createAction->execute($request->validated());

        return $this->success(new ScheduledSmsResource($scheduledSms), 'Planlı SMS başarıyla oluşturuldu.', 201);
    }

    /**
     * Display the specified scheduled SMS.
     */
    public function show(ScheduledSms $scheduledSms): JsonResponse
    {
        Gate::authorize('view', $scheduledSms);

        $scheduledSms->load(['creator']);

        return $this->success(new ScheduledSmsResource($scheduledSms));
    }

    /**
     * Cancel a scheduled SMS.
     */
    public function cancel(ScheduledSms $scheduledSms): JsonResponse
    {
        Gate::authorize('cancel', $scheduledSms);

        if ($scheduledSms->status !== 'pending') {
            return $this->error('Sadece bekleyen SMS\'ler iptal edilebilir.', [], 400);
        }

        $scheduledSms->update(['status' => 'cancelled']);
        $this->activityLogService->logUpdate($scheduledSms);

        return $this->success(new ScheduledSmsResource($scheduledSms), 'Planlı SMS başarıyla iptal edildi.');
    }

    /**
     * Remove the specified scheduled SMS.
     */
    public function destroy(ScheduledSms $scheduledSms): JsonResponse
    {
        Gate::authorize('delete', $scheduledSms);

        $this->activityLogService->logDelete($scheduledSms);
        $scheduledSms->delete();

        return $this->success(null, 'Planlı SMS başarıyla silindi.');
    }
}
