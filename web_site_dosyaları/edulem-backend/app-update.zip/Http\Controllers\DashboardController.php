<?php

namespace App\Http\Controllers;

use App\Models\Student;
use App\Models\Classroom;
use App\Models\Lesson;
use App\Models\Payment;
use App\Models\Invoice;
use App\Models\Expense;
use App\Models\Tenant;
use App\Models\Attendance;
use App\Models\Campus;
use App\Models\EducationLevel;
use App\Models\Homework;
use App\Models\MealMenu;
use App\Models\DutySchedule;
use App\Models\User;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class DashboardController extends ApiController
{
    /**
     * Get dashboard statistics.
     * Eksik tablolar veya hata durumunda ilgili istatistik 0 döner, 500 hatası verilmez.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function stats(Request $request): JsonResponse
    {
        $user = $request->user();
        $roleName = $user && $user->role ? $user->role->name : null;

        $safeCount = function (string $table, $query): int {
            if (!Schema::hasTable($table)) {
                return 0;
            }
            try {
                return $query->count();
            } catch (\Throwable $e) {
                return 0;
            }
        };

        $stats = [
            'total_students' => $safeCount('students', Student::query()),
            'total_classrooms' => $safeCount('classrooms', Classroom::query()),
            'total_lessons' => $safeCount('lessons', Lesson::query()),
            'total_payments' => $safeCount('payments', Payment::query()),
            'total_invoices' => $safeCount('invoices', Invoice::query()),
            'total_expenses' => $this->safeSum('expenses', 'amount'), // Frontend balance için tutar
            'total_tenants' => $safeCount('tenants', Tenant::query()),
            'total_payments_amount' => $this->safeSum('payments', 'amount'),
            'recent_students' => $this->getRecentStudents(),
            'recent_payments' => [],
        ];

        if ($this->isStudentAffairsRole($roleName)) {
            $stats['student_affairs_analytics'] = $this->getStudentAffairsAnalytics($request);
        }

        if ($this->isManagerRole($roleName)) {
            $stats['manager_analytics'] = $this->getManagerAnalytics($request);
        }

        return $this->success(['stats' => $stats], 'Dashboard istatistikleri başarıyla getirildi.');
    }

    private function isStudentAffairsRole(?string $roleName): bool
    {
        return in_array($roleName, ['Öğrenci İşleri', 'student_affairs'], true);
    }

    private function isManagerRole(?string $roleName): bool
    {
        return in_array($roleName, ['Müdür', 'Müdür Yardımcısı', 'Kampüs Müdürü', 'Genel Müdür'], true);
    }

    private function applyManagerScopeToStudentsQuery(Builder $query, Request $request): Builder
    {
        $user = $request->user();
        if (!$user) {
            return $query;
        }

        if ($user->tenant_id) {
            $query->where('students.tenant_id', $user->tenant_id);
        }

        // Kurucu/superadmin tüm kurum; aksi durumda kampüs + kademe scope'u uygula
        if ($user->is_superadmin) {
            return $query;
        }

        $roleName = optional($user->role)->name;
        if (! $this->isManagerRole($roleName)) {
            return $query;
        }

        $campusIds = array_filter(array_map('intval', (array) ($user->campus_ids ?? [])));
        $educationLevelIds = array_filter(array_map('intval', (array) ($user->education_level_ids ?? [])));

        $educationLevelCodeOrIdValues = [];
        if (!empty($educationLevelIds)) {
            $educationLevelCodes = EducationLevel::query()
                ->when($user->tenant_id, fn (Builder $q) => $q->where('education_levels.tenant_id', $user->tenant_id))
                ->whereIn('id', $educationLevelIds)
                ->pluck('code')
                ->filter()
                ->map(fn ($v) => (string) $v)
                ->values()
                ->all();
            $educationLevelCodeOrIdValues = array_values(array_unique(array_merge(array_map('strval', $educationLevelIds), $educationLevelCodes)));
        }

        // Kampüs/kademe seçimi yoksa: tenant bazında bırak (fail-open)
        if (empty($campusIds) && empty($educationLevelIds)) {
            return $query;
        }

        return $query->whereHas('classroom', function (Builder $classroomQuery) use ($campusIds, $educationLevelCodeOrIdValues) {
            if (!empty($campusIds)) {
                $classroomQuery->whereHas('educationLevel', function (Builder $educationLevelQuery) use ($campusIds) {
                    $educationLevelQuery->whereIn('campus_id', $campusIds);
                });
            }

            if (!empty($educationLevelCodeOrIdValues)) {
                // classrooms.grade_level can be legacy (code) or FK-like (id stored as string)
                $classroomQuery->whereIn('grade_level', $educationLevelCodeOrIdValues);
            }
        });
    }

    private function applyManagerScopeToUsersQuery(Builder $query, Request $request): Builder
    {
        $user = $request->user();
        if (!$user) {
            return $query;
        }

        if ($user->tenant_id) {
            $query->where('users.tenant_id', $user->tenant_id);
        }

        if ($user->is_superadmin) {
            return $query;
        }

        $roleName = optional($user->role)->name;
        if (! $this->isManagerRole($roleName)) {
            return $query;
        }

        $campusIds = array_filter(array_map('intval', (array) ($user->campus_ids ?? [])));
        $educationLevelIds = array_filter(array_map('intval', (array) ($user->education_level_ids ?? [])));

        if (empty($campusIds) && empty($educationLevelIds)) {
            return $query;
        }

        return $query->where(function (Builder $scoped) use ($campusIds, $educationLevelIds) {
            if (!empty($campusIds)) {
                $scoped->where(function (Builder $q) use ($campusIds) {
                    foreach ($campusIds as $id) {
                        $q->orWhereJsonContains('campus_ids', $id);
                    }
                });
            }

            if (!empty($educationLevelIds)) {
                $scoped->where(function (Builder $q) use ($educationLevelIds) {
                    foreach ($educationLevelIds as $id) {
                        $q->orWhereJsonContains('education_level_ids', $id);
                    }
                });
            }
        });
    }

    private function getManagerAnalytics(Request $request): array
    {
        $user = $request->user();
        $tenantId = $user?->tenant_id;
        $campusIds = array_filter(array_map('intval', (array) ($user->campus_ids ?? [])));
        $educationLevelIds = array_filter(array_map('intval', (array) ($user->education_level_ids ?? [])));

        $educationLevelCodeOrIdValues = [];
        if (!empty($educationLevelIds)) {
            $educationLevelCodes = EducationLevel::query()
                ->when($tenantId, fn (Builder $q) => $q->where('education_levels.tenant_id', $tenantId))
                ->whereIn('id', $educationLevelIds)
                ->pluck('code')
                ->filter()
                ->map(fn ($v) => (string) $v)
                ->values()
                ->all();
            $educationLevelCodeOrIdValues = array_values(array_unique(array_merge(array_map('strval', $educationLevelIds), $educationLevelCodes)));
        }

        $scopedStudents = $this->applyManagerScopeToStudentsQuery(Student::query(), $request);

        $totalStudents = (clone $scopedStudents)->count();

        $studentsByEducationLevel = (clone $scopedStudents)
            ->from('students')
            ->join('classrooms', 'classrooms.id', '=', 'students.classroom_id')
            ->leftJoin('education_levels', function ($join) {
                $join->on('education_levels.id', '=', 'classrooms.grade_level')
                    ->orOn('education_levels.code', '=', 'classrooms.grade_level');
            })
            ->when($tenantId, function (Builder $q) use ($tenantId) {
                $q->where('students.tenant_id', $tenantId)
                    ->where('classrooms.tenant_id', $tenantId)
                    ->where(function (Builder $eq) use ($tenantId) {
                        $eq->whereNull('education_levels.tenant_id')
                            ->orWhere('education_levels.tenant_id', $tenantId);
                    });
            })
            ->selectRaw('education_levels.id as education_level_id, COALESCE(education_levels.name, ?) as education_level_name, COUNT(students.id) as student_count', ['Tanımsız Kademe'])
            ->groupBy('education_levels.id', 'education_levels.name')
            ->orderByDesc('student_count')
            ->get()
            ->map(fn ($row) => [
                'education_level_id' => $row->education_level_id,
                'education_level_name' => $row->education_level_name,
                'student_count' => (int) $row->student_count,
            ])
            ->values()
            ->all();

        // Scoped teacher count
        // - Eğer müdürde scope yoksa (campus_ids / education_level_ids boş): tenant içindeki tüm aktif öğretmenleri say.
        // - Scope varsa: öğretmenleri iki kaynaktan yakala (union)
        //   1) Öğretmenin kendi JSON alanları (campus_ids / education_level_ids)
        //   2) Sınıf ataması (classrooms.teacher_id) scope'a uyan sınıflar
        $teacherRoleNames = ['Öğretmen', 'Sınıf Öğretmeni'];

        $teachersBase = User::query()
            ->when($tenantId, fn (Builder $q) => $q->where('users.tenant_id', $tenantId))
            ->where('is_active', true)
            ->whereHas('role', fn (Builder $q) => $q->whereIn('name', $teacherRoleNames));

        if (empty($campusIds) && empty($educationLevelIds)) {
            $totalTeachers = (clone $teachersBase)->count();
        } else {
            // Classroom teacher IDs in scope
            $scopedClassrooms = Classroom::query()
                ->when($tenantId, fn (Builder $q) => $q->where('classrooms.tenant_id', $tenantId))
                ->whereNotNull('teacher_id');

            if (!empty($educationLevelCodeOrIdValues)) {
                $scopedClassrooms->whereIn('grade_level', $educationLevelCodeOrIdValues);
            }

            if (!empty($campusIds)) {
                $scopedClassrooms->whereHas('educationLevel', fn (Builder $q) => $q->whereIn('campus_id', $campusIds));
            }

            $classroomTeacherIds = $scopedClassrooms
                ->distinct()
                ->pluck('teacher_id')
                ->filter()
                ->map(fn ($v) => (int) $v)
                ->values()
                ->all();

            $teachersScoped = (clone $teachersBase)->where(function (Builder $q) use ($campusIds, $educationLevelIds, $classroomTeacherIds) {
                $hasAny = false;

                if (!empty($classroomTeacherIds)) {
                    $q->whereIn('users.id', $classroomTeacherIds);
                    $hasAny = true;
                }

                if (!empty($campusIds)) {
                    $q->orWhere(function (Builder $sub) use ($campusIds) {
                        foreach ($campusIds as $id) {
                            $sub->orWhereJsonContains('campus_ids', $id);
                        }
                    });
                    $hasAny = true;
                }

                if (!empty($educationLevelIds)) {
                    $q->orWhere(function (Builder $sub) use ($educationLevelIds) {
                        foreach ($educationLevelIds as $id) {
                            $sub->orWhereJsonContains('education_level_ids', $id);
                        }
                    });
                    $hasAny = true;
                }

                if (!$hasAny) {
                    // Safeguard: hiçbir scope koşulu eklenmediyse filtreleme yapma
                    $q->whereRaw('1=1');
                }
            });

            $totalTeachers = $teachersScoped->distinct('users.id')->count('users.id');
        }

        $today = Carbon::today()->toDateString();
        $todayDayOfWeek = Carbon::today()->englishDayOfWeek;

        // Today's meal menus (published)
        $menusQuery = MealMenu::query()
            ->with(['classroom'])
            ->when($tenantId, fn (Builder $q) => $q->where('meal_menus.tenant_id', $tenantId))
            ->whereDate('menu_date', $today)
            ->where('is_published', true);

        // Scope menus by classrooms in manager scope (if scope exists)
        if (!empty($campusIds) || !empty($educationLevelCodeOrIdValues)) {
            $menusQuery->where(function (Builder $q) use ($campusIds, $educationLevelCodeOrIdValues) {
                $q->whereNull('classroom_id');
                $q->orWhereHas('classroom', function (Builder $cq) use ($campusIds, $educationLevelCodeOrIdValues) {
                    if (!empty($campusIds)) {
                        $cq->whereHas('educationLevel', fn (Builder $eq) => $eq->whereIn('campus_id', $campusIds));
                    }
                    if (!empty($educationLevelCodeOrIdValues)) {
                        $cq->whereIn('grade_level', $educationLevelCodeOrIdValues);
                    }
                });
            });
        }

        $todayMenus = $menusQuery
            ->orderBy('meal_type')
            ->get()
            ->map(fn (MealMenu $m) => [
                'id' => $m->id,
                'menu_date' => $m->menu_date?->toDateString(),
                'meal_type' => $m->meal_type,
                'meals' => $m->meals,
                'notes' => $m->notes,
                'classroom' => $m->classroom ? [
                    'id' => $m->classroom->id,
                    'name' => $m->classroom->name,
                ] : null,
            ])
            ->values()
            ->all();

        // Latest homeworks in scope (5)
        $homeworkQuery = Homework::query()
            ->with(['classroom', 'teacher', 'lesson'])
            ->when($tenantId, fn (Builder $q) => $q->where('homeworks.tenant_id', $tenantId));

        if (!empty($campusIds) || !empty($educationLevelCodeOrIdValues)) {
            $homeworkQuery->whereHas('classroom', function (Builder $cq) use ($campusIds, $educationLevelCodeOrIdValues) {
                if (!empty($campusIds)) {
                    $cq->whereHas('educationLevel', fn (Builder $eq) => $eq->whereIn('campus_id', $campusIds));
                }
                if (!empty($educationLevelCodeOrIdValues)) {
                    $cq->whereIn('grade_level', $educationLevelCodeOrIdValues);
                }
            });
        }

        $recentHomeworks = $homeworkQuery
            ->orderByDesc('created_at')
            ->limit(5)
            ->get()
            ->map(fn (Homework $hw) => [
                'id' => $hw->id,
                'title' => $hw->title,
                'due_date' => $hw->due_date?->toDateString(),
                'created_at' => $hw->created_at?->toIso8601String(),
                'classroom' => $hw->classroom ? [
                    'id' => $hw->classroom->id,
                    'name' => $hw->classroom->name,
                ] : null,
                'teacher' => $hw->teacher ? [
                    'id' => $hw->teacher->id,
                    'name' => $hw->teacher->name,
                ] : null,
                'lesson' => $hw->lesson ? [
                    'id' => $hw->lesson->id,
                    'name' => $hw->lesson->name,
                ] : null,
            ])
            ->values()
            ->all();

        // Today's duty schedules (not scoped by campus/education level because model has no campus field)
        $todayDuties = DutySchedule::query()
            ->with(['user'])
            ->when($tenantId, fn (Builder $q) => $q->where('duty_schedules.tenant_id', $tenantId))
            ->where('is_active', true)
            ->where('day_of_week', $todayDayOfWeek)
            ->orderBy('start_time')
            ->get()
            ->map(fn (DutySchedule $d) => [
                'id' => $d->id,
                'day_of_week' => $d->day_of_week,
                'start_time' => $d->start_time,
                'end_time' => $d->end_time,
                'location' => $d->location,
                'notes' => $d->notes,
                'user' => $d->user ? [
                    'id' => $d->user->id,
                    'name' => $d->user->name,
                ] : null,
            ])
            ->values()
            ->all();

        return [
            'scope' => [
                'campus_ids' => array_values($campusIds),
                'education_level_ids' => array_values($educationLevelIds),
            ],
            'totals' => [
                'total_students' => $totalStudents,
                'total_teachers' => $totalTeachers,
            ],
            'students_by_education_level' => $studentsByEducationLevel,
            'today_meal_menus' => $todayMenus,
            'recent_homeworks' => $recentHomeworks,
            'today_duty_schedules' => $todayDuties,
        ];
    }

    private function applyStudentAffairsScope(Builder $query, Request $request): Builder
    {
        $user = $request->user();
        if (!$user) {
            return $query;
        }

        if ($user->tenant_id) {
            $query->where('students.tenant_id', $user->tenant_id);
        }

        if ($user->is_superadmin || !$this->isStudentAffairsRole(optional($user->role)->name)) {
            return $query;
        }

        $campusIds = array_filter(array_map('intval', (array) ($user->campus_ids ?? [])));
        $educationLevelIds = array_filter(array_map('intval', (array) ($user->education_level_ids ?? [])));

        return $query->whereHas('classroom', function (Builder $classroomQuery) use ($campusIds, $educationLevelIds) {
            if (!empty($campusIds)) {
                $classroomQuery->whereHas('educationLevel', function (Builder $educationLevelQuery) use ($campusIds) {
                    $educationLevelQuery->whereIn('campus_id', $campusIds);
                });
            }

            if (!empty($educationLevelIds)) {
                $classroomQuery->whereIn('grade_level', $educationLevelIds);
            }
        });
    }

    private function getStudentAffairsAnalytics(Request $request): array
    {
        $user = $request->user();
        $campusIds = array_filter(array_map('intval', (array) ($user->campus_ids ?? [])));
        $educationLevelIds = array_filter(array_map('intval', (array) ($user->education_level_ids ?? [])));

        $scopedStudents = $this->applyStudentAffairsScope(Student::query(), $request);

        $totalStudents = (clone $scopedStudents)->count();
        $activeStudents = (clone $scopedStudents)->where('is_active', true)->count();
        $inactiveStudents = (clone $scopedStudents)->where('is_active', false)->count();

        $attendanceStatusCounts = Attendance::query()
            ->whereDate('date', Carbon::today()->toDateString())
            ->whereIn('student_id', (clone $scopedStudents)->select('id'))
            ->selectRaw('status, COUNT(*) as total')
            ->groupBy('status')
            ->pluck('total', 'status');

        $absentToday = (int) ($attendanceStatusCounts['absent'] ?? 0);
        $presentToday = (int) ($attendanceStatusCounts['present'] ?? 0);
        $lateToday = (int) ($attendanceStatusCounts['late'] ?? 0);
        $excusedToday = (int) ($attendanceStatusCounts['excused'] ?? 0);
        $sickToday = (int) ($attendanceStatusCounts['sick'] ?? 0);
        $attendanceTotal = $presentToday + $absentToday + $lateToday + $excusedToday + $sickToday;

        $studentsByEducationLevel = (clone $scopedStudents)
            ->join('classrooms', 'classrooms.id', '=', 'students.classroom_id')
            ->leftJoin('education_levels', 'education_levels.id', '=', 'classrooms.grade_level')
            ->selectRaw('education_levels.id as education_level_id, COALESCE(education_levels.name, ?) as education_level_name, COUNT(students.id) as student_count', ['Tanımsız Kademe'])
            ->groupBy('education_levels.id', 'education_levels.name')
            ->orderByDesc('student_count')
            ->get()
            ->map(fn ($row) => [
                'education_level_id' => $row->education_level_id,
                'education_level_name' => $row->education_level_name,
                'student_count' => (int) $row->student_count,
            ])
            ->values()
            ->all();

        $studentsByClassroom = (clone $scopedStudents)
            ->join('classrooms', 'classrooms.id', '=', 'students.classroom_id')
            ->selectRaw('classrooms.id as classroom_id, classrooms.name as classroom_name, COUNT(students.id) as student_count')
            ->groupBy('classrooms.id', 'classrooms.name')
            ->orderByDesc('student_count')
            ->limit(12)
            ->get()
            ->map(fn ($row) => [
                'classroom_id' => $row->classroom_id,
                'classroom_name' => $row->classroom_name,
                'student_count' => (int) $row->student_count,
            ])
            ->values()
            ->all();

        return [
            'scope' => [
                'campuses' => Campus::query()
                    ->where('tenant_id', $user->tenant_id)
                    ->when(!empty($campusIds), fn ($query) => $query->whereIn('id', $campusIds))
                    ->orderBy('name')
                    ->get(['id', 'name'])
                    ->map(fn ($campus) => ['id' => $campus->id, 'name' => $campus->name])
                    ->values()
                    ->all(),
                'education_levels' => EducationLevel::query()
                    ->where('tenant_id', $user->tenant_id)
                    ->when(!empty($educationLevelIds), fn ($query) => $query->whereIn('id', $educationLevelIds))
                    ->orderBy('sort_order')
                    ->orderBy('name')
                    ->get(['id', 'name'])
                    ->map(fn ($educationLevel) => ['id' => $educationLevel->id, 'name' => $educationLevel->name])
                    ->values()
                    ->all(),
            ],
            'totals' => [
                'total_students' => $totalStudents,
                'active_students' => $activeStudents,
                'inactive_students' => $inactiveStudents,
            ],
            'attendance_today' => [
                'date' => Carbon::today()->toDateString(),
                'present' => $presentToday,
                'absent' => $absentToday,
                'late' => $lateToday,
                'excused' => $excusedToday,
                'sick' => $sickToday,
                'total_records' => $attendanceTotal,
                'absence_rate' => $attendanceTotal > 0 ? round(($absentToday / $attendanceTotal) * 100, 2) : 0,
            ],
            'students_by_education_level' => $studentsByEducationLevel,
            'students_by_classroom' => $studentsByClassroom,
        ];
    }

    private function safeSum(string $table, string $column): float
    {
        if (!Schema::hasTable($table)) {
            return 0;
        }
        try {
            return (float) DB::table($table)->sum($column);
        } catch (\Throwable $e) {
            return 0;
        }
    }

    private function getRecentStudents(): array
    {
        if (!Schema::hasTable('students')) {
            return [];
        }
        try {
            return Student::query()
                ->orderByDesc('created_at')
                ->limit(5)
                ->get()
                ->map(fn ($s) => [
                    'id' => $s->id,
                    'name' => $s->name,
                    'school_no' => $s->school_no ?? '',
                    'created_at' => $s->created_at?->toIso8601String(),
                ])
                ->all();
        } catch (\Throwable $e) {
            return [];
        }
    }
}
