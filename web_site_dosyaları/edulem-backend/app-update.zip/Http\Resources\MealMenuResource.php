<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class MealMenuResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'menu_date' => $this->menu_date?->format('Y-m-d'),
            'meal_type' => $this->meal_type,
            'meals' => $this->meals,
            'target_student_ids' => $this->target_student_ids,
            'classroom' => $this->whenLoaded('classroom', fn() => new ClassroomResource($this->classroom)),
            'notes' => $this->notes,
            'is_published' => $this->is_published,
            'is_published_check' => $this->isPublished(),
            'creator' => $this->whenLoaded('creator', fn() => [
                'id' => $this->creator->id,
                'name' => $this->creator->name,
            ]),
            'attendances' => MealAttendanceResource::collection($this->whenLoaded('attendances')),
            'created_at' => $this->created_at?->toISOString(),
            'updated_at' => $this->updated_at?->toISOString(),
        ];
    }
}
