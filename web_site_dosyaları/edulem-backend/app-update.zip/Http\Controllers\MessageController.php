<?php

namespace App\Http\Controllers;

use App\Models\Message;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;

class MessageController extends ApiController
{
    /**
     * Kullanıcının konuşmalarını getirir (WhatsApp mantığı).
     * Son mesaj tarihine göre üstten alta sıralı; mesajı olanlar üstte.
     * Mesajı olmayan kullanıcılar frontend'de /users ile alınıp en altta listelenir.
     */
    public function getConversations(Request $request): JsonResponse
    {
        try {
            $user = $request->user();
            if (!$user) {
                return $this->error('Oturum açmanız gerekiyor.', [], 401);
            }
            $userId = $user->id;

            $latest = Message::query()
                ->selectRaw('MAX(id) as last_message_id')
                ->selectRaw('CASE WHEN sender_id = ? THEN receiver_id ELSE sender_id END as other_user_id', [$userId])
                ->where(function ($query) use ($userId) {
                    $query->where('sender_id', $userId)->orWhere('receiver_id', $userId);
                })
                ->whereNotNull(DB::raw('CASE WHEN sender_id = ' . (int) $userId . ' THEN receiver_id ELSE sender_id END'))
                ->groupBy('other_user_id')
                ->orderByDesc('last_message_id')
                ->limit(50)
                ->get();

            $lastMessageIds = $latest->pluck('last_message_id')->filter()->values()->all();
            if (empty($lastMessageIds)) {
                return $this->success([
                    'conversations' => [],
                    'current_user_id' => $userId,
                ], 'Konuşmalar getirildi.');
            }

            $lastMessages = Message::query()
                ->whereIn('id', $lastMessageIds)
                ->with(['sender', 'receiver'])
                ->get()
                ->keyBy('id');

            $otherUserIds = $latest->pluck('other_user_id')->filter()->unique()->values()->all();
            $unreadCounts = Message::query()
                ->selectRaw('sender_id, COUNT(*) as cnt')
                ->where('receiver_id', $userId)
                ->where('is_read', false)
                ->whereIn('sender_id', $otherUserIds)
                ->groupBy('sender_id')
                ->pluck('cnt', 'sender_id');

            $conversations = [];
            foreach ($latest as $row) {
                $otherUserId = (int) $row->other_user_id;
                $message = $lastMessages->get((int) $row->last_message_id);
                if (!$message) {
                    continue;
                }

                $otherUser = (int) $message->sender_id === (int) $userId ? $message->receiver : $message->sender;
                if (!$otherUser) {
                    continue;
                }

                $displayName = trim(($otherUser->first_name ?? '') . ' ' . ($otherUser->last_name ?? '')) ?: ($otherUser->email ?? 'Kullanıcı');
                $conversations[] = [
                    'id' => $otherUserId,
                    'user' => [
                        'id' => $otherUser->id,
                        'first_name' => $otherUser->first_name ?? '',
                        'last_name' => $otherUser->last_name ?? '',
                        'email' => $otherUser->email ?? '',
                        'avatar' => 'https://ui-avatars.com/api/?name=' . urlencode($displayName) . '&background=random',
                        'is_online' => false,
                    ],
                    'last_message' => [
                        'id' => $message->id,
                        'sender_id' => $message->sender_id,
                        'receiver_id' => $message->receiver_id,
                        'content' => $message->content,
                        'created_at' => $message->created_at->toISOString(),
                        'is_read' => $message->is_read,
                    ],
                    'unread_count' => (int) ($unreadCounts[$otherUserId] ?? 0),
                    'updated_at' => $message->created_at->toISOString(),
                ];
            }

            usort($conversations, function ($a, $b) {
                return strcmp($b['updated_at'], $a['updated_at']);
            });

            return $this->success([
                'conversations' => $conversations,
                'current_user_id' => $userId,
            ], 'Konuşmalar getirildi.');
        } catch (\Exception $e) {
            return $this->error('Konuşmalar getirilirken bir hata oluştu: ' . $e->getMessage(), [], 500);
        }
    }

    /**
     * Get messages between two users
     */
    public function getMessages(Request $request): JsonResponse
    {
        try {
            $user = $request->user();
            $userId = $user->id;
            $otherUserId = $request->get('user_id');

            if (!$otherUserId) {
                return $this->error('Kullanıcı ID zorunludur.', [], 400);
            }

            $messages = Message::where(function ($query) use ($userId, $otherUserId) {
                $query->where(function ($subQuery) use ($userId, $otherUserId) {
                    $subQuery->where('sender_id', $userId)
                        ->where('receiver_id', $otherUserId);
                })->orWhere(function ($subQuery) use ($userId, $otherUserId) {
                    $subQuery->where('sender_id', $otherUserId)
                        ->where('receiver_id', $userId);
                });
            })
            ->with(['sender', 'receiver'])
            ->orderBy('created_at', 'asc')
            ->get()
            ->map(function ($message) {
                return [
                    'id' => $message->id,
                    'sender_id' => $message->sender_id,
                    'receiver_id' => $message->receiver_id,
                    'content' => $message->content,
                    'created_at' => $message->created_at->toISOString(),
                    'is_read' => $message->is_read,
                ];
            });

            // Mark messages as read
            Message::where('sender_id', $otherUserId)
                ->where('receiver_id', $userId)
                ->where('is_read', false)
                ->update(['is_read' => true, 'read_at' => now()]);

            return $this->success($messages->toArray(), 'Mesajlar başarıyla getirildi.');
        } catch (\Exception $e) {
            return $this->error('Mesajlar getirilirken bir hata oluştu: ' . $e->getMessage(), [], 500);
        }
    }

    /**
     * Send a new message
     */
    public function sendMessage(Request $request): JsonResponse
    {
        try {
            $request->validate([
                'receiver_id' => 'required|exists:users,id',
                'content' => 'required|string|max:1000',
            ]);

            $user = $request->user();

            $message = Message::create([
                'sender_id' => $user->id,
                'receiver_id' => $request->receiver_id,
                'content' => $request->content,
                'is_read' => false,
            ]);

            $message->load(['sender', 'receiver']);

            return $this->success([
                'id' => $message->id,
                'sender_id' => $message->sender_id,
                'receiver_id' => $message->receiver_id,
                'content' => $message->content,
                'created_at' => $message->created_at->toISOString(),
                'is_read' => $message->is_read,
            ], 'Mesaj başarıyla gönderildi.');
        } catch (\Exception $e) {
            return $this->error('Mesaj gönderilirken bir hata oluştu: ' . $e->getMessage(), [], 500);
        }
    }

    /**
     * Get unread message count
     */
    public function getUnreadCount(Request $request): JsonResponse
    {
        try {
            $user = $request->user();
            $unreadCount = Message::where('receiver_id', $user->id)
                ->where('is_read', false)
                ->count();

            return $this->success(['unread_count' => $unreadCount], 'Okunmamış mesaj sayısı getirildi.');
        } catch (\Exception $e) {
            return $this->error('Okunmamış mesaj sayısı getirilirken bir hata oluştu: ' . $e->getMessage(), [], 500);
        }
    }

    /**
     * Mark message as read
     */
    public function markAsRead(Request $request, $id): JsonResponse
    {
        try {
            $user = $request->user();
            $message = Message::where('id', $id)
                ->where('receiver_id', $user->id)
                ->firstOrFail();

            $message->markAsRead();

            return $this->success([], 'Mesaj okundu olarak işaretlendi.');
        } catch (\Exception $e) {
            return $this->error('Mesaj işaretlenirken bir hata oluştu: ' . $e->getMessage(), [], 500);
        }
    }
}
