<?php

namespace App\Http\Controllers;

use Illuminate\Http\JsonResponse;

abstract class ApiController extends Controller
{
    /**
     * Success response.
     *
     * @param  mixed  $data
     * @param  string  $message
     * @param  int  $statusCode
     * @return \Illuminate\Http\JsonResponse
     */
    protected function success(mixed $data = [], string $message = 'İşlem başarılı.', int $statusCode = 200): JsonResponse
    {
        return response()->json([
            'status' => true,
            'data' => $data,
            'message' => $message,
        ], $statusCode);
    }

    /**
     * Error response.
     *
     * @param  string  $message
     * @param  mixed  $errors
     * @param  int  $statusCode
     * @return \Illuminate\Http\JsonResponse
     */
    protected function error(string $message = 'Bir hata oluştu.', mixed $errors = [], int $statusCode = 400): JsonResponse
    {
        $response = [
            'status' => false,
            'data' => [],
            'message' => $message,
        ];

        if (!empty($errors)) {
            $response['errors'] = $errors;
        }

        return response()->json($response, $statusCode);
    }

    /**
     * Paginated response.
     *
     * @param  \Illuminate\Contracts\Pagination\LengthAwarePaginator  $paginator
     * @param  string  $message
     * @return \Illuminate\Http\JsonResponse
     */
    protected function paginated($paginator, string $message = 'İşlem başarılı.'): JsonResponse
    {
        return response()->json([
            'status' => true,
            'data' => $paginator->items(),
            'pagination' => [
                'current_page' => $paginator->currentPage(),
                'last_page' => $paginator->lastPage(),
                'per_page' => $paginator->perPage(),
                'total' => $paginator->total(),
            ],
            'message' => $message,
        ], 200);
    }
}
