<?php

namespace App\Http\Controllers;

use App\Actions\BulkCreateAttendanceAction;
use App\Actions\CreateAttendanceAction;
use App\Actions\UpdateAttendanceAction;
use App\Http\Requests\BulkAttendanceRequest;
use App\Http\Requests\StoreAttendanceRequest;
use App\Http\Requests\UpdateAttendanceRequest;
use App\Http\Resources\AttendanceResource;
use App\Models\Attendance;
use App\Models\Schedule;
use App\Services\ActivityLogService;
use Carbon\Carbon;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;

class AttendanceController extends ApiController
{
    protected ActivityLogService $activityLogService;

    public function __construct(ActivityLogService $activityLogService)
    {
        $this->activityLogService = $activityLogService;
    }

    /**
     * Günlük yoklama takip verisi (Yoklama Takibi sayfası için).
     * Tarihe göre o günkü dersleri, yoklama alınıp alınmadığını, devamsız öğrencileri döndürür.
     */
    public function dailyTracking(Request $request): JsonResponse
    {
        Gate::authorize('viewAny', Attendance::class);

        $user = auth()->user();
        $tenantId = $user->tenant_id ?? null;
        if (!$tenantId) {
            return $this->error('Kurum bilgisi bulunamadı.', [], 400);
        }

        $date = $request->input('date', now()->toDateString());
        $date = Carbon::parse($date)->toDateString();
        $educationLevelId = $request->input('education_level_id') ? (int) $request->input('education_level_id') : null;
        $roleName = $user->role ? $user->role->name : null;
        $teacherOnlyRoles = ['Öğretmen', 'Sınıf Öğretmeni', 'Rehberlik'];
        $trackingRolesRequireKademe = ['owner', 'Genel Müdür', 'Kampüs Müdürü', 'Müdür', 'Müdür Yardımcısı', 'Öğrenci İşleri'];

        $dayOfWeek = strtolower(Carbon::parse($date)->locale('en')->dayName);
        $gunAdi = (function () use ($date) {
            $map = ['Monday' => 'Pazartesi', 'Tuesday' => 'Salı', 'Wednesday' => 'Çarşamba', 'Thursday' => 'Perşembe', 'Friday' => 'Cuma', 'Saturday' => 'Cumartesi', 'Sunday' => 'Pazar'];
            return $map[Carbon::parse($date)->locale('en')->dayName] ?? $date;
        })();
        $haftaSonu = in_array($dayOfWeek, ['saturday', 'sunday'], true);

        $scheduleQuery = Schedule::with(['classroom' => function ($q) {
            $q->with(['educationLevel', 'branch']);
        }, 'lesson', 'teacher'])
            ->where('tenant_id', $tenantId)
            ->where('day_of_week', $dayOfWeek)
            ->orderBy('start_time');

        $isTeacherOnly = $roleName && in_array($roleName, $teacherOnlyRoles, true);
        if ($isTeacherOnly) {
            $scheduleQuery->where('teacher_id', $user->id);
        } else {
            if (!$user->is_superadmin && $user->role && in_array($user->role->name, ['Müdür', 'Müdür Yardımcısı', 'Öğrenci İşleri'], true)) {
                $campusIds = array_filter(array_map('intval', (array) ($user->campus_ids ?? [])));
                $educationLevelIds = array_filter(array_map('intval', (array) ($user->education_level_ids ?? [])));
                $scheduleQuery->whereHas('classroom', function ($q) use ($campusIds, $educationLevelIds) {
                    if (!empty($campusIds)) {
                        $q->whereHas('educationLevel', function ($qEl) use ($campusIds) {
                            $qEl->whereIn('campus_id', $campusIds);
                        });
                    }
                    if (!empty($educationLevelIds)) {
                        $q->whereIn('grade_level', $educationLevelIds);
                    }
                });
            }
            if ($educationLevelId) {
                $scheduleQuery->whereHas('classroom', fn ($q) => $q->where('grade_level', $educationLevelId));
            } elseif ($roleName && in_array($roleName, $trackingRolesRequireKademe, true)) {
                $schedules = collect();
                $dersler = [];
                $istatistikler = ['toplam_ders' => 0, 'alinan_yoklama' => 0];
                $gelmeyenOgrenciler = [];
                return $this->success([
                    'gun' => $gunAdi,
                    'tarih' => $date,
                    'hafta_sonu' => $haftaSonu,
                    'dersler' => $dersler,
                    'istatistikler' => $istatistikler,
                    'gelmeyen_ogrenciler' => $gelmeyenOgrenciler,
                    'kademe_secimi_gerekli' => true,
                ], 'Yoklama takibi için kademe seçin.');
            }
        }

        $schedules = $scheduleQuery->get();
        $slotOrder = 0;
        $dersler = [];
        foreach ($schedules as $schedule) {
            $slotOrder++;
            $classroom = $schedule->classroom;
            $sinifTamAdi = $classroom ? ($classroom->name . ($classroom->educationLevel ? ' - ' . $classroom->educationLevel->name : '')) : '-';
            $teacherName = $schedule->teacher ? (trim(($schedule->teacher->first_name ?? '') . ' ' . ($schedule->teacher->last_name ?? '')) ?: ($schedule->teacher->name ?? '-')) : '-';

            $attendanceCount = Attendance::where('schedule_id', $schedule->id)->whereDate('date', $date)->count();
            $yoklamaAlindi = $attendanceCount > 0;
            $yoklamaOzet = null;
            if ($yoklamaAlindi) {
                $byStatus = Attendance::where('schedule_id', $schedule->id)->whereDate('date', $date)->selectRaw('status, count(*) as cnt')->groupBy('status')->pluck('cnt', 'status')->toArray();
                $yoklamaOzet = [
                    'geldi_sayisi' => (int) ($byStatus['present'] ?? 0),
                    'gelmedi_sayisi' => (int) ($byStatus['absent'] ?? 0),
                    'izinli_sayisi' => (int) ($byStatus['excused'] ?? 0),
                    'raporlu_sayisi' => (int) ($byStatus['sick'] ?? 0),
                    'gec_sayisi' => (int) ($byStatus['late'] ?? 0),
                ];
            }

            $dersler[] = [
                'schedule_id' => $schedule->id,
                'ders_adi' => $schedule->lesson ? $schedule->lesson->name : 'Ders',
                'sinif_tam_adi' => $sinifTamAdi,
                'sinif_mevcudu' => $classroom ? (int) $classroom->capacity : 0,
                'ogretmen_adi' => $teacherName,
                'saat' => $slotOrder,
                'yoklama_alindi' => $yoklamaAlindi,
                'yoklama_ozet' => $yoklamaOzet,
            ];
        }

        $istatistikler = [
            'toplam_ders' => count($dersler),
            'alinan_yoklama' => collect($dersler)->where('yoklama_alindi', true)->count(),
        ];

        $absentQuery = Attendance::with(['student' => function ($q) {
            $q->with(['classroom' => function ($q2) {
                $q2->with(['educationLevel', 'branch']);
            }, 'guardians']);
        }, 'schedule.lesson'])
            ->where('tenant_id', $tenantId)
            ->whereDate('date', $date)
            ->where('status', '!=', 'present');

        if ($isTeacherOnly) {
            $absentQuery->whereHas('schedule', fn ($q) => $q->where('teacher_id', $user->id));
        } else {
            if (!$user->is_superadmin && $user->role && in_array($user->role->name, ['Müdür', 'Müdür Yardımcısı', 'Öğrenci İşleri'], true)) {
                $campusIds = array_filter(array_map('intval', (array) ($user->campus_ids ?? [])));
                $educationLevelIds = array_filter(array_map('intval', (array) ($user->education_level_ids ?? [])));
                $absentQuery->whereHas('student.classroom', function ($q) use ($campusIds, $educationLevelIds) {
                    if (!empty($campusIds)) {
                        $q->whereHas('educationLevel', function ($qEl) use ($campusIds) {
                            $qEl->whereIn('campus_id', $campusIds);
                        });
                    }
                    if (!empty($educationLevelIds)) {
                        $q->whereIn('grade_level', $educationLevelIds);
                    }
                });
            }
            if ($educationLevelId) {
                $absentQuery->whereHas('student.classroom', fn ($q) => $q->where('grade_level', $educationLevelId));
            }
        }

        $absentList = $absentQuery->get();
        $gelmeyenOgrenciler = [];
        $slotBySchedule = array_flip(array_column($dersler, 'schedule_id'));
        foreach ($absentList as $a) {
            $student = $a->student;
            $classroom = $student && $student->classroom ? $student->classroom : null;
            $sinifTamAdi = $classroom ? ($classroom->name . ($classroom->educationLevel ? ' - ' . $classroom->educationLevel->name : '')) : '-';
            $veli = $student && $student->guardians->isNotEmpty() ? $student->guardians->first() : null;
            $gelmeyenOgrenciler[] = [
                'ogrenci_adi' => $student ? $student->name : '-',
                'okul_no' => $student ? $student->school_no : '',
                'sinif_tam_adi' => $sinifTamAdi,
                'ders_adi' => $a->schedule && $a->schedule->lesson ? $a->schedule->lesson->name : 'Ders',
                'ders_saati' => $slotBySchedule[$a->schedule_id] ?? 0,
                'durum' => $a->status === 'late' ? 'gc' : ($a->status === 'excused' ? 'izinli' : ($a->status === 'sick' ? 'raporlu' : 'gelmedi')),
                'veli_adi' => $veli ? $veli->name : null,
                'veli_telefon' => $veli ? $veli->phone : null,
            ];
        }

        return $this->success([
            'gun' => $gunAdi,
            'tarih' => $date,
            'hafta_sonu' => $haftaSonu,
            'dersler' => $dersler,
            'istatistikler' => $istatistikler,
            'gelmeyen_ogrenciler' => $gelmeyenOgrenciler,
        ], 'Günlük yoklama takip verisi getirildi.');
    }

    /**
     * Display a listing of attendances.
     */
    public function index(): JsonResponse
    {
        Gate::authorize('viewAny', Attendance::class);

        $user = auth()->user();
        $roleName = $user && $user->role ? $user->role->name : null;
        $teacherOnlyRoles = ['Öğretmen', 'Sınıf Öğretmeni', 'Rehberlik'];
        $isTeacherOnly = $roleName && in_array($roleName, $teacherOnlyRoles, true);

        $query = Attendance::with(['student', 'schedule' => function ($q) {
            $q->with('lesson');
        }, 'teacher']);

        if ($user && $user->tenant_id) {
            $query->where('tenant_id', $user->tenant_id);
        }

        if ($isTeacherOnly) {
            $query->whereHas('schedule', fn ($q) => $q->where('teacher_id', $user->id));
        }

        // Filtreleme
        if (request()->has('student_id')) {
            $query->where('student_id', request('student_id'));
        }

        if (request()->has('classroom_id')) {
            $query->whereHas('student', function ($q) {
                $q->where('classroom_id', request('classroom_id'));
            });
        }

        if (request()->has('date_from')) {
            $query->where('date', '>=', request('date_from'));
        }

        if (request()->has('date_to')) {
            $query->where('date', '<=', request('date_to'));
        }

        if (request()->has('status')) {
            $query->where('status', request('status'));
        }

        if (request()->has('schedule_id')) {
            $query->where('schedule_id', request('schedule_id'));
        }

        // Sıralama
        $query->latest('date')->latest('created_at');

        $attendances = $query->paginate(request('per_page', 50));

        // İstatistikler
        $stats = [
            'total' => Attendance::count(),
            'present' => Attendance::where('status', 'present')->count(),
            'absent' => Attendance::where('status', 'absent')->count(),
            'late' => Attendance::where('status', 'late')->count(),
            'excused' => Attendance::where('status', 'excused')->count(),
        ];

        return $this->success([
            'attendances' => AttendanceResource::collection($attendances),
            'pagination' => [
                'current_page' => $attendances->currentPage(),
                'last_page' => $attendances->lastPage(),
                'per_page' => $attendances->perPage(),
                'total' => $attendances->total(),
            ],
            'statistics' => $stats,
        ], 'Yoklama kayıtları başarıyla listelendi.');
    }

    /**
     * Store a newly created attendance in storage.
     */
    public function store(StoreAttendanceRequest $request, CreateAttendanceAction $createAttendanceAction): JsonResponse
    {
        Gate::authorize('create', Attendance::class);

        $attendance = $createAttendanceAction->execute($request->validated());

        return $this->success(new AttendanceResource($attendance), 'Yoklama kaydı başarıyla oluşturuldu.', 201);
    }

    /**
     * Store multiple attendance records (bulk).
     */
    public function bulkStore(BulkAttendanceRequest $request, BulkCreateAttendanceAction $bulkCreateAttendanceAction): JsonResponse
    {
        Gate::authorize('create', Attendance::class);

        $result = $bulkCreateAttendanceAction->execute($request->validated());

        return $this->success([
            'created_count' => $result['created'],
            'attendances' => AttendanceResource::collection($result['attendances']),
        ], "{$result['created']} adet yoklama kaydı başarıyla oluşturuldu.", 201);
    }

    /**
     * Display the specified attendance.
     */
    public function show(Attendance $attendance): JsonResponse
    {
        Gate::authorize('view', $attendance);

        return $this->success(new AttendanceResource($attendance->load(['student', 'schedule.lesson', 'teacher'])));
    }

    /**
     * Update the specified attendance in storage.
     */
    public function update(UpdateAttendanceRequest $request, Attendance $attendance, UpdateAttendanceAction $updateAttendanceAction): JsonResponse
    {
        Gate::authorize('update', $attendance);

        $updatedAttendance = $updateAttendanceAction->execute($attendance, $request->validated());

        return $this->success(new AttendanceResource($updatedAttendance), 'Yoklama kaydı başarıyla güncellendi.');
    }

    /**
     * Remove the specified attendance from storage.
     */
    public function destroy(Attendance $attendance): JsonResponse
    {
        Gate::authorize('delete', $attendance);

        $this->activityLogService->logDelete($attendance);
        $attendance->delete();

        return $this->success(null, 'Yoklama kaydı başarıyla silindi.');
    }

    /**
     * Get student attendance statistics.
     */
    public function studentStatistics(int $studentId): JsonResponse
    {
        Gate::authorize('viewAny', Attendance::class);

        $student = \App\Models\Student::findOrFail($studentId);

        // Tarih aralığı
        $dateFrom = request('date_from', now()->startOfMonth()->toDateString());
        $dateTo = request('date_to', now()->toDateString());

        $totalDays = Attendance::where('student_id', $studentId)
            ->whereBetween('date', [$dateFrom, $dateTo])
            ->count();

        $presentDays = Attendance::where('student_id', $studentId)
            ->where('status', 'present')
            ->whereBetween('date', [$dateFrom, $dateTo])
            ->count();

        $absentDays = Attendance::where('student_id', $studentId)
            ->where('status', 'absent')
            ->whereBetween('date', [$dateFrom, $dateTo])
            ->count();

        $lateDays = Attendance::where('student_id', $studentId)
            ->where('status', 'late')
            ->whereBetween('date', [$dateFrom, $dateTo])
            ->count();

        $excusedDays = Attendance::where('student_id', $studentId)
            ->where('status', 'excused')
            ->whereBetween('date', [$dateFrom, $dateTo])
            ->count();

        $administrativeLeaveDays = Attendance::where('student_id', $studentId)
            ->where('is_administrative_leave', true)
            ->whereBetween('date', [$dateFrom, $dateTo])
            ->count();

        $attendanceRate = $totalDays > 0 ? round(($presentDays / $totalDays) * 100, 2) : 0;

        return $this->success([
            'student' => [
                'id' => $student->id,
                'name' => $student->name,
                'school_no' => $student->school_no,
            ],
            'period' => [
                'from' => $dateFrom,
                'to' => $dateTo,
            ],
            'statistics' => [
                'total_days' => $totalDays,
                'present_days' => $presentDays,
                'absent_days' => $absentDays,
                'late_days' => $lateDays,
                'excused_days' => $excusedDays,
                'administrative_leave_days' => $administrativeLeaveDays,
                'attendance_rate' => $attendanceRate,
            ],
        ], 'Öğrenci devamsızlık istatistikleri başarıyla getirildi.');
    }

    /**
     * Get teacher attendance taking statistics.
     */
    public function teacherStatistics(int $teacherId): JsonResponse
    {
        Gate::authorize('viewAny', Attendance::class);

        $user = auth()->user();
        $roleName = $user && $user->role ? $user->role->name : null;
        $teacherOnlyRoles = ['Öğretmen', 'Sınıf Öğretmeni', 'Rehberlik'];
        $isTeacherOnly = $roleName && in_array($roleName, $teacherOnlyRoles, true);
        if ($isTeacherOnly && $user && $user->id !== $teacherId) {
            return $this->error('Bu işlemi yapmaya yetkiniz yok.', [], 403);
        }

        $teacher = \App\Models\User::findOrFail($teacherId);

        // Tarih aralığı
        $dateFrom = request('date_from', now()->startOfMonth()->toDateString());
        $dateTo = request('date_to', now()->toDateString());

        $totalAttendances = Attendance::where('teacher_id', $teacherId)
            ->whereBetween('date', [$dateFrom, $dateTo])
            ->count();

        // Öğretmenin ders programındaki toplam ders sayısı (tahmini)
        $schedules = \App\Models\Schedule::where('teacher_id', $teacherId)->get();
        $totalExpectedLessons = 0;

        foreach ($schedules as $schedule) {
            $days = \Carbon\Carbon::parse($dateFrom)->daysUntil($dateTo);
            $totalExpectedLessons += $days->count();
        }

        $attendanceTakingRate = $totalExpectedLessons > 0 
            ? round(($totalAttendances / $totalExpectedLessons) * 100, 2) 
            : 0;

        return $this->success([
            'teacher' => [
                'id' => $teacher->id,
                'name' => $teacher->name,
                'email' => $teacher->email,
            ],
            'period' => [
                'from' => $dateFrom,
                'to' => $dateTo,
            ],
            'statistics' => [
                'total_attendances_taken' => $totalAttendances,
                'total_expected_lessons' => $totalExpectedLessons,
                'attendance_taking_rate' => $attendanceTakingRate,
            ],
        ], 'Öğretmen yoklama alma istatistikleri başarıyla getirildi.');
    }
}
