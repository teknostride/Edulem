<?php

namespace App\Http\Controllers;

use App\Models\Lesson;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class LessonController extends ApiController
{
    /**
     * Dersleri Listele
     */
    public function index(): JsonResponse
    {
        try {
            $query = Lesson::query()->select(['id', 'tenant_id', 'name', 'code', 'is_active']);

            if (auth()->check() && auth()->user()->tenant_id) {
                $query->where('tenant_id', auth()->user()->tenant_id);
            }

            // Arama filtresi
            if (request()->has('search')) {
                $search = request('search');
                $query->where(function($q) use ($search) {
                    $q->where('name', 'like', "%{$search}%")
                      ->orWhere('code', 'like', "%{$search}%");
                });
            }

            $ids = request()->input('ids');
            if ($ids !== null) {
                if (is_string($ids)) {
                    $ids = array_filter(array_map('trim', explode(',', $ids)));
                }
                if (is_array($ids)) {
                    $ids = array_filter(array_map('intval', $ids), static fn ($id) => $id > 0);
                    if (! empty($ids)) {
                        $query->whereIn('id', $ids);
                    }
                }
            }

            $perPage = (int) request()->get('per_page', 100);
            if ($perPage <= 0) {
                $perPage = 100;
            }
            $perPage = min($perPage, 200);

            $lessons = $query->orderBy('name', 'asc')->paginate($perPage);

            return $this->success([
                'lessons' => $lessons->items(),
                'pagination' => [
                    'current_page' => $lessons->currentPage(),
                    'last_page' => $lessons->lastPage(),
                    'total' => $lessons->total(),
                ],
                'data' => $lessons->items()
            ], 'Dersler listelendi.');

        } catch (\Exception $e) {
            return $this->error('Hata: ' . $e->getMessage(), [], 500);
        }
    }

    /**
     * Yeni Ders Ekle
     * short_code boşsa otomatik üretilir: en fazla 5 karakter (Mat, Mat1, Mat10 gibi).
     */
    public function store(Request $request): JsonResponse
    {
        try {
            $validated = $request->validate([
                'name'       => 'required|string|max:255',
                'short_code' => 'nullable|string|max:5',
                'color'      => 'nullable|string|max:20',
                'is_active'  => 'boolean',
            ]);

            $tenantId = auth()->user()?->tenant_id ?? 1;
            $code = $request->input('short_code');
            if (empty(trim((string) $code))) {
                $code = $this->generateCode($validated['name'], $tenantId);
            } else {
                $code = strtoupper(substr(trim($code), 0, 5));
            }

            $lesson = Lesson::create([
                'tenant_id'   => $tenantId,
                'name'        => $validated['name'],
                'code'        => $code,
                'description' => $request->input('description'),
                'color'       => $validated['color'] ?? '#3b6cff',
                'is_active'   => $request->boolean('is_active', true),
            ]);

            return $this->success($lesson, 'Ders başarıyla oluşturuldu.', 201);

        } catch (\Illuminate\Validation\ValidationException $e) {
            return $this->error('Geçersiz veri.', $e->errors(), 422);
        } catch (\Exception $e) {
            return $this->error('Kayıt hatası: ' . $e->getMessage(), [], 500);
        }
    }

    /**
     * Dersi Güncelle
     */
    public function update(Request $request, string $id): JsonResponse
    {
        try {
            $lesson = Lesson::findOrFail($id);

            $request->validate([
                'name'       => 'required|string|max:255',
                'short_code' => 'nullable|string|max:5',
                'color'      => 'nullable|string|max:20',
                'is_active'  => 'boolean',
            ]);

            $lesson->update([
                'name'      => $request->input('name', $lesson->name),
                // Eğer kod geldiyse güncelle, gelmediyse eskisini koru
                'code'      => $request->filled('short_code') ? strtoupper($request->input('short_code')) : $lesson->code,
                'color'     => $request->input('color', $lesson->color),
                'is_active' => $request->boolean('is_active', $lesson->is_active),
            ]);

            return $this->success(['data' => $lesson], 'Ders güncellendi.');

        } catch (\Exception $e) {
            return $this->error('Güncelleme hatası: ' . $e->getMessage(), [], 500);
        }
    }

    /**
     * Dersi Sil
     */
    public function destroy(string $id): JsonResponse
    {
        try {
            $lesson = Lesson::findOrFail($id);
            
            // Kullanım kontrolü (tablo varsa)
            $isInUse = DB::table('education_level_lessons')->where('lesson_id', $id)->exists();
            if ($isInUse) {
                return $this->error('Bu ders müfredatta kullanıldığı için silinemez.', [], 422);
            }

            $lesson->delete();
            return $this->success([], 'Ders silindi.');
        } catch (\Exception $e) {
            return $this->error('Silme hatası: ' . $e->getMessage(), [], 500);
        }
    }

    /**
     * Dersin öğretmenlerini getir
     */
    public function teachers(string $id): JsonResponse
    {
        try {
            $lesson = Lesson::findOrFail($id);
            $tenantId = $lesson->tenant_id ?? auth()->user()?->tenant_id ?? 1;
            $lessonIdInt = (int) $lesson->id;
            $lessonIdStr = (string) $lesson->id;
            
            // 1. lesson_teacher tablosundan öğretmenleri getir
            $teachersFromPivot = $lesson->teachers()
                ->where('users.tenant_id', $tenantId)
                ->select('users.id', 'users.first_name', 'users.last_name', 'users.email', 'users.role_id')
                ->get();

            // 2. schedules tablosundan bu derse atanmış öğretmenleri getir
            $teacherIdsFromSchedules = DB::table('schedules')
                ->where('lesson_id', $lessonIdInt)
                ->where('tenant_id', $tenantId)
                ->whereNotNull('teacher_id')
                ->distinct()
                ->pluck('teacher_id')
                ->toArray();

            $teachersFromSchedules = collect([]);
            if (!empty($teacherIdsFromSchedules)) {
                $teachersFromSchedules = User::whereIn('id', $teacherIdsFromSchedules)
                    ->where('tenant_id', $tenantId)
                    ->select('id', 'first_name', 'last_name', 'email', 'role_id')
                    ->get();
            }

            // 3. Kullanıcıların subjects alanından bu dersi veren öğretmenleri getir
            $teachersFromSubjects = User::where('tenant_id', $tenantId)
                ->where(function ($q) use ($lesson, $lessonIdInt, $lessonIdStr) {
                    // subjects: [4] veya ["4"]
                    $q->whereJsonContains('subjects', $lessonIdInt)
                      ->orWhereJsonContains('subjects', $lessonIdStr);

                    // subjects farklı formatta tutulmuş olabilir: ["Türkçe"] veya ["TRK"]
                    if (!empty($lesson->name)) {
                        $q->orWhereJsonContains('subjects', $lesson->name);
                    }
                    if (!empty($lesson->code)) {
                        $q->orWhereJsonContains('subjects', $lesson->code);
                    }

                    // MySQL JSON_CONTAINS fallback (bazı ortamlarda whereJsonContains sorun çıkarabiliyor)
                    $q->orWhereRaw('JSON_CONTAINS(subjects, ?, "$")', [json_encode($lessonIdInt)])
                      ->orWhereRaw('JSON_CONTAINS(subjects, ?, "$")', [json_encode($lessonIdStr)]);
                })
                ->select('id', 'first_name', 'last_name', 'email', 'role_id', 'subjects')
                ->get();

            // Tüm öğretmenleri birleştir ve tekrarları kaldır
            $allTeachers = $teachersFromPivot
                ->merge($teachersFromSchedules)
                ->merge($teachersFromSubjects)
                ->unique('id')
                ->values();

            return $this->success($allTeachers, 'Dersin öğretmenleri listelendi.');

        } catch (\Exception $e) {
            return $this->error('Öğretmenler yüklenemedi: ' . $e->getMessage(), [], 500);
        }
    }

    /**
     * Ders adından en fazla 5 karakterlik kısa kod üretir: Mat, Mat1, Mat10 gibi.
     * Mantıklı kısaltma: Türkçe karakterler dönüştürülür, ilk 3 harf alınır, gerekiyorsa 1–99 eklenir.
     */
    private function generateCode(string $name, int $tenantId): string
    {
        $tr = ['ı' => 'i', 'İ' => 'I', 'ş' => 's', 'Ş' => 'S', 'ğ' => 'g', 'Ğ' => 'G', 'ü' => 'u', 'Ü' => 'U', 'ö' => 'o', 'Ö' => 'O', 'ç' => 'c', 'Ç' => 'C'];
        $s = str_replace(array_keys($tr), array_values($tr), $name);
        $s = preg_replace('/[^A-Za-z0-9\s]/', '', $s) ?: $name;
        $words = array_filter(explode(' ', $s));
        $base = '';
        if (count($words) >= 2) {
            foreach (array_slice($words, 0, 3) as $w) {
                $base .= mb_strtoupper(mb_substr($w, 0, 1));
            }
        }
        if (strlen($base) < 2) {
            $base = mb_strtoupper(preg_replace('/[^A-Za-z]/', '', $s) ?: 'D');
            $base = substr($base, 0, 3) ?: 'D';
        }
        $base = substr($base, 0, 3);

        for ($n = 0; $n <= 99; $n++) {
            $c = $base . ($n > 0 ? (string) $n : '');
            if (strlen($c) <= 5 && ! Lesson::where('tenant_id', $tenantId)->where('code', $c)->exists()) {
                return $c;
            }
        }
        return $base . substr((string) random_int(10, 99), 0, 2);
    }
}