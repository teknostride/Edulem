<?php

namespace App\Actions;

use App\Models\Guardian;
use App\Models\Student;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class CreateStudentAction
{
    /**
     * Execute the action to create a student with guardians.
     *
     * @param  array  $studentData
     * @return \Illuminate\Http\JsonResponse
     * @throws \Exception
     */
    public function execute(array $studentData): JsonResponse
    {
        try {
            // Sınıf bilgilerini al (kapasite kontrolü için)
            $classroom = \App\Models\Classroom::with('educationLevel')->find($studentData['classroom_id']);
            if (!$classroom) {
                return response()->json([
                    'status' => false,
                    'message' => 'Sınıf bulunamadı.'
                ], 404);
            }

            $user = auth()->user();
            // Müdür / Müdür Yardımcısı: Sadece atandığı kampüs ve kademelere öğrenci ekleyebilir
            if ($user && $user->role && in_array($user->role->name, ['Müdür', 'Müdür Yardımcısı', 'Öğrenci İşleri', 'student_affairs'], true)) {
                $campusIds = array_filter(array_map('intval', (array) ($user->campus_ids ?? [])));
                $educationLevelIds = array_filter(array_map('intval', (array) ($user->education_level_ids ?? [])));
                $campusOk = empty($campusIds) || ($classroom->educationLevel && in_array((int) $classroom->educationLevel->campus_id, $campusIds, true));
                $levelOk = empty($educationLevelIds) || in_array((int) $classroom->grade_level, $educationLevelIds, true);
                if (!$campusOk || !$levelOk) {
                    return response()->json([
                        'status' => false,
                        'message' => 'Bu kampüs veya kademeye öğrenci ekleme yetkiniz yok.'
                    ], 403);
                }
            }

            // Kapasite kontrolü
            $currentStudents = \App\Models\Student::where('classroom_id', $studentData['classroom_id'])->count();
            if ($currentStudents >= $classroom->capacity) {
                return response()->json([
                    'status' => false,
                    'message' => 'Sınıf kapasitesi dolu! Mevcut: ' . $currentStudents . ', Kapasite: ' . $classroom->capacity
                ], 400);
            }

            // Tenant ID kontrolü
            if (!$user) {
                $user = auth()->user();
            }
            if (!$user) {
                \Log::error('CreateStudentAction: User not authenticated');
                return response()->json([
                    'status' => false,
                    'message' => 'Kullanıcı giriş yapmamış.'
                ], 401);
            }
            
            $tenantId = $user->tenant_id;
            if (!$tenantId || $tenantId === 0 || $tenantId === '0' || $tenantId === null) {
                \Log::error('CreateStudentAction: Tenant ID is invalid', [
                    'user_id' => $user->id,
                    'user_email' => $user->email,
                    'tenant_id_value' => $tenantId,
                    'tenant_id_type' => gettype($tenantId)
                ]);
                return response()->json([
                    'status' => false,
                    'message' => 'Kullanıcı tenant bilgisi bulunamadı. Lütfen sistem yöneticisi ile iletişime geçin.'
                ], 400);
            }

            \Log::info('CreateStudentAction: Creating student', [
                'tenant_id' => $tenantId,
                'student_name' => $studentData['student_name'],
                'tenant_id_type' => gettype($tenantId),
                'tenant_id_value' => $tenantId
            ]);

            // Öğrenciyi kaydet - tenant_id ve sütun adı eşlemesi (veritabanında 'name', API'de 'student_name')
            $studentData['tenant_id'] = (int)$tenantId;
            if (isset($studentData['student_name'])) {
                $studentData['name'] = $studentData['student_name'];
                unset($studentData['student_name']);
            }
            $guardians = $studentData['guardians'] ?? null;
            unset($studentData['guardians']);

            \Log::info('CreateStudentAction: Student data before create', [
                'tenant_id_in_data' => $studentData['tenant_id'],
                'all_keys' => array_keys($studentData)
            ]);

            $student = Student::create($studentData);

            $guardianPasswords = $this->syncGuardiansForStudent($student, $guardians);
            $student->load('guardians');

            $response = [
                'status' => true,
                'data' => $student,
                'message' => 'Öğrenci başarıyla oluşturuldu.',
            ];
            if (!empty($guardianPasswords)) {
                $response['guardian_passwords'] = $guardianPasswords;
                $response['message'] .= ' Veli girişi için oluşturulan şifreleri velilere iletin.';
            }

            return response()->json($response, 201);
        } catch (\Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'Öğrenci oluşturulurken hata oluştu: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Veli listesini öğrenciye bağla: guardians tablosunda yoksa oluştur, portal şifresi ata, öğrenci-veli ilişkisini sync et.
     * Güncellemede kullanıldığında mevcut veli listesini bu liste ile değiştirir.
     *
     * @return array Yeni oluşturulan veliler için { name, phone, email, password } listesi
     */
    public function syncGuardiansForStudent(Student $student, ?array $guardians): array
    {
        $guardianPasswords = [];
        $syncMap = [];

        if (empty($guardians) || !is_array($guardians)) {
            $student->guardians()->sync([]);
            return [];
        }

        foreach ($guardians as $index => $g) {
            $tcNo = isset($g['tc_no']) ? preg_replace('/\D/', '', (string) $g['tc_no']) : null;
            $hasValidTc = $tcNo !== null && $tcNo !== '' && strlen($tcNo) === 11;
            $name = trim($g['name'] ?? '');
            $phone = $g['phone'] ?? null;
            $email = isset($g['email']) ? trim((string) $g['email']) : null;
            $relationType = $g['relation_type'] ?? 'other';
            $isLegalGuardian = (bool) ($g['is_legal_guardian'] ?? false);

            // Referans: veli e-posta ile de kaydedilebilir (TC opsiyonel)
            if (!$hasValidTc && empty($email)) {
                continue;
            }

            $guardian = null;
            if ($hasValidTc) {
                $guardian = Guardian::where('tc_no', $tcNo)->first();
            }
            if (!$guardian && $email) {
                $guardian = Guardian::where('email', $email)->first();
            }
            if (!$guardian) {
                $guardian = new Guardian();
                if ($hasValidTc) {
                    $guardian->tc_no = $tcNo;
                }
            }

            $guardian->name = $name ?: $guardian->name;
            $guardian->phone = $phone ?? $guardian->phone;
            if ($email) {
                $guardian->email = $email;
            }
            $guardian->is_portal_active = true;

            // İlk veli için sabit portal şifresi: 123456
            if ($index === 0 && $email) {
                $guardian->password = Hash::make('123456');
                $guardianPasswords[] = [
                    'name' => $guardian->name,
                    'phone' => $guardian->phone,
                    'email' => $guardian->email,
                    'password' => '123456',
                ];
            } elseif (!$guardian->password) {
                $plainPassword = Str::random(8);
                $guardian->password = Hash::make($plainPassword);
                $guardianPasswords[] = [
                    'name' => $guardian->name,
                    'phone' => $guardian->phone,
                    'email' => $guardian->email,
                    'password' => $plainPassword,
                ];
            }
            $guardian->save();

            $syncMap[$guardian->id] = [
                'relation_type' => $relationType,
                'is_legal_guardian' => $isLegalGuardian,
            ];
        }

        $student->guardians()->sync($syncMap);
        return $guardianPasswords;
    }
}
