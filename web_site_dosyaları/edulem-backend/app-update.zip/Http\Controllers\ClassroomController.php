<?php

namespace App\Http\Controllers;

use App\Actions\CreateClassroomAction;
use App\Actions\UpdateClassroomAction;
use App\Http\Requests\StoreClassroomRequest;
use App\Http\Requests\UpdateClassroomRequest;
use App\Http\Resources\ClassroomResource;
use App\Models\Classroom;
use App\Services\ActivityLogService;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Gate;

class ClassroomController extends ApiController
{
    protected ActivityLogService $activityLogService;

    private function isScopedManagerRole(?string $roleName): bool
    {
        return in_array($roleName, ['Müdür', 'Müdür Yardımcısı', 'Öğrenci İşleri', 'student_affairs'], true);
    }

    private function scopedCampusAndLevelIds($user): array
    {
        return [
            'campus_ids' => array_filter(array_map('intval', (array) ($user->campus_ids ?? []))),
            'education_level_ids' => array_filter(array_map('intval', (array) ($user->education_level_ids ?? []))),
        ];
    }

    private function classroomInScope(Classroom $classroom, array $campusIds, array $educationLevelIds): bool
    {
        $classroom->loadMissing('educationLevel');
        $campusOk = empty($campusIds) || ($classroom->educationLevel && in_array((int) $classroom->educationLevel->campus_id, $campusIds, true));
        $levelOk = empty($educationLevelIds) || in_array((int) $classroom->grade_level, $educationLevelIds, true);
        return $campusOk && $levelOk;
    }

    private function educationLevelInScope(int $educationLevelId, array $campusIds, array $educationLevelIds): bool
    {
        $level = \App\Models\EducationLevel::query()->find($educationLevelId);
        if (! $level) {
            return false;
        }

        $campusOk = empty($campusIds) || in_array((int) $level->campus_id, $campusIds, true);
        $levelOk = empty($educationLevelIds) || in_array((int) $educationLevelId, $educationLevelIds, true);
        return $campusOk && $levelOk;
    }

    public function __construct(ActivityLogService $activityLogService)
    {
        $this->activityLogService = $activityLogService;
    }

    /**
     * Display a listing of classrooms.
     */
    public function index(): JsonResponse
    {
        try {
            $user = auth()->user();
            if (!$user) {
                return $this->error('Kullanıcı giriş yapmamış.', [], 401);
            }

            $query = Classroom::query()
                ->with([
                    'teacher',
                    'branch.campus',
                    'educationLevel.campus',
                ])
                ->withCount('students')
                ->where('tenant_id', $user->tenant_id);

            // Müdür / Müdür Yardımcısı: Sadece atandığı kampüs ve kademelerdeki sınıfları görebilir (kampüs = education_level.campus_id)
            $roleName = $user->role ? $user->role->name : null;
            if (in_array($roleName, ['Müdür', 'Müdür Yardımcısı', 'Öğrenci İşleri', 'student_affairs'], true)) {
                $campusIds = array_filter(array_map('intval', (array) ($user->campus_ids ?? [])));
                $educationLevelIds = array_filter(array_map('intval', (array) ($user->education_level_ids ?? [])));
                if (empty($campusIds) && empty($educationLevelIds)) {
                    $query->whereRaw('1 = 0');
                } else {
                    $query->where(function ($q) use ($campusIds, $educationLevelIds) {
                        if (!empty($campusIds)) {
                            $q->whereHas('educationLevel', function ($qEl) use ($campusIds) {
                                $qEl->whereIn('campus_id', $campusIds);
                            });
                        }
                        if (!empty($educationLevelIds)) {
                            $q->whereIn('grade_level', $educationLevelIds);
                        }
                    });
                }
            }

            // Branch ID filtresi
            if (request()->has('branch_id') && request('branch_id')) {
                $query->where('branch_id', request('branch_id'));
            }

            // Kampüs filtresi: kademenin (education_level) kayıtlı olduğu kampüs (öğrenci listesi filtre mantığı ile uyumlu)
            $campusId = request()->input('campus_id');
            if ($campusId !== null && $campusId !== '') {
                $query->whereHas('educationLevel', function ($q) use ($campusId) {
                    $q->where('campus_id', (int) $campusId);
                });
            }

            // Kademe filtresi (grade_level = education_levels.id)
            $educationLevelId = request()->input('education_level_id');
            if ($educationLevelId !== null && $educationLevelId !== '') {
                $query->where('grade_level', $educationLevelId);
            }

            $activeCount = (clone $query)->where('is_active', true)->count();
            $totalCount = (clone $query)->count();
            $classrooms = $query->latest()->paginate(request('per_page', 100));

            // Direkt model attributes'ı dönür (resource wrapping olmaksızın)
            $classroomArray = $classrooms->items();

            return $this->success([
                'classrooms' => $classroomArray, // Zaten array of Models
                'pagination' => [
                    'current_page' => $classrooms->currentPage(),
                    'last_page' => $classrooms->lastPage(),
                    'per_page' => $classrooms->perPage(),
                    'total' => $classrooms->total(),
                ],
                'active_count' => $activeCount,
                'total_count' => $totalCount,
            ], 'Sınıflar başarıyla listelendi.');
        } catch (\Exception $e) {
            \Log::error('ClassroomController::index error: ' . $e->getMessage(), [
                'trace' => $e->getTraceAsString()
            ]);
            return $this->error('Sınıflar listelenirken bir hata oluştu: ' . $e->getMessage(), [], 500);
        }
    }

    /**
     * Store a newly created classroom in storage.
     */
    public function store(StoreClassroomRequest $request, CreateClassroomAction $createClassroomAction): JsonResponse
    {
        Gate::authorize('create', Classroom::class);

        $validated = $request->validated();
        $user = auth()->user();
        $roleName = $user && $user->role ? $user->role->name : null;
        if ($this->isScopedManagerRole($roleName)) {
            $scoped = $this->scopedCampusAndLevelIds($user);
            $targetEducationLevelId = (int) ($validated['grade_level'] ?? 0);
            if ($targetEducationLevelId <= 0 || ! $this->educationLevelInScope($targetEducationLevelId, $scoped['campus_ids'], $scoped['education_level_ids'])) {
                return $this->error('Bu kampüs/kademede sınıf oluşturma yetkiniz yok.', [], 403);
            }
        }

        $classroom = $createClassroomAction->execute($validated);

        return $this->success(new ClassroomResource($classroom), 'Sınıf başarıyla oluşturuldu.', 201);
    }

    /**
     * Display the specified classroom.
     */
    public function show($id): JsonResponse
    {
        $classroom = Classroom::withoutGlobalScope(\App\Scopes\TenantScope::class)->find($id);
        
        if (!$classroom) {
            return $this->error('Sınıf bulunamadı', [], 404);
        }

        $user = auth()->user();
        $roleName = $user && $user->role ? $user->role->name : null;
        if ($this->isScopedManagerRole($roleName)) {
            $scoped = $this->scopedCampusAndLevelIds($user);
            if (! $this->classroomInScope($classroom, $scoped['campus_ids'], $scoped['education_level_ids'])) {
                return $this->error('Bu sınıfa erişim yetkiniz yok.', [], 403);
            }
        }

        Gate::authorize('view', $classroom);

        return $this->success(new ClassroomResource($classroom->load(['teacher', 'students', 'schedules'])));
    }

    /**
     * Update the specified classroom in storage.
     */
    public function update(UpdateClassroomRequest $request, $id, UpdateClassroomAction $updateClassroomAction): JsonResponse
    {
        $classroom = Classroom::withoutGlobalScope(\App\Scopes\TenantScope::class)->find($id);
        
        if (!$classroom) {
            return $this->error('Sınıf bulunamadı', [], 404);
        }

        $user = auth()->user();
        $roleName = $user && $user->role ? $user->role->name : null;
        if ($this->isScopedManagerRole($roleName)) {
            $scoped = $this->scopedCampusAndLevelIds($user);
            if (! $this->classroomInScope($classroom, $scoped['campus_ids'], $scoped['education_level_ids'])) {
                return $this->error('Bu sınıfı güncelleme yetkiniz yok.', [], 403);
            }

            $validated = $request->validated();
            if (array_key_exists('grade_level', $validated)) {
                $targetEducationLevelId = (int) $validated['grade_level'];
                if (! $this->educationLevelInScope($targetEducationLevelId, $scoped['campus_ids'], $scoped['education_level_ids'])) {
                    return $this->error('Bu kampüs/kademeye sınıf taşıma yetkiniz yok.', [], 403);
                }
            }
        }

        Gate::authorize('update', $classroom);

        $updatedClassroom = $updateClassroomAction->execute($classroom, $request->validated());

        return $this->success(new ClassroomResource($updatedClassroom), 'Sınıf başarıyla güncellendi.');
    }

    /**
     * Remove the specified classroom from storage.
     */
    public function destroy($id): JsonResponse
    {
        // Route binding'in global scope problem'ini bypass et - ID'den direkt query yap
        $classroom = Classroom::withoutGlobalScope(\App\Scopes\TenantScope::class)->find($id);
        
        if (!$classroom) {
            return $this->error('Sınıf bulunamadı', [], 404);
        }

        $user = auth()->user();
        $roleName = $user && $user->role ? $user->role->name : null;
        if ($this->isScopedManagerRole($roleName)) {
            $scoped = $this->scopedCampusAndLevelIds($user);
            if (! $this->classroomInScope($classroom, $scoped['campus_ids'], $scoped['education_level_ids'])) {
                return $this->error('Bu sınıfı silme yetkiniz yok.', [], 403);
            }
        }

        $classroomId = $classroom->id;
        
        \Log::info('ClassroomController::destroy - START', [
            'classroom_id' => $classroomId,
            'classroom_exists_before' => Classroom::find($classroomId) ? 'YES' : 'NO',
        ]);
        
        // SuperAdmin and Owner can delete
        if (!($user->is_superadmin || ($user->role && $user->role->name === 'owner'))) {
            // For other roles, check policy
            try {
                Gate::authorize('delete', $classroom);
            } catch (\Exception $e) {
                \Log::error('ClassroomController::destroy - Gate::authorize FAILED', [
                    'error' => $e->getMessage(),
                    'user_id' => $user->id,
                    'classroom_id' => $classroom->id,
                ]);
                return $this->error('Bu işlem için yetkiniz bulunmamaktadır.', [], 403);
            }
        }

        // Sınıfta öğrenci varsa silme işlemini engelle
        if ($classroom->students()->count() > 0) {
            return $this->error('Bu sınıfta öğrenci bulunduğu için silinemez. Önce öğrencileri başka bir sınıfa taşıyın.', [], 422);
        }

        $this->activityLogService->logDelete($classroom);
        
        $deleted = $classroom->delete();
        
        \Log::info('ClassroomController::destroy - DELETE RESULT', [
            'classroom_id' => $classroomId,
            'delete_returned' => $deleted ? 'TRUE' : 'FALSE',
            'classroom_exists_after' => Classroom::find($classroomId) ? 'YES' : 'NO',
        ]);

        return $this->success(null, 'Sınıf başarıyla silindi.');
    }
}
