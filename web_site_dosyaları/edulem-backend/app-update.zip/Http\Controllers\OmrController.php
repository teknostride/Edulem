<?php

namespace App\Http\Controllers;

use App\Models\OmrCourse;
use App\Models\OmrTopic;
use App\Models\OmrTemplate;
use App\Models\OmrExam;
use App\Models\OmrExamCourse;
use App\Models\OmrAnswerKey;
use App\Models\OmrResult;
use App\Models\OmrSession;
use App\Models\Student;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Barryvdh\DomPDF\Facade\Pdf;

class OmrController extends ApiController
{
    private const BOOKLETS = ['A', 'B', 'C', 'D'];

    private function resolveRoleName(): ?string
    {
        $user = auth()->user();
        if (!$user) {
            return null;
        }

        $name = $user->role?->name
            ?? ($user->role_name ?? null)
            ?? ($user->role ?? null)
            ?? null;

        if ($name) {
            return $name;
        }

        $roleId = $user->role_id ?? null;
        if ($roleId) {
            $dbName = DB::table('roles')->where('id', (int) $roleId)->value('name');
            if (is_string($dbName) && $dbName !== '') {
                return $dbName;
            }
        }

        return null;
    }

    private function toUtf8(string $value): string
    {
        if ($value === '') {
            return '';
        }

        if (mb_detect_encoding($value, 'UTF-8', true)) {
            return $value;
        }

        return mb_convert_encoding($value, 'UTF-8', 'Windows-1254,ISO-8859-9,ISO-8859-1,UTF-8');
    }

    private function utf8izeMixed(mixed $value): mixed
    {
        if (is_string($value)) {
            return $this->toUtf8($value);
        }

        if (is_array($value)) {
            foreach ($value as $k => $v) {
                $value[$k] = $this->utf8izeMixed($v);
            }
            return $value;
        }

        if ($value instanceof \Illuminate\Support\Collection) {
            return $value->map(fn($item) => $this->utf8izeMixed($item));
        }

        if (is_object($value) && method_exists($value, 'toArray')) {
            return $this->utf8izeMixed($value->toArray());
        }

        return $value;
    }

    private function normalizeNameKey(string $value): string
    {
        $value = $this->toUtf8(trim($value));
        if ($value === '') {
            return '';
        }

        $value = mb_strtoupper($value, 'UTF-8');
        $value = strtr($value, [
            'İ' => 'I',
            'I' => 'I',
            'Ş' => 'S',
            'Ğ' => 'G',
            'Ü' => 'U',
            'Ö' => 'O',
            'Ç' => 'C',
            'Â' => 'A',
            'Ê' => 'E',
            'Î' => 'I',
            'Ô' => 'O',
            'Û' => 'U',
        ]);

        return preg_replace('/[^A-Z0-9]/u', '', $value) ?? '';
    }

    private function normalizeTcNo(string $value): string
    {
        $digits = preg_replace('/\D+/', '', $this->toUtf8(trim($value))) ?? '';
        return $digits;
    }

    private function buildStudentLookup(int $tenantId): array
    {
        $students = Student::where('tenant_id', $tenantId)
            ->where('is_active', true)
            ->select(['id', 'tc_no', 'school_no', 'name'])
            ->get();

        $byTcNo = [];
        $bySchoolNo = [];
        $byName = [];

        foreach ($students as $student) {
            $tcNo = $this->normalizeTcNo((string) ($student->tc_no ?? ''));
            if ($tcNo !== '' && !isset($byTcNo[$tcNo])) {
                $byTcNo[$tcNo] = $student;
            }

            $schoolNo = trim((string) ($student->school_no ?? ''));
            if ($schoolNo !== '' && !isset($bySchoolNo[$schoolNo])) {
                $bySchoolNo[$schoolNo] = $student;
            }

            $nameKey = $this->normalizeNameKey((string) ($student->name ?? ''));
            if ($nameKey !== '') {
                $byName[$nameKey] = $byName[$nameKey] ?? [];
                $byName[$nameKey][] = $student;
            }
        }

        return [$byTcNo, $byName, $bySchoolNo];
    }

    private function parseOmrRows(array $lines, array $rules): array
    {
        $rows = [];
        foreach ($lines as $lineNo => $line) {
            $rawLine = rtrim((string) $line, "\r\n");
            $parsedFields = [];
            foreach (['tc_no', 'school_no', 'full_name', 'classroom_section', 'gender'] as $f) {
                if (!empty($rules[$f])) {
                    $parsedFields[$f] = $this->extractField($rawLine, $rules[$f]);
                }
            }

            foreach (($rules['custom_fields'] ?? []) as $cf) {
                $key = (string) ($cf['key'] ?? '');
                if ($key !== '') {
                    $parsedFields[$key] = $this->extractField($rawLine, $cf);
                }
            }

            $bookletType = strtoupper($this->extractField($rawLine, $rules['booklet_type'] ?? []));
            if (!in_array($bookletType, self::BOOKLETS, true)) {
                $bookletType = 'A';
            }

            $rawAnswers = [];
            foreach (($rules['courses'] ?? []) as $courseRule) {
                $cId = (int) ($courseRule['course_id'] ?? 0);
                if ($cId <= 0) {
                    continue;
                }
                $rawAnswers[$cId] = $this->extractRawField($rawLine, $courseRule);
            }

            $rows[] = [
                'row_no' => $lineNo + 1,
                'txt_tc_no' => (string) ($parsedFields['tc_no'] ?? ''),
                'txt_full_name' => (string) ($parsedFields['full_name'] ?? ''),
                'txt_school_no' => (string) ($parsedFields['school_no'] ?? ''),
                'txt_classroom_section' => (string) ($parsedFields['classroom_section'] ?? ''),
                'txt_gender' => (string) ($parsedFields['gender'] ?? ''),
                'booklet_type' => $bookletType,
                'parsed_fields' => $parsedFields,
                'raw_answers' => $rawAnswers,
                'match_status' => 'unmatched',
                'matched_by' => null,
                'db_student_id' => null,
                'db_student_name' => null,
            ];
        }

        return $rows;
    }

    private function applyAutoMatch(array $rows, int $tenantId): array
    {
        [$studentsByTcNo, $studentsByName, $studentsBySchoolNo] = $this->buildStudentLookup($tenantId);

        $matched = 0;
        foreach ($rows as &$row) {
            $row['match_status'] = 'unmatched';
            $row['matched_by'] = null;
            $row['db_student_id'] = null;
            $row['db_student_name'] = null;

            $tcNo = $this->normalizeTcNo((string) (($row['parsed_fields']['tc_no'] ?? null) ?? ($row['txt_tc_no'] ?? '')));
            $nameKey = $this->normalizeNameKey((string) ($row['txt_full_name'] ?? ''));
            $schoolNo = trim((string) ($row['txt_school_no'] ?? ''));

            if ($tcNo !== '' && isset($studentsByTcNo[$tcNo])) {
                $student = $studentsByTcNo[$tcNo];
                $row['db_student_id'] = $student->id;
                $row['db_student_name'] = $student->name;
                $row['match_status'] = 'matched';
                $row['matched_by'] = 'tc_no';
                $matched++;
                continue;
            }

            $nameCandidates = $nameKey !== '' ? ($studentsByName[$nameKey] ?? []) : [];
            if (count($nameCandidates) === 1) {
                $student = $nameCandidates[0];
                $row['db_student_id'] = $student->id;
                $row['db_student_name'] = $student->name;
                $row['match_status'] = 'matched';
                $row['matched_by'] = 'full_name';
                $matched++;
                continue;
            }

            if ($schoolNo !== '' && isset($studentsBySchoolNo[$schoolNo])) {
                $student = $studentsBySchoolNo[$schoolNo];
                $row['db_student_id'] = $student->id;
                $row['db_student_name'] = $student->name;
                $row['match_status'] = 'matched';
                $row['matched_by'] = 'school_no';
                $matched++;
                continue;
            }
        }

        return [$rows, $matched];
    }

    private function calculateMatchedRows(OmrExam $exam, array $rows): array
    {
        $answerMap = $this->buildBookletAnswerMap($exam->id);
        $coeffMap = $this->buildExamCourseCoefficientMap($exam->id, $exam->exam_type);
        $penalty = $exam->wrong_penalty;
        $tenantId = $this->tenantId();

        $calculatedRows = [];
        $skipped = 0;
        $errors = [];

        $students = Student::where('tenant_id', $tenantId)
            ->whereIn('id', collect($rows)->pluck('db_student_id')->filter()->map(fn($v) => (int) $v)->unique()->values())
            ->select(['id', 'school_no', 'name'])
            ->get()
            ->keyBy('id');

        foreach ($rows as $row) {
            try {
                $studentId = (int) ($row['db_student_id'] ?? 0);
                if ($studentId <= 0 || !isset($students[$studentId])) {
                    $skipped++;
                    $errors[] = 'Satır ' . ((int) ($row['row_no'] ?? 0)) . ': geçerli öğrenci eşleşmesi yok.';
                    continue;
                }

                $bookletType = strtoupper((string) ($row['booklet_type'] ?? 'A'));
                if (!in_array($bookletType, self::BOOKLETS, true)) {
                    $bookletType = 'A';
                }

                $rawAnswers = (array) ($row['raw_answers'] ?? []);
                $courseScores = [];
                $totalNet = 0.0;
                $totalPoint = 0.0;

                foreach ($rawAnswers as $courseId => $answers) {
                    $cId = (int) $courseId;
                    $answers = (string) $answers;
                    $keyMap = $answerMap[$cId][$bookletType] ?? [];
                    if (empty($keyMap)) {
                        continue;
                    }

                    $correct = 0;
                    $wrong = 0;
                    $blank = 0;
                    for ($i = 0; $i < strlen($answers); $i++) {
                        $given = strtoupper($answers[$i]);
                        $mapped = $keyMap[$i + 1] ?? null;
                        if ($mapped === null) {
                            continue;
                        }

                        $expect = strtoupper((string) $mapped['answer']);
                        if (in_array($given, ['', ' ', '-', '0'], true)) {
                            $blank++;
                        } elseif ($given === $expect) {
                            $correct++;
                        } else {
                            $wrong++;
                        }
                    }

                    $net = (float) $correct;
                    if ($penalty !== null && $penalty > 0) {
                        $net = max(0.0, $correct - ($wrong / $penalty));
                    }
                    $point = round($net * ($coeffMap[$cId] ?? 1.0), 3);

                    $courseScores[$cId] = [
                        'correct' => $correct,
                        'wrong' => $wrong,
                        'blank' => $blank,
                        'net' => round($net, 3),
                        'point' => $point,
                    ];
                    $totalNet += $net;
                    $totalPoint += $point;
                }

                $parsedFields = (array) ($row['parsed_fields'] ?? []);
                $parsedFields['_matched_by'] = (string) ($row['matched_by'] ?? 'manual');

                $calculatedRows[] = [
                    'row_no' => (int) ($row['row_no'] ?? 0),
                    'db_student_id' => $studentId,
                    'db_student_name' => (string) ($students[$studentId]->name ?? ($row['db_student_name'] ?? '')),
                    'student_no' => (string) ($students[$studentId]->school_no ?? ($row['txt_school_no'] ?? '')),
                    'booklet_type' => $bookletType,
                    'raw_answers' => $rawAnswers,
                    'parsed_fields' => $parsedFields,
                    'course_scores' => $courseScores,
                    'total_net' => round($totalNet, 3),
                    'total_point' => round($totalPoint, 3),
                    'matched_by' => (string) ($row['matched_by'] ?? 'manual'),
                ];
            } catch (\Throwable $ex) {
                $skipped++;
                $errors[] = 'Satır ' . ((int) ($row['row_no'] ?? 0)) . ': ' . $this->toUtf8((string) $ex->getMessage());
            }
        }

        return [$calculatedRows, $skipped, array_slice($errors, 0, 20)];
    }

    private function persistCalculatedRows(OmrExam $exam, array $rows): array
    {
        $tenantId = $this->tenantId();
        $batchId = time();
        $imported = 0;
        $skipped = 0;
        $errors = [];

        $students = Student::where('tenant_id', $tenantId)
            ->whereIn('id', collect($rows)->pluck('db_student_id')->filter()->map(fn($v) => (int) $v)->unique()->values())
            ->select(['id', 'school_no'])
            ->get()
            ->keyBy('id');

        foreach ($rows as $row) {
            try {
                $studentId = (int) ($row['db_student_id'] ?? 0);
                if ($studentId <= 0 || !isset($students[$studentId])) {
                    $skipped++;
                    $errors[] = 'Satır ' . ((int) ($row['row_no'] ?? 0)) . ': geçerli öğrenci bulunamadı.';
                    continue;
                }

                OmrResult::updateOrCreate(
                    ['exam_id' => $exam->id, 'student_id' => $studentId],
                    [
                        'tenant_id' => $tenantId,
                        'student_no' => (string) ($students[$studentId]->school_no ?? ($row['student_no'] ?? '')),
                        'booklet_type' => strtoupper((string) ($row['booklet_type'] ?? 'A')),
                        'raw_answers' => (array) ($row['raw_answers'] ?? []),
                        'parsed_fields' => (array) ($row['parsed_fields'] ?? []),
                        'course_scores' => (array) ($row['course_scores'] ?? []),
                        'total_net' => (float) ($row['total_net'] ?? 0),
                        'total_point' => (float) ($row['total_point'] ?? 0),
                        'import_batch_id' => $batchId,
                        'calculated_at' => now(),
                    ]
                );
                $imported++;
            } catch (\Throwable $ex) {
                $skipped++;
                $errors[] = 'Satır ' . ((int) ($row['row_no'] ?? 0)) . ': ' . $this->toUtf8((string) $ex->getMessage());
            }
        }

        $this->recalculateRanks((int) $exam->id);

        return [$imported, $skipped, array_slice($errors, 0, 20)];
    }

    private function tenantId(): int
    {
        return (int) auth()->user()?->tenant_id;
    }

    private function ensureAccess(): ?JsonResponse
    {
        $role = $this->resolveRoleName();
        $allowed = [
            'Müdür',
            'Müdür Yardımcısı',
            'Kampüs Müdürü',
            'owner',
            'Admin',
            'Genel Müdür',
            'Rehberlik',
            'guidance',
            'Öğrenci İşleri',
            'student_affairs',
            'Öğretmen',
            'teacher',
        ];
        return in_array($role, $allowed, true)
            ? null
            : $this->error('Bu işlem için yetkiniz bulunmamaktadır.', [], 403);
    }

    private function defaultBookletQnoMap(int $questionNo): array
    {
        return [
            'booklet_a_qno' => $questionNo,
            'booklet_b_qno' => null,
            'booklet_c_qno' => null,
            'booklet_d_qno' => null,
        ];
    }

    private function isExamConfigured(OmrExam $exam): bool
    {
        $courseCount = OmrExamCourse::where('exam_id', $exam->id)->count();
        $answerCount = OmrAnswerKey::where('exam_id', $exam->id)->count();
        return $courseCount > 0 && $answerCount > 0 && !empty($exam->configured_at);
    }

    private function extractField(string $line, array $rule): string
    {
        $start = $this->resolveRuleStart($rule);
        $startIndex = $start - 1;
        $length = intval($this->resolveRuleLength($rule));
        if ($length <= 0) {
            return '';
        }

        $extracted = mb_substr($line, $startIndex, $length, 'UTF-8');

        return trim($this->toUtf8((string) $extracted));
    }

    private function extractRawField(string $line, array $rule): string
    {
        $start = $this->resolveRuleStart($rule);
        $startIndex = $start - 1;
        $length = intval($this->resolveRuleLength($rule));
        if ($length <= 0) {
            return '';
        }

        return (string) mb_substr($line, $startIndex, $length, 'UTF-8');
    }

    private function resolveRuleStart(array $rule): int
    {
        $oneBasedStart = array_key_exists('start_position', $rule)
            ? (int) $rule['start_position']
            : (int) ($rule['start'] ?? 1);

        // Template UI is 1-based; treat 0 or 1 as first character.
        return $oneBasedStart <= 1 ? 1 : $oneBasedStart;
    }

    private function resolveRuleLength(array $rule): int
    {
        if (array_key_exists('field_length', $rule)) {
            return max(0, (int) $rule['field_length']);
        }

        return max(0, (int) ($rule['length'] ?? 0));
    }

    private function normalizeFieldRules(array $rules): array
    {
        $required = ['tc_no', 'school_no', 'full_name', 'classroom_section', 'gender', 'booklet_type'];
        foreach ($required as $f) {
            if (!isset($rules[$f])) {
                $rules[$f] = null;
            }
        }
        $rules['custom_fields'] = is_array($rules['custom_fields'] ?? null) ? $rules['custom_fields'] : [];
        $rules['courses'] = is_array($rules['courses'] ?? null) ? $rules['courses'] : [];
        return $rules;
    }

    private function buildExamCourseCoefficientMap(int $examId, string $examType): array
    {
        $examCourses = OmrExamCourse::where('exam_id', $examId)->get();
        if ($examCourses->isNotEmpty()) {
            return $examCourses->pluck('coefficient', 'course_id')
                ->map(fn($v) => (float) $v)
                ->toArray();
        }

        return OmrCourse::where('tenant_id', $this->tenantId())
            ->pluck('coefficients', 'id')
            ->map(function ($coeffs) use ($examType) {
                $arr = is_array($coeffs) ? $coeffs : [];
                return (float) ($arr[$examType] ?? 1.0);
            })
            ->toArray();
    }

    private function buildBookletAnswerMap(int $examId): array
    {
        $map = [];
        $keys = OmrAnswerKey::where('exam_id', $examId)->get();
        foreach ($keys as $key) {
            $canonical = (int) $key->question_no;
            $courseId = (int) $key->course_id;
            $answer = strtoupper((string) $key->correct_answer);
            $bookletQMap = [
                'A' => $key->booklet_a_qno,
                'B' => $key->booklet_b_qno,
                'C' => $key->booklet_c_qno,
                'D' => $key->booklet_d_qno,
            ];
            foreach (self::BOOKLETS as $booklet) {
                $qno = (int) ($bookletQMap[$booklet] ?? 0);
                if ($qno > 0) {
                    $map[$courseId][$booklet][$qno] = [
                        'answer' => $answer,
                        'canonical_qno' => $canonical,
                        'topic_id' => $key->topic_id,
                    ];
                }
            }
        }

        return $map;
    }

    private function recalculateRanks(int $examId): void
    {
        $results = OmrResult::where('exam_id', $examId)
            ->orderByDesc('total_point')
            ->orderByDesc('total_net')
            ->get();

        foreach ($results as $rank => $result) {
            $result->update(['rank' => $rank + 1]);
        }
    }

    private function buildStudentTopicAnalysis(OmrResult $result, \Illuminate\Support\Collection $answerKeys): array
    {
        $topicAnalysis = [];
        $booklet = strtoupper((string) $result->booklet_type);

        foreach ($answerKeys as $ak) {
            $courseId = (int) $ak->course_id;
            $rawStr = (string) ($result->raw_answers[$courseId] ?? '');

            $targetQ = match ($booklet) {
                'B' => $ak->booklet_b_qno,
                'C' => $ak->booklet_c_qno,
                'D' => $ak->booklet_d_qno,
                default => $ak->booklet_a_qno,
            };
            if (!$targetQ) {
                continue;
            }

            $given = strtoupper($rawStr[$targetQ - 1] ?? '');
            $expect = strtoupper((string) $ak->correct_answer);
            $status = in_array($given, ['', ' ', '-', '0'], true)
                ? 'blank'
                : ($given === $expect ? 'correct' : 'wrong');

            $topicId = (int) ($ak->topic_id ?? 0);
            if (!isset($topicAnalysis[$topicId])) {
                $topicAnalysis[$topicId] = [
                    'topic_id' => $topicId,
                    'topic_name' => (string) ($ak->topic?->name ?? 'Belirtilmemiş'),
                    'course_id' => $courseId,
                    'course_name' => (string) ($ak->course?->name ?? ''),
                    'correct' => 0,
                    'wrong' => 0,
                    'blank' => 0,
                ];
            }

            $topicAnalysis[$topicId][$status]++;
        }

        return array_values($topicAnalysis);
    }

    // COURSES
    public function coursesIndex(): JsonResponse
    {
        if ($e = $this->ensureAccess()) return $e;
        $courses = OmrCourse::where('tenant_id', $this->tenantId())
            ->withCount('topics')->orderBy('sort_order')->orderBy('name')->get();
        return $this->success(['courses' => $courses]);
    }

    public function coursesStore(Request $request): JsonResponse
    {
        if ($e = $this->ensureAccess()) return $e;
        $data = $request->validate([
            'name' => 'required|string|max:100',
            'code' => 'nullable|string|max:20',
            'coefficients' => 'nullable|array',
            'sort_order' => 'nullable|integer|min:0',
            'is_active' => 'nullable|boolean',
        ]);
        $data['tenant_id'] = $this->tenantId();
        return $this->success(['course' => OmrCourse::create($data)], 'Ders oluşturuldu.', 201);
    }

    public function coursesUpdate(Request $request, int $id): JsonResponse
    {
        if ($e = $this->ensureAccess()) return $e;
        $course = OmrCourse::where('tenant_id', $this->tenantId())->findOrFail($id);
        $data = $request->validate([
            'name' => 'sometimes|required|string|max:100',
            'code' => 'nullable|string|max:20',
            'coefficients' => 'nullable|array',
            'sort_order' => 'nullable|integer|min:0',
            'is_active' => 'nullable|boolean',
        ]);
        $course->update($data);
        return $this->success(['course' => $course->fresh()], 'Ders güncellendi.');
    }

    public function coursesDestroy(int $id): JsonResponse
    {
        if ($e = $this->ensureAccess()) return $e;
        OmrCourse::where('tenant_id', $this->tenantId())->findOrFail($id)->delete();
        return $this->success([], 'Ders silindi.');
    }

    // TOPICS
    public function topicsIndex(int $courseId): JsonResponse
    {
        if ($e = $this->ensureAccess()) return $e;
        OmrCourse::where('tenant_id', $this->tenantId())->findOrFail($courseId);
        $topics = OmrTopic::where('tenant_id', $this->tenantId())
            ->where('course_id', $courseId)->orderBy('sort_order')->orderBy('name')->get();
        return $this->success(['topics' => $topics]);
    }

    public function topicsStore(Request $request, int $courseId): JsonResponse
    {
        if ($e = $this->ensureAccess()) return $e;
        OmrCourse::where('tenant_id', $this->tenantId())->findOrFail($courseId);
        $data = $request->validate([
            'name' => 'required|string|max:200',
            'type' => 'nullable|in:topic,objective',
            'sort_order' => 'nullable|integer|min:0',
        ]);
        $data['tenant_id'] = $this->tenantId();
        $data['course_id'] = $courseId;
        return $this->success(['topic' => OmrTopic::create($data)], 'Konu/Kazanım oluşturuldu.', 201);
    }

    public function topicsBulkStore(Request $request, int $courseId): JsonResponse
    {
        if ($e = $this->ensureAccess()) return $e;
        OmrCourse::where('tenant_id', $this->tenantId())->findOrFail($courseId);
        $request->validate([
            'text'         => 'required|string',
            'type'         => 'nullable|in:topic,objective',
            'start_order'  => 'nullable|integer|min:0',
        ]);

        $type       = $request->input('type', 'topic');
        $startOrder = (int) $request->input('start_order', 0);
        $tenantId   = $this->tenantId();

        $lines = array_values(array_filter(
            array_map('trim', explode("\n", $request->input('text'))),
            fn($l) => $l !== ''
        ));

        if (empty($lines)) {
            return $this->error('Eklenecek satır bulunamadı.', [], 422);
        }

        $now  = now();
        $rows = [];
        foreach ($lines as $i => $line) {
            $rows[] = [
                'tenant_id'  => $tenantId,
                'course_id'  => $courseId,
                'name'       => mb_substr($line, 0, 200),
                'type'       => $type,
                'sort_order' => $startOrder + $i,
                'created_at' => $now,
                'updated_at' => $now,
            ];
        }

        \Illuminate\Support\Facades\DB::table('omr_topics')->insert($rows);

        $topics = OmrTopic::where('tenant_id', $tenantId)
            ->where('course_id', $courseId)
            ->orderBy('sort_order')->orderBy('name')->get();

        return $this->success(['topics' => $topics, 'inserted' => count($rows)], count($rows) . ' konu/kazanım eklendi.', 201);
    }

    public function topicsUpdate(Request $request, int $courseId, int $id): JsonResponse
    {
        if ($e = $this->ensureAccess()) return $e;
        $topic = OmrTopic::where('tenant_id', $this->tenantId())->where('course_id', $courseId)->findOrFail($id);
        $data = $request->validate([
            'name' => 'sometimes|required|string|max:200',
            'type' => 'nullable|in:topic,objective',
            'sort_order' => 'nullable|integer|min:0',
        ]);
        $topic->update($data);
        return $this->success(['topic' => $topic->fresh()], 'Konu/Kazanım güncellendi.');
    }

    public function topicsDestroy(int $courseId, int $id): JsonResponse
    {
        if ($e = $this->ensureAccess()) return $e;
        OmrTopic::where('tenant_id', $this->tenantId())->where('course_id', $courseId)->findOrFail($id)->delete();
        return $this->success([], 'Konu/Kazanım silindi.');
    }

    // OMR TEMPLATES
    public function templatesIndex(): JsonResponse
    {
        if ($e = $this->ensureAccess()) return $e;
        return $this->success([
            'templates' => OmrTemplate::where('tenant_id', $this->tenantId())
                ->orderByDesc('id')
                ->get(),
        ]);
    }

    public function templatesStore(Request $request): JsonResponse
    {
        if ($e = $this->ensureAccess()) return $e;
        $data = $request->validate([
            'name' => 'required|string|max:200',
            'exam_type' => 'required|string|max:30',
            'field_rules' => 'required|array',
            'field_rules.tc_no.start' => 'nullable|integer|min:0',
            'field_rules.tc_no.length' => 'nullable|integer|min:1',
            'field_rules.school_no.start' => 'required|integer|min:0',
            'field_rules.school_no.length' => 'required|integer|min:1',
            'field_rules.full_name.start' => 'nullable|integer|min:0',
            'field_rules.full_name.length' => 'nullable|integer|min:1',
            'field_rules.classroom_section.start' => 'nullable|integer|min:0',
            'field_rules.classroom_section.length' => 'nullable|integer|min:1',
            'field_rules.gender.start' => 'nullable|integer|min:0',
            'field_rules.gender.length' => 'nullable|integer|min:1',
            'field_rules.booklet_type.start' => 'required|integer|min:0',
            'field_rules.booklet_type.length' => 'required|integer|min:1',
            'field_rules.custom_fields' => 'nullable|array',
            'field_rules.custom_fields.*.key' => 'required_with:field_rules.custom_fields|string|max:100',
            'field_rules.custom_fields.*.label' => 'nullable|string|max:200',
            'field_rules.custom_fields.*.start' => 'required_with:field_rules.custom_fields|integer|min:0',
            'field_rules.custom_fields.*.length' => 'required_with:field_rules.custom_fields|integer|min:1',
            'field_rules.courses' => 'nullable|array',
            'field_rules.courses.*.course_id' => 'required_with:field_rules.courses|integer|exists:omr_courses,id',
            'field_rules.courses.*.start' => 'required_with:field_rules.courses|integer|min:0',
            'field_rules.courses.*.length' => 'required_with:field_rules.courses|integer|min:1',
            'notes' => 'nullable|string',
            'is_active' => 'nullable|boolean',
        ]);

        $data['field_rules'] = $this->normalizeFieldRules($data['field_rules']);
        $data['tenant_id'] = $this->tenantId();
        $data['created_by'] = auth()->id();
        return $this->success(['template' => OmrTemplate::create($data)], 'OMR şablonu oluşturuldu.', 201);
    }

    public function templatesShow(int $id): JsonResponse
    {
        if ($e = $this->ensureAccess()) return $e;
        return $this->success(['template' => OmrTemplate::where('tenant_id', $this->tenantId())->findOrFail($id)]);
    }

    public function templatesUpdate(Request $request, int $id): JsonResponse
    {
        if ($e = $this->ensureAccess()) return $e;
        $template = OmrTemplate::where('tenant_id', $this->tenantId())->findOrFail($id);
        $data = $request->validate([
            'name' => 'sometimes|required|string|max:200',
            'exam_type' => 'sometimes|required|string|max:30',
            'field_rules' => 'sometimes|required|array',
            'notes' => 'nullable|string',
            'is_active' => 'nullable|boolean',
        ]);

        if (isset($data['field_rules'])) {
            $data['field_rules'] = $this->normalizeFieldRules($data['field_rules']);
        }
        $template->update($data);
        return $this->success(['template' => $template->fresh()], 'OMR şablonu güncellendi.');
    }

    public function templatesDestroy(int $id): JsonResponse
    {
        if ($e = $this->ensureAccess()) return $e;
        OmrTemplate::where('tenant_id', $this->tenantId())->findOrFail($id)->delete();
        return $this->success([], 'OMR şablonu silindi.');
    }

    // EXAMS
    public function examsIndex(Request $request): JsonResponse
    {
        if ($e = $this->ensureAccess()) return $e;
        $query = OmrExam::where('tenant_id', $this->tenantId())
            ->with(['template:id,name', 'creator:id,name'])
            ->withCount(['results', 'examCourses', 'answerKeys']);
        if ($request->filled('exam_type')) $query->where('exam_type', $request->get('exam_type'));
        if ($request->filled('status')) $query->where('status', $request->get('status'));

        $exams = $query->orderByDesc('exam_date')->orderByDesc('id')->get();
        $exams->transform(function ($exam) {
            $exam->is_configured = $this->isExamConfigured($exam);
            return $exam;
        });

        return $this->success(['exams' => $this->utf8izeMixed($exams)]);
    }

    public function examsStore(Request $request): JsonResponse
    {
        if ($e = $this->ensureAccess()) return $e;
        $data = $request->validate([
            'name' => 'required|string|max:255',
            'exam_type' => 'required|string|max:30',
            'session' => 'nullable|string|max:30',
            'level' => 'nullable|string|max:20',
            'exam_date' => 'nullable|date',
        ]);

        $data['duration'] = null;
        $data['season'] = null;
        $data['test_code'] = null;
        $data['wrong_penalty'] = $data['exam_type'] === 'LGS' ? 3 : ($data['exam_type'] === 'YKS-TYT' || $data['exam_type'] === 'YKS-AYT' || $data['exam_type'] === 'YKS-DIL' ? 4 : null);
        $data['omr_template_id'] = null;
        $data['status'] = 'draft';
        $data['configured_at'] = null;
        $data['tenant_id'] = $this->tenantId();
        $data['created_by'] = auth()->id();
        return $this->success(['exam' => OmrExam::create($data)->load('template')], 'Sınav oluşturuldu.', 201);
    }

    public function examsShow(int $id): JsonResponse
    {
        if ($e = $this->ensureAccess()) return $e;
        $exam = OmrExam::where('tenant_id', $this->tenantId())
            ->with([
                'template',
                'creator:id,name',
                'answerKeys.course',
                'answerKeys.topic',
                'examCourses.course:id,name,code',
            ])
            ->findOrFail($id);

        $answerKeysByCourse = $exam->answerKeys
            ->groupBy('course_id')
            ->map(function ($keys, $courseId) {
            return [
                'course_id' => $courseId,
                'course_name' => $keys->first()->course?->name,
                'questions' => $keys->sortBy('question_no')->values()->map(fn($k) => [
                        'id' => $k->id,
                        'question_no' => $k->question_no,
                        'booklet_a_qno' => $k->booklet_a_qno,
                        'booklet_b_qno' => $k->booklet_b_qno,
                        'booklet_c_qno' => $k->booklet_c_qno,
                        'booklet_d_qno' => $k->booklet_d_qno,
                        'correct_answer' => $k->correct_answer,
                        'topic_id' => $k->topic_id,
                        'topic_name' => $k->topic?->name,
                    ]),
            ];
        })->values();

        $exam->is_configured = $this->isExamConfigured($exam);

        return $this->success([
            'exam' => $exam,
            'exam_courses' => $exam->examCourses,
            'answer_keys' => $answerKeysByCourse,
        ]);
    }

    public function examsUpdate(Request $request, int $id): JsonResponse
    {
        if ($e = $this->ensureAccess()) return $e;
        $exam = OmrExam::where('tenant_id', $this->tenantId())->findOrFail($id);
        $data = $request->validate([
            'name' => 'sometimes|required|string|max:255',
            'exam_type' => 'sometimes|required|string|max:30',
            'session' => 'nullable|string|max:30',
            'level' => 'nullable|string|max:20',
            'exam_date' => 'nullable|date',
            'duration' => 'nullable|integer|min:1',
            'season' => 'nullable|string|max:20',
            'test_code' => 'nullable|string|max:50',
            'wrong_penalty' => 'nullable|numeric|min:0|max:10',
            'omr_template_id' => 'nullable|integer|exists:omr_templates,id',
            'status' => 'nullable|in:draft,active,archived',
            'configured_at' => 'nullable|date',
        ]);
        $exam->update($data);
        return $this->success(['exam' => $exam->fresh()], 'Sınav güncellendi.');
    }

    public function examCoursesSync(Request $request, int $examId): JsonResponse
    {
        if ($e = $this->ensureAccess()) return $e;
        $exam = OmrExam::where('tenant_id', $this->tenantId())->findOrFail($examId);
        $data = $request->validate([
            'courses' => 'required|array|min:1',
            'courses.*.course_id' => 'required|integer|exists:omr_courses,id',
            'courses.*.coefficient' => 'required|numeric|min:0',
            'courses.*.question_count' => 'nullable|integer|min:0',
            'courses.*.sort_order' => 'nullable|integer|min:0|max:255',
        ]);

        DB::transaction(function () use ($exam, $data) {
            OmrExamCourse::where('exam_id', $exam->id)->delete();
            foreach ($data['courses'] as $row) {
                OmrExamCourse::create([
                    'tenant_id' => $this->tenantId(),
                    'exam_id' => $exam->id,
                    'course_id' => (int) $row['course_id'],
                    'coefficient' => (float) $row['coefficient'],
                    'question_count' => (int) ($row['question_count'] ?? 0),
                    'sort_order' => (int) ($row['sort_order'] ?? 0),
                ]);
            }
        });

        return $this->success([], 'Sınav dersleri ve katsayıları kaydedildi.');
    }

    public function examConfigureFinalize(Request $request, int $examId): JsonResponse
    {
        if ($e = $this->ensureAccess()) return $e;
        $exam = OmrExam::where('tenant_id', $this->tenantId())->findOrFail($examId);

        if (OmrExamCourse::where('exam_id', $exam->id)->count() === 0) {
            return $this->error('Önce sınava en az bir ders eklenmelidir.', [], 422);
        }
        if (OmrAnswerKey::where('exam_id', $exam->id)->count() === 0) {
            return $this->error('Önce cevap anahtarı girilmelidir.', [], 422);
        }

        $exam->update([
            'configured_at' => now(),
            'status' => $exam->status === 'draft' ? 'active' : $exam->status,
        ]);

        return $this->success(['exam' => $exam->fresh()], 'Sınav yapılandırması tamamlandı.');
    }

    public function examsDestroy(int $id): JsonResponse
    {
        if ($e = $this->ensureAccess()) return $e;
        OmrExam::where('tenant_id', $this->tenantId())->findOrFail($id)->delete();
        return $this->success([], 'Sınav silindi.');
    }

    // ANSWER KEYS
    public function answerKeysBulkSave(Request $request, int $examId): JsonResponse
    {
        if ($e = $this->ensureAccess()) return $e;
        $exam = OmrExam::where('tenant_id', $this->tenantId())->findOrFail($examId);

        if (OmrExamCourse::where('exam_id', $exam->id)->count() === 0) {
            return $this->error('Önce sınava dersler eklenmeli ve katsayılar belirlenmelidir.', [], 422);
        }

        $request->validate([
            'keys' => 'required|array|min:1',
            'keys.*.course_id' => 'required|integer|exists:omr_courses,id',
            'keys.*.question_no' => 'required|integer|min:1',
            'keys.*.booklet_a_qno' => 'nullable|integer|min:1',
            'keys.*.booklet_b_qno' => 'nullable|integer|min:1',
            'keys.*.booklet_c_qno' => 'nullable|integer|min:1',
            'keys.*.booklet_d_qno' => 'nullable|integer|min:1',
            'keys.*.correct_answer' => 'required|in:A,B,C,D,E',
            'keys.*.topic_id' => 'nullable|integer|exists:omr_topics,id',
            'keys.*.custom_topic_text' => 'nullable|string|max:200',
        ]);

        $tenantId = $this->tenantId();

        DB::transaction(function () use ($exam, $request, $tenantId) {
            foreach ($request->input('keys') as $key) {
                $topicId = $key['topic_id'] ?? null;

                // Eğer manuel kazanım metni gönderildiyse, aynı isimli topic yoksa yarat
                $customText = trim((string)($key['custom_topic_text'] ?? ''));
                if ($customText !== '' && $topicId === null) {
                    $existing = OmrTopic::where('tenant_id', $tenantId)
                        ->where('course_id', $key['course_id'])
                        ->where('name', $customText)
                        ->first();
                    if ($existing) {
                        $topicId = $existing->id;
                    } else {
                        $newTopic = OmrTopic::create([
                            'tenant_id'  => $tenantId,
                            'course_id'  => $key['course_id'],
                            'name'       => mb_substr($customText, 0, 200),
                            'type'       => 'objective',
                            'sort_order' => 0,
                        ]);
                        $topicId = $newTopic->id;
                    }
                }

                $defaultMap = $this->defaultBookletQnoMap((int) $key['question_no']);
                OmrAnswerKey::updateOrCreate(
                    [
                        'exam_id' => $exam->id,
                        'course_id' => $key['course_id'],
                        'question_no' => $key['question_no'],
                    ],
                    [
                        'booklet_type' => 'A',
                        'booklet_a_qno' => $key['booklet_a_qno'] ?? $defaultMap['booklet_a_qno'],
                        'booklet_b_qno' => $key['booklet_b_qno'] ?? $defaultMap['booklet_b_qno'],
                        'booklet_c_qno' => $key['booklet_c_qno'] ?? $defaultMap['booklet_c_qno'],
                        'booklet_d_qno' => $key['booklet_d_qno'] ?? $defaultMap['booklet_d_qno'],
                        'correct_answer' => strtoupper($key['correct_answer']),
                        'topic_id' => $topicId,
                    ]
                );
            }
        });
        return $this->success([], 'Cevap anahtarı kaydedildi.');
    }

    // OMR FILE IMPORT - STAGING LAYER
    public function importPreview(Request $request, int $examId): JsonResponse
    {
        if ($e = $this->ensureAccess()) return $e;
        $exam = OmrExam::where('tenant_id', $this->tenantId())
            ->with(['template'])
            ->findOrFail($examId);

        $data = $request->validate([
            'exam_id' => 'nullable|integer',
            'template_id' => 'nullable|integer',
            'parsed_rows' => 'required|array|min:1',
            'parsed_rows.*.row_no' => 'nullable|integer|min:1',
            'parsed_rows.*.txt_tc_no' => 'nullable|string|max:30',
            'parsed_rows.*.txt_full_name' => 'nullable|string|max:255',
            'parsed_rows.*.txt_school_no' => 'nullable|string|max:100',
            'parsed_rows.*.txt_classroom_section' => 'nullable|string|max:120',
            'parsed_rows.*.txt_gender' => 'nullable|string|max:30',
            'parsed_rows.*.booklet_type' => 'nullable|string|max:2',
            'parsed_rows.*.parsed_fields' => 'nullable|array',
            'parsed_rows.*.raw_answers' => 'nullable|array',
        ]);

        if (!$exam->template) return $this->error('Bu sınava OMR şablonu atanmamış.', [], 422);
        if (empty($exam->configured_at)) return $this->error('Sınav henüz yapılandırılmamış. Önce yapılandırmayı tamamlayın.', [], 422);

        $rows = [];
        foreach ($data['parsed_rows'] as $i => $row) {
            $booklet = strtoupper((string) ($row['booklet_type'] ?? 'A'));
            if (!in_array($booklet, self::BOOKLETS, true)) {
                $booklet = 'A';
            }

            $rows[] = [
                'row_no' => (int) ($row['row_no'] ?? ($i + 1)),
                'txt_tc_no' => trim((string) ($row['txt_tc_no'] ?? '')),
                'txt_full_name' => trim((string) ($row['txt_full_name'] ?? '')),
                'txt_school_no' => trim((string) ($row['txt_school_no'] ?? '')),
                'txt_classroom_section' => trim((string) ($row['txt_classroom_section'] ?? '')),
                'txt_gender' => trim((string) ($row['txt_gender'] ?? '')),
                'booklet_type' => $booklet,
                'parsed_fields' => is_array($row['parsed_fields'] ?? null) ? $row['parsed_fields'] : [],
                'raw_answers' => is_array($row['raw_answers'] ?? null) ? $row['raw_answers'] : [],
                'match_status' => 'unmatched',
                'matched_by' => null,
                'db_student_id' => null,
                'db_student_name' => null,
            ];
        }

        [$rows, $matched] = $this->applyAutoMatch($rows, $this->tenantId());
        $total = count($rows);

        return $this->success([
            'rows' => $this->utf8izeMixed($rows),
            'summary' => [
                'total_rows' => $total,
                'matched_rows' => $matched,
                'unmatched_rows' => $total - $matched,
            ],
        ], 'Satırlar alındı, otomatik eşleştirme tamamlandı.');
    }

    public function importAutoMatch(Request $request, int $examId): JsonResponse
    {
        if ($e = $this->ensureAccess()) return $e;
        OmrExam::where('tenant_id', $this->tenantId())->findOrFail($examId);

        $data = $request->validate([
            'rows' => 'required|array|min:1',
            'rows.*.row_no' => 'required|integer|min:1',
            'rows.*.txt_tc_no' => 'nullable|string|max:30',
            'rows.*.txt_full_name' => 'nullable|string|max:255',
            'rows.*.txt_school_no' => 'nullable|string|max:100',
            'rows.*.booklet_type' => 'nullable|string|max:2',
            'rows.*.parsed_fields' => 'nullable|array',
            'rows.*.raw_answers' => 'nullable|array',
        ]);

        [$rows, $matched] = $this->applyAutoMatch($data['rows'], $this->tenantId());
        $total = count($rows);

        return $this->success([
            'rows' => $this->utf8izeMixed($rows),
            'summary' => [
                'total_rows' => $total,
                'matched_rows' => $matched,
                'unmatched_rows' => $total - $matched,
            ],
        ], 'Otomatik eşleştirme tamamlandı.');
    }

    public function studentsSearch(Request $request, int $examId): JsonResponse
    {
        if ($e = $this->ensureAccess()) return $e;
        OmrExam::where('tenant_id', $this->tenantId())->findOrFail($examId);

        $q = trim((string) $request->get('q', ''));
        $limit = min(max((int) $request->get('limit', 50), 1), 200);

        $query = Student::where('tenant_id', $this->tenantId())
            ->where('is_active', true)
            ->select(['id', 'name', 'school_no', 'classroom_id'])
            ->with('classroom:id,name')
            ->orderBy('name');

        if ($q !== '') {
            $query->where(function ($inner) use ($q) {
                $inner->where('name', 'like', "%{$q}%")
                    ->orWhere('school_no', 'like', "%{$q}%");
            });
        }

        $students = $query->limit($limit)->get();

        return $this->success(['students' => $students]);
    }

    public function importFinalize(Request $request, int $examId): JsonResponse
    {
        if ($e = $this->ensureAccess()) return $e;
        $exam = OmrExam::where('tenant_id', $this->tenantId())
            ->with(['answerKeys.course', 'template', 'examCourses'])
            ->findOrFail($examId);

        if (!$exam->template) return $this->error('Bu sınava OMR şablonu atanmamış.', [], 422);
        if (empty($exam->configured_at)) return $this->error('Sınav henüz yapılandırılmamış. Önce yapılandırmayı tamamlayın.', [], 422);

        $data = $request->validate([
            'rows' => 'required|array|min:1',
            'rows.*.row_no' => 'required|integer|min:1',
            'rows.*.db_student_id' => 'required|integer|exists:students,id',
            'rows.*.booklet_type' => 'required|string|max:2',
            'rows.*.raw_answers' => 'required|array',
            'rows.*.parsed_fields' => 'nullable|array',
            'rows.*.txt_school_no' => 'nullable|string|max:100',
            'rows.*.matched_by' => 'nullable|string|max:40',
        ]);

        $unmatched = collect($data['rows'])->first(fn($r) => empty($r['db_student_id']));
        if ($unmatched) {
            return $this->error('Tüm satırlar eşleştirilmeden hesaplama yapılamaz.', [], 422);
        }

        [$calculatedRows] = $this->calculateMatchedRows($exam, $data['rows']);
        [$imported, $skipped, $errors] = $this->persistCalculatedRows($exam, $calculatedRows);
        $exam->update(['status' => $exam->status === 'draft' ? 'active' : $exam->status]);

        return $this->success([
            'imported' => $imported,
            'skipped' => $skipped,
            'errors' => $errors,
        ], "{$imported} öğrenci sonucu hesaplandı ve kaydedildi.");
    }

    public function importCalculate(Request $request, int $examId): JsonResponse
    {
        if ($e = $this->ensureAccess()) return $e;
        $exam = OmrExam::where('tenant_id', $this->tenantId())
            ->with(['answerKeys.course', 'template', 'examCourses'])
            ->findOrFail($examId);

        if (!$exam->template) return $this->error('Bu sınava OMR şablonu atanmamış.', [], 422);
        if (empty($exam->configured_at)) return $this->error('Sınav henüz yapılandırılmamış. Önce yapılandırmayı tamamlayın.', [], 422);

        $data = $request->validate([
            'rows' => 'required|array|min:1',
            'rows.*.row_no' => 'required|integer|min:1',
            'rows.*.db_student_id' => 'required|integer|exists:students,id',
            'rows.*.booklet_type' => 'required|string|max:2',
            'rows.*.raw_answers' => 'required|array',
            'rows.*.parsed_fields' => 'nullable|array',
            'rows.*.txt_school_no' => 'nullable|string|max:100',
            'rows.*.matched_by' => 'nullable|string|max:40',
        ]);

        [$calculatedRows, $skipped, $errors] = $this->calculateMatchedRows($exam, $data['rows']);

        return $this->success([
            'rows' => $this->utf8izeMixed($calculatedRows),
            'summary' => [
                'calculated' => count($calculatedRows),
                'skipped' => $skipped,
            ],
            'errors' => $errors,
        ], 'Eşleşen satırlar hesaplandı. Kaydetme için onay bekleniyor.');
    }

    public function importSave(Request $request, int $examId): JsonResponse
    {
        if ($e = $this->ensureAccess()) return $e;
        $exam = OmrExam::where('tenant_id', $this->tenantId())
            ->with(['template'])
            ->findOrFail($examId);

        if (!$exam->template) return $this->error('Bu sınava OMR şablonu atanmamış.', [], 422);
        if (empty($exam->configured_at)) return $this->error('Sınav henüz yapılandırılmamış. Önce yapılandırmayı tamamlayın.', [], 422);

        $data = $request->validate([
            'rows' => 'required|array|min:1',
            'rows.*.row_no' => 'required|integer|min:1',
            'rows.*.db_student_id' => 'required|integer|exists:students,id',
            'rows.*.student_no' => 'nullable|string|max:100',
            'rows.*.booklet_type' => 'required|string|max:2',
            'rows.*.raw_answers' => 'required|array',
            'rows.*.parsed_fields' => 'nullable|array',
            'rows.*.course_scores' => 'required|array',
            'rows.*.total_net' => 'required|numeric',
            'rows.*.total_point' => 'required|numeric',
        ]);

        [$imported, $skipped, $errors] = $this->persistCalculatedRows($exam, $data['rows']);
        $exam->update(['status' => $exam->status === 'draft' ? 'active' : $exam->status]);

        return $this->success([
            'imported' => $imported,
            'skipped' => $skipped,
            'errors' => $errors,
            'exam_status' => (string) $exam->fresh()->status,
        ], "{$imported} sonuç kaydedildi.");
    }

    // RESULTS
    public function resultsIndex(Request $request, int $examId): JsonResponse
    {
        if ($e = $this->ensureAccess()) return $e;
        $exam = OmrExam::where('tenant_id', $this->tenantId())
            ->with(['examCourses.course:id,name'])
            ->findOrFail($examId);
        $query = OmrResult::where('exam_id', $examId)
            ->with(['student:id,name,school_no,classroom_id', 'student.classroom:id,name']);
        if ($request->filled('classroom_id'))
            $query->whereHas('student', fn($q) => $q->where('classroom_id', (int)$request->get('classroom_id')));
        $query->orderBy('rank');
        $perPage = min((int)$request->get('per_page', 50), 200);
        $results = $query->paginate($perPage);

        $courseHeaders = $exam->examCourses
            ->sortBy(fn($row) => (int) ($row->sort_order ?? 0))
            ->map(fn($row) => [
                'course_id' => (int) $row->course_id,
                'course_name' => (string) ($row->course?->name ?? ('Ders ' . (int) $row->course_id)),
            ])
            ->values()
            ->toArray();

        if (empty($courseHeaders)) {
            $courseIds = collect($results->items())
                ->flatMap(fn($r) => array_keys((array) ($r->course_scores ?? [])))
                ->map(fn($id) => (int) $id)
                ->unique()
                ->values();
            $courseNames = OmrCourse::whereIn('id', $courseIds)->pluck('name', 'id');
            $courseHeaders = $courseIds->map(fn($id) => [
                'course_id' => $id,
                'course_name' => (string) ($courseNames[$id] ?? ('Ders ' . $id)),
            ])->toArray();
        }

        return $this->success(['results' => $results->items(), 'pagination' => [
            'current_page' => $results->currentPage(), 'last_page' => $results->lastPage(), 'total' => $results->total(),
        ], 'course_headers' => $courseHeaders]);
    }

    public function resultUpdate(Request $request, int $examId, int $resultId): JsonResponse
    {
        if ($e = $this->ensureAccess()) return $e;
        $exam = OmrExam::where('tenant_id', $this->tenantId())->findOrFail($examId);
        $result = OmrResult::where('exam_id', $examId)->findOrFail($resultId);

        $data = $request->validate([
            'student_id' => 'nullable|integer|exists:students,id',
            'course_scores' => 'nullable|array',
            'course_scores.*.correct' => 'required_with:course_scores|integer|min:0',
            'course_scores.*.wrong' => 'required_with:course_scores|integer|min:0',
        ]);

        $coeffMap = $this->buildExamCourseCoefficientMap($exam->id, $exam->exam_type);
        $penalty = $exam->wrong_penalty;
        $currentScores = (array) ($result->course_scores ?? []);
        $updatedScores = $currentScores;

        if (!empty($data['course_scores'])) {
            foreach ((array) $data['course_scores'] as $courseId => $score) {
                $cId = (int) $courseId;
                $correct = max(0, (int) ($score['correct'] ?? 0));
                $wrong = max(0, (int) ($score['wrong'] ?? 0));

                $answerLen = strlen((string) (($result->raw_answers ?? [])[(string) $cId] ?? (($result->raw_answers ?? [])[$cId] ?? '')));
                $blank = max(0, $answerLen - $correct - $wrong);
                $net = (float) $correct;
                if ($penalty !== null && $penalty > 0) {
                    $net = max(0.0, $correct - ($wrong / $penalty));
                }
                $point = round($net * ($coeffMap[$cId] ?? 1.0), 3);

                $updatedScores[$cId] = [
                    'correct' => $correct,
                    'wrong' => $wrong,
                    'blank' => $blank,
                    'net' => round($net, 3),
                    'point' => $point,
                ];
            }
        }

        $totalNet = collect($updatedScores)->sum(fn($row) => (float) ($row['net'] ?? 0));
        $totalPoint = collect($updatedScores)->sum(fn($row) => (float) ($row['point'] ?? 0));

        $payload = [
            'course_scores' => $updatedScores,
            'total_net' => round($totalNet, 3),
            'total_point' => round($totalPoint, 3),
            'calculated_at' => now(),
        ];

        if (!empty($data['student_id']) && (int) $data['student_id'] !== (int) $result->student_id) {
            $student = Student::where('tenant_id', $this->tenantId())->findOrFail((int) $data['student_id']);
            $payload['student_id'] = (int) $student->id;
            $payload['student_no'] = (string) ($student->school_no ?? $result->student_no);
        }

        $result->update($payload);
        $this->recalculateRanks($examId);

        return $this->success([
            'result' => $result->fresh()->load(['student:id,name,school_no,classroom_id', 'student.classroom:id,name']),
        ], 'Sonuç güncellendi.');
    }

    public function resultDestroy(int $examId, int $resultId): JsonResponse
    {
        if ($e = $this->ensureAccess()) return $e;
        OmrExam::where('tenant_id', $this->tenantId())->findOrFail($examId);
        $result = OmrResult::where('exam_id', $examId)->findOrFail($resultId);
        $result->delete();
        $this->recalculateRanks($examId);

        return $this->success([], 'Sonuç silindi.');
    }

    public function resultStudent(int $examId, int $studentId): JsonResponse
    {
        if ($e = $this->ensureAccess()) return $e;
        OmrExam::where('tenant_id', $this->tenantId())->findOrFail($examId);
        $result = OmrResult::where('exam_id', $examId)->where('student_id', $studentId)
            ->with(['student:id,name,school_no', 'exam'])->firstOrFail();

        $answerMap = $this->buildBookletAnswerMap($examId);
        $answerKeys = OmrAnswerKey::where('exam_id', $examId)
            ->with('topic:id,name,type')->get()->groupBy('course_id');

        $topicAnalysis = [];
        foreach ($answerKeys as $courseId => $keys) {
            $rawStr = $result->raw_answers[$courseId] ?? '';
            foreach ($keys as $ak) {
                $booklet = strtoupper((string) $result->booklet_type);
                $targetQ = match ($booklet) {
                    'B' => $ak->booklet_b_qno,
                    'C' => $ak->booklet_c_qno,
                    'D' => $ak->booklet_d_qno,
                    default => $ak->booklet_a_qno,
                };
                if (!$targetQ) continue;

                $given = strtoupper($rawStr[$targetQ - 1] ?? '');
                $expect = strtoupper((string) $ak->correct_answer);
                $status = in_array($given, ['', ' ', '-', '0']) ? 'blank' : ($given === $expect ? 'correct' : 'wrong');
                $tid = $ak->topic_id ?? 0;
                if (!isset($topicAnalysis[$courseId][$tid]))
                    $topicAnalysis[$courseId][$tid] = ['topic_id' => $tid, 'topic_name' => $ak->topic?->name ?? 'Belirtilmemiş', 'correct' => 0, 'wrong' => 0, 'blank' => 0];
                $topicAnalysis[$courseId][$tid][$status]++;
            }
        }
        return $this->success(['result' => $result, 'topic_analysis' => $topicAnalysis, 'parsed_fields' => $result->parsed_fields]);
    }

    // ANALYTICS
    public function analytics(Request $request, int $examId): JsonResponse
    {
        if ($e = $this->ensureAccess()) return $e;
        OmrExam::where('tenant_id', $this->tenantId())->findOrFail($examId);
        $query = OmrResult::where('exam_id', $examId);
        if ($request->filled('classroom_id'))
            $query->whereHas('student', fn($q) => $q->where('classroom_id', (int)$request->get('classroom_id')));

        $summary = (clone $query)->selectRaw(
            'COUNT(*) as total, AVG(total_net) as avg_net, MIN(total_net) as min_net, MAX(total_net) as max_net, STDDEV_POP(total_net) as stddev_net'
        )->first();

        $binSize = max(0.1, (float)$request->get('bin_size', 5));
        $distribution = (clone $query)
            ->selectRaw('FLOOR(total_net / ?) as bin_index, COUNT(*) as count', [$binSize])
            ->groupBy('bin_index')->orderBy('bin_index')->get()
            ->map(fn($r) => ['start' => round($r->bin_index * $binSize, 2), 'end' => round(($r->bin_index + 1) * $binSize, 2), 'count' => (int)$r->count])->values();

        $classAverages = (clone $query)
            ->join('students', 'students.id', '=', 'omr_results.student_id')
            ->join('classrooms', 'classrooms.id', '=', 'students.classroom_id')
            ->selectRaw('classrooms.id as classroom_id, classrooms.name as classroom_name, COUNT(*) as total, AVG(omr_results.total_net) as avg_net')
            ->groupBy('classrooms.id', 'classrooms.name')->orderByDesc('avg_net')->get();

        $resultsForAnalysis = (clone $query)
            ->select(['id', 'student_id', 'booklet_type', 'raw_answers', 'course_scores'])
            ->get();

        $courseAgg = [];
        foreach ($resultsForAnalysis as $result) {
            foreach ((array) ($result->course_scores ?? []) as $courseId => $score) {
                $cid = (int) $courseId;
                if (!isset($courseAgg[$cid])) {
                    $courseAgg[$cid] = [
                        'course_id' => $cid,
                        'total_net' => 0.0,
                        'total_point' => 0.0,
                        'correct' => 0,
                        'wrong' => 0,
                        'blank' => 0,
                        'student_count' => 0,
                    ];
                }

                $courseAgg[$cid]['total_net'] += (float) ($score['net'] ?? 0);
                $courseAgg[$cid]['total_point'] += (float) ($score['point'] ?? 0);
                $courseAgg[$cid]['correct'] += (int) ($score['correct'] ?? 0);
                $courseAgg[$cid]['wrong'] += (int) ($score['wrong'] ?? 0);
                $courseAgg[$cid]['blank'] += (int) ($score['blank'] ?? 0);
                $courseAgg[$cid]['student_count']++;
            }
        }

        $courseNames = OmrCourse::whereIn('id', array_keys($courseAgg))->pluck('name', 'id');
        $courseAverages = collect($courseAgg)
            ->map(function ($row) use ($courseNames) {
                $count = max(1, (int) $row['student_count']);
                return [
                    'course_id' => (int) $row['course_id'],
                    'course_name' => (string) ($courseNames[$row['course_id']] ?? ('Ders ' . $row['course_id'])),
                    'avg_net' => round($row['total_net'] / $count, 2),
                    'avg_point' => round($row['total_point'] / $count, 2),
                    'correct' => (int) $row['correct'],
                    'wrong' => (int) $row['wrong'],
                    'blank' => (int) $row['blank'],
                ];
            })
            ->sortByDesc('avg_net')
            ->values();

        $answerKeys = OmrAnswerKey::where('exam_id', $examId)
            ->with(['topic:id,name,type', 'course:id,name'])
            ->get();

        $questionStats = [];
        foreach ($answerKeys as $ak) {
            $courseId = (int) $ak->course_id;
            $canonicalQno = (int) $ak->question_no;
            $qKey = $courseId . '-' . $canonicalQno;
            if (!isset($questionStats[$qKey])) {
                $questionStats[$qKey] = [
                    'course_id' => $courseId,
                    'course_name' => (string) ($ak->course?->name ?? ''),
                    'question_no' => $canonicalQno,
                    'topic_id' => (int) ($ak->topic_id ?? 0),
                    'topic_name' => (string) ($ak->topic?->name ?? 'Belirtilmemiş'),
                    'correct' => 0,
                    'wrong' => 0,
                    'blank' => 0,
                    'total' => 0,
                ];
            }
        }

        foreach ($resultsForAnalysis as $result) {
            $booklet = strtoupper((string) $result->booklet_type);

            foreach ($answerKeys as $ak) {
                $courseId = (int) $ak->course_id;
                $canonicalQno = (int) $ak->question_no;
                $qKey = $courseId . '-' . $canonicalQno;

                $mappedQno = match ($booklet) {
                    'B' => $ak->booklet_b_qno,
                    'C' => $ak->booklet_c_qno,
                    'D' => $ak->booklet_d_qno,
                    default => $ak->booklet_a_qno,
                };
                if (!$mappedQno) {
                    continue;
                }

                $rawStr = (string) ($result->raw_answers[$courseId] ?? '');
                $given = strtoupper($rawStr[$mappedQno - 1] ?? '');
                $expect = strtoupper((string) $ak->correct_answer);

                if (in_array($given, ['', ' ', '-', '0'], true)) {
                    $questionStats[$qKey]['blank']++;
                } elseif ($given === $expect) {
                    $questionStats[$qKey]['correct']++;
                } else {
                    $questionStats[$qKey]['wrong']++;
                }
                $questionStats[$qKey]['total']++;
            }
        }

        $questionDifficulty = collect($questionStats)
            ->map(function ($row) {
                $total = max(1, (int) $row['total']);
                $row['wrong_ratio'] = round(($row['wrong'] / $total) * 100, 2);
                $row['blank_ratio'] = round(($row['blank'] / $total) * 100, 2);
                $row['success_ratio'] = round(($row['correct'] / $total) * 100, 2);
                return $row;
            })
            ->sortByDesc('wrong_ratio')
            ->values();

        $topicDifficulty = $questionDifficulty
            ->groupBy('topic_id')
            ->map(function ($rows) {
                $total = (int) $rows->sum('total');
                $wrong = (int) $rows->sum('wrong');
                $blank = (int) $rows->sum('blank');
                return [
                    'topic_id' => (int) ($rows->first()['topic_id'] ?? 0),
                    'topic_name' => (string) ($rows->first()['topic_name'] ?? 'Belirtilmemiş'),
                    'total' => $total,
                    'wrong' => $wrong,
                    'blank' => $blank,
                    'wrong_ratio' => $total > 0 ? round(($wrong / $total) * 100, 2) : 0,
                ];
            })
            ->sortByDesc('wrong_ratio')
            ->values();

        $studentTopicAnalysis = [];
        if ($request->filled('student_id')) {
            $studentResult = (clone $query)
                ->where('student_id', (int) $request->get('student_id'))
                ->first();
            if ($studentResult) {
                $studentTopicAnalysis = $this->buildStudentTopicAnalysis($studentResult, $answerKeys);
            }
        }

        // Extended descriptive stats (median, mode, variance)
        $allNets = (clone $query)->orderBy('total_net')->pluck('total_net')->map(fn($v) => (float)$v)->values();
        $extStats = $this->calcDescriptiveStats($allNets->toArray());

        return $this->success($this->utf8izeMixed([
            'summary' => [
                'total'      => (int)($summary->total ?? 0),
                'avg_net'    => round((float)($summary->avg_net ?? 0), 2),
                'median_net' => $extStats['median'],
                'mode_net'   => $extStats['mode'],
                'min_net'    => round((float)($summary->min_net ?? 0), 2),
                'max_net'    => round((float)($summary->max_net ?? 0), 2),
                'stddev_net' => round((float)($summary->stddev_net ?? 0), 2),
                'variance'   => $extStats['variance'],
            ],
            'distribution'           => $distribution,
            'class_averages'         => $classAverages,
            'course_averages'        => $courseAverages,
            'most_missed_questions'  => $questionDifficulty->take(20)->values(),
            'most_missed_topics'     => $topicDifficulty->take(20)->values(),
            'student_topic_analysis' => $studentTopicAnalysis,
        ]));
    }

    // ANALYTICS – Level 2: Class drill-down (supports multiple exam_ids)
    public function analyticsClass(Request $request, int $examId): JsonResponse
    {
        if ($e = $this->ensureAccess()) return $e;
        $tenantId = $this->tenantId();

        $classroomId = (int) $request->get('classroom_id');
        if (!$classroomId) return $this->error('classroom_id gerekli.', [], 422);

        // Collect exam IDs: if exam_ids[] provided use those, otherwise use route examId
        $examIds = array_filter(array_map('intval', (array)($request->get('exam_ids', []))));
        if (empty($examIds)) $examIds = [$examId];

        // Validate all requested exams belong to this tenant
        $validIds = OmrExam::where('tenant_id', $tenantId)->whereIn('id', $examIds)->pluck('id')->toArray();
        if (empty($validIds)) return $this->error('Geçerli sınav bulunamadı.', [], 422);

        // Exam-wide average across all selected exams
        $examAvg = round((float)(OmrResult::whereIn('exam_id', $validIds)->avg('total_net') ?? 0), 2);

        // Class results across all selected exams
        $classResults = OmrResult::whereIn('exam_id', $validIds)
            ->whereHas('student', fn($q) => $q->where('classroom_id', $classroomId))
            ->with(['student:id,name,school_no,classroom_id', 'student.classroom:id,name'])
            ->orderByDesc('total_net')
            ->get();

        if ($classResults->isEmpty()) {
            return $this->success(['class_avg' => 0, 'exam_avg' => $examAvg, 'students' => [], 'below_avg' => [], 'course_averages' => [], 'topic_difficulty' => [], 'exam_ids' => $validIds]);
        }

        // Aggregate nets (average per student across exams)
        $netsByStudent = $classResults->groupBy('student_id')->map(fn($rows) => round($rows->avg('total_net'), 2));
        $classNets  = $netsByStudent->values()->toArray();
        $classAvg   = round(array_sum($classNets) / max(1, count($classNets)), 2);
        $extStats   = $this->calcDescriptiveStats($classNets);

        // Students list: one row per student, avg across exams
        $students = $netsByStudent->map(function ($avgNet, $studentId) use ($classResults, $classAvg) {
            $firstResult = $classResults->firstWhere('student_id', $studentId);
            return [
                'id'          => $studentId,
                'name'        => $firstResult?->student?->name ?? '',
                'school_no'   => $firstResult?->student?->school_no ?? '',
                'total_net'   => $avgNet,
                'total_point' => round($classResults->where('student_id', $studentId)->avg('total_point'), 2),
                'rank'        => 0,
                'below_avg'   => $avgNet < $classAvg,
                'result_id'   => $firstResult?->id,
            ];
        })->sortByDesc('total_net')->values()->map(function ($s, $idx) {
            $s['rank'] = $idx + 1;
            return $s;
        });

        $belowAvg = $students->filter(fn($s) => $s['below_avg'])->values();

        // Course averages aggregated across all results
        $courseAgg = [];
        foreach ($classResults as $result) {
            foreach ((array)($result->course_scores ?? []) as $courseId => $score) {
                $cid = (int)$courseId;
                if (!isset($courseAgg[$cid])) $courseAgg[$cid] = ['total_net' => 0.0, 'correct' => 0, 'wrong' => 0, 'blank' => 0, 'count' => 0];
                $courseAgg[$cid]['total_net'] += (float)($score['net'] ?? 0);
                $courseAgg[$cid]['correct']   += (int)($score['correct'] ?? 0);
                $courseAgg[$cid]['wrong']     += (int)($score['wrong'] ?? 0);
                $courseAgg[$cid]['blank']     += (int)($score['blank'] ?? 0);
                $courseAgg[$cid]['count']++;
            }
        }
        $courseNames = OmrCourse::whereIn('id', array_keys($courseAgg))->pluck('name', 'id');
        $courseAverages = collect($courseAgg)->map(function ($row, $cid) use ($courseNames) {
            $cnt = max(1, $row['count']);
            return [
                'course_id'   => (int)$cid,
                'course_name' => (string)($courseNames[$cid] ?? ('Ders ' . $cid)),
                'avg_net'     => round($row['total_net'] / $cnt, 2),
                'correct'     => (int)$row['correct'],
                'wrong'       => (int)$row['wrong'],
                'blank'       => (int)$row['blank'],
            ];
        })->sortByDesc('avg_net')->values();

        // Topic difficulty across all selected exams
        $answerKeys = OmrAnswerKey::whereIn('exam_id', $validIds)->with(['topic:id,name', 'course:id,name'])->get();
        $topicDifficulty = $this->buildTopicDifficulty($classResults, $answerKeys);

        return $this->success($this->utf8izeMixed([
            'class_avg'       => $classAvg,
            'exam_avg'        => $examAvg,
            'class_stats'     => $extStats,
            'student_count'   => count($classNets),
            'students'        => $students->values(),
            'below_avg'       => $belowAvg->values(),
            'course_averages' => $courseAverages,
            'topic_difficulty'=> $topicDifficulty->take(20)->values(),
            'exam_ids'        => $validIds,
            'exam_count'      => count($validIds),
        ]));
    }

    // ANALYTICS – Level 3: Student drill-down (supports multiple exam_ids)
    public function analyticsStudent(Request $request, int $examId): JsonResponse
    {
        if ($e = $this->ensureAccess()) return $e;
        $tenantId = $this->tenantId();

        $studentId = (int) $request->get('student_id');
        if (!$studentId) return $this->error('student_id gerekli.', [], 422);

        // Collect exam IDs: if exam_ids[] provided use those, otherwise use route examId
        $examIds = array_filter(array_map('intval', (array)($request->get('exam_ids', []))));
        if (empty($examIds)) $examIds = [$examId];
        $validIds = OmrExam::where('tenant_id', $tenantId)->whereIn('id', $examIds)->pluck('id')->toArray();
        if (empty($validIds)) return $this->error('Geçerli sınav bulunamadı.', [], 422);

        // Fetch all results for this student across selected exams
        $studentResults = OmrResult::whereIn('exam_id', $validIds)
            ->where('student_id', $studentId)
            ->with(['student:id,name,school_no,classroom_id', 'student.classroom:id,name', 'exam:id,name,exam_date'])
            ->get();

        if ($studentResults->isEmpty()) {
            return $this->error('Öğrenci bu sınavlarda sonuç bulunamadı.', [], 404);
        }

        $firstResult = $studentResults->first();
        $student = $firstResult->student;
        $classroomId = $student?->classroom_id;

        // Per-exam summary list (for trend table)
        $examNames = OmrExam::whereIn('id', $validIds)->pluck('name', 'id');
        $examSummaries = $studentResults->map(function ($r) use ($examNames) {
            return [
                'exam_id'     => $r->exam_id,
                'exam_name'   => (string)($examNames[$r->exam_id] ?? ('Sınav ' . $r->exam_id)),
                'total_net'   => round((float)$r->total_net, 2),
                'total_point' => round((float)$r->total_point, 2),
                'rank'        => (int)$r->rank,
                'booklet_type'=> $r->booklet_type,
            ];
        })->sortBy('exam_id')->values();

        // Aggregated stats across selected exams
        $allStudentNets = $studentResults->pluck('total_net')->map(fn($v) => (float)$v)->toArray();
        $avgNet   = round(array_sum($allStudentNets) / max(1, count($allStudentNets)), 2);
        $avgPoint = round($studentResults->avg('total_point'), 2);

        // Exam-wide stats (across all selected exams, all students)
        $allNets = OmrResult::whereIn('exam_id', $validIds)
            ->orderBy('total_net')->pluck('total_net')->map(fn($v) => (float)$v)->values()->toArray();
        $examStats = $this->calcDescriptiveStats($allNets);
        $examTotal = count($allNets);
        $examAvg   = round((float)($examStats['mean'] ?? 0), 2);

        // Class average across selected exams
        $classAvg = 0.0;
        if ($classroomId) {
            $classAvg = round((float)(OmrResult::whereIn('exam_id', $validIds)
                ->whereHas('student', fn($q) => $q->where('classroom_id', $classroomId))
                ->avg('total_net') ?? 0), 2);
        }

        // Percentile based on aggregated avg net
        $belowCount = count(array_filter($allNets, fn($n) => $n < $avgNet));
        $percentile = $examTotal > 0 ? round(($belowCount / $examTotal) * 100, 1) : 0;

        // Aggregate course scores across all results
        $courseAgg = [];
        foreach ($studentResults as $result) {
            foreach ((array)($result->course_scores ?? []) as $cid => $score) {
                $cid = (int)$cid;
                if (!isset($courseAgg[$cid])) $courseAgg[$cid] = ['net' => 0.0, 'correct' => 0, 'wrong' => 0, 'blank' => 0, 'count' => 0];
                $courseAgg[$cid]['net']     += (float)($score['net'] ?? 0);
                $courseAgg[$cid]['correct'] += (int)($score['correct'] ?? 0);
                $courseAgg[$cid]['wrong']   += (int)($score['wrong'] ?? 0);
                $courseAgg[$cid]['blank']   += (int)($score['blank'] ?? 0);
                $courseAgg[$cid]['count']++;
            }
        }
        $courseNames = OmrCourse::whereIn('id', array_keys($courseAgg))->pluck('name', 'id');
        $courseScores = collect($courseAgg)->map(function ($row, $cid) use ($courseNames) {
            $cnt = max(1, $row['count']);
            return [
                'course_id'   => (int)$cid,
                'course_name' => (string)($courseNames[$cid] ?? ('Ders ' . $cid)),
                'net'         => round($row['net'] / $cnt, 2),
                'correct'     => $row['correct'],
                'wrong'       => $row['wrong'],
                'blank'       => $row['blank'],
            ];
        })->values();

        // Aggregate wrong/blank questions across all exams
        $answerKeys = OmrAnswerKey::whereIn('exam_id', $validIds)
            ->with(['topic:id,name,type', 'course:id,name'])
            ->orderBy('course_id')->orderBy('question_no')
            ->get()->groupBy('exam_id');

        $questionDetail = [];
        foreach ($studentResults as $result) {
            $keys = $answerKeys->get($result->exam_id, collect());
            $booklet = strtoupper((string)$result->booklet_type);
            foreach ($keys as $ak) {
                $mappedQno = match ($booklet) {
                    'B' => $ak->booklet_b_qno,
                    'C' => $ak->booklet_c_qno,
                    'D' => $ak->booklet_d_qno,
                    default => $ak->booklet_a_qno,
                };
                if (!$mappedQno) continue;
                $rawStr = (string)($result->raw_answers[(string)$ak->course_id] ?? $result->raw_answers[$ak->course_id] ?? '');
                $given  = strtoupper($rawStr[$mappedQno - 1] ?? '');
                $expect = strtoupper((string)$ak->correct_answer);
                $status = in_array($given, ['', ' ', '-', '0'], true) ? 'blank' : ($given === $expect ? 'correct' : 'wrong');
                if ($status !== 'correct') {
                    $questionDetail[] = [
                        'exam_id'        => $result->exam_id,
                        'course_id'      => (int)$ak->course_id,
                        'course_name'    => (string)($ak->course?->name ?? ''),
                        'question_no'    => (int)$ak->question_no,
                        'topic_id'       => (int)($ak->topic_id ?? 0),
                        'topic_name'     => (string)($ak->topic?->name ?? 'Belirtilmemiş'),
                        'given_answer'   => $given ?: '-',
                        'correct_answer' => $expect,
                        'status'         => $status,
                    ];
                }
            }
        }

        // Topic analysis from first result (for radar)
        $firstKeys = $answerKeys->get($firstResult->exam_id, collect());
        $topicAnalysis = $this->buildStudentTopicAnalysis($firstResult, $firstKeys);

        // Aggregate result object (averaged)
        $aggregatedResult = [
            'id'           => $firstResult->id,
            'total_net'    => $avgNet,
            'total_point'  => $avgPoint,
            'rank'         => (int)$firstResult->rank,
            'booklet_type' => $firstResult->booklet_type,
        ];

        return $this->success($this->utf8izeMixed([
            'student'               => $student,
            'result'                => $aggregatedResult,
            'exam_summaries'        => $examSummaries,
            'exam_stats'            => $examStats,
            'exam_avg'              => $examAvg,
            'class_avg'             => $classAvg,
            'percentile'            => $percentile,
            'exam_total'            => $examTotal,
            'course_scores'         => $courseScores->values(),
            'wrong_blank_questions' => $questionDetail,
            'topic_analysis'        => $topicAnalysis,
            'exam_ids'              => $validIds,
            'exam_count'            => count($validIds),
        ]));
    }

    // ANALYTICS – Correlation Matrix (Pearson between courses)
    public function analyticsCorrelation(Request $request, int $examId): JsonResponse
    {
        if ($e = $this->ensureAccess()) return $e;
        OmrExam::where('tenant_id', $this->tenantId())->findOrFail($examId);

        $query = OmrResult::where('exam_id', $examId)->select(['course_scores']);
        if ($request->filled('classroom_id'))
            $query->whereHas('student', fn($q) => $q->where('classroom_id', (int)$request->get('classroom_id')));

        $results = $query->get();
        if ($results->count() < 3) {
            return $this->success(['matrix' => [], 'course_names' => [], 'message' => 'Yeterli veri yok (min 3 öğrenci).']);
        }

        // Collect per-course net arrays
        $courseNets = [];
        foreach ($results as $r) {
            foreach ((array)($r->course_scores ?? []) as $cid => $score) {
                $courseNets[(int)$cid][] = (float)($score['net'] ?? 0);
            }
        }

        $courseIds = array_keys($courseNets);
        $courseNames = OmrCourse::whereIn('id', $courseIds)->pluck('name', 'id');

        // Pearson correlation matrix
        $matrix = [];
        foreach ($courseIds as $ci) {
            $row = [];
            foreach ($courseIds as $cj) {
                $row[(int)$cj] = round($this->pearsonCorrelation($courseNets[$ci], $courseNets[$cj]), 3);
            }
            $matrix[(int)$ci] = $row;
        }

        $courseLabels = collect($courseIds)->map(fn($id) => [
            'id'   => (int)$id,
            'name' => (string)($courseNames[$id] ?? ('Ders ' . $id)),
        ])->values();

        return $this->success($this->utf8izeMixed([
            'matrix'       => $matrix,
            'course_labels'=> $courseLabels,
        ]));
    }

    // ANALYTICS – Multi-exam comparison
    public function analyticsCompare(Request $request, int $examId): JsonResponse
    {
        if ($e = $this->ensureAccess()) return $e;
        OmrExam::where('tenant_id', $this->tenantId())->findOrFail($examId);

        $examIds = array_filter(array_map('intval', (array)$request->get('exam_ids', [])));
        if (count($examIds) < 2) return $this->error('En az 2 sınav seçin.', [], 422);

        // Validate all exams belong to tenant
        $validIds = OmrExam::where('tenant_id', $this->tenantId())
            ->whereIn('id', $examIds)->pluck('id')->toArray();

        $exams = OmrExam::whereIn('id', $validIds)->orderBy('exam_date')->get();

        $studentId  = $request->filled('student_id')  ? (int)$request->get('student_id')  : null;
        $classroomId= $request->filled('classroom_id') ? (int)$request->get('classroom_id') : null;

        $series = [];
        foreach ($exams as $exam) {
            $q = OmrResult::where('exam_id', $exam->id);
            if ($classroomId) $q->whereHas('student', fn($sq) => $sq->where('classroom_id', $classroomId));
            if ($studentId)   $q->where('student_id', $studentId);

            $agg = (clone $q)->selectRaw('AVG(total_net) as avg_net, MIN(total_net) as min_net, MAX(total_net) as max_net, COUNT(*) as total')->first();

            // Per-course averages
            $courseAgg = [];
            foreach ((clone $q)->select(['course_scores'])->get() as $r) {
                foreach ((array)($r->course_scores ?? []) as $cid => $score) {
                    $cid = (int)$cid;
                    if (!isset($courseAgg[$cid])) $courseAgg[$cid] = ['sum' => 0.0, 'count' => 0];
                    $courseAgg[$cid]['sum']   += (float)($score['net'] ?? 0);
                    $courseAgg[$cid]['count']++;
                }
            }
            $courseAvgs = collect($courseAgg)->map(fn($row, $cid) => [
                'course_id' => (int)$cid,
                'avg_net'   => round($row['sum'] / max(1, $row['count']), 2),
            ])->values();

            // Linear regression slope for this exam's net distribution
            $nets = (clone $q)->orderBy('rank')->pluck('total_net')->map(fn($v) => (float)$v)->values()->toArray();
            $regression = $this->linearRegression(array_keys($nets), $nets);

            $series[] = [
                'exam_id'     => (int)$exam->id,
                'exam_name'   => (string)$exam->name,
                'exam_date'   => $exam->exam_date ? $exam->exam_date->format('Y-m-d') : null,
                'exam_type'   => (string)$exam->exam_type,
                'avg_net'     => round((float)($agg->avg_net ?? 0), 2),
                'min_net'     => round((float)($agg->min_net ?? 0), 2),
                'max_net'     => round((float)($agg->max_net ?? 0), 2),
                'total'       => (int)($agg->total ?? 0),
                'course_avgs' => $courseAgg ? $courseAvgs : [],
                'regression'  => $regression,
            ];
        }

        // All course names across all exams
        $allCourseIds = collect($series)->flatMap(fn($s) => collect($s['course_avgs'])->pluck('course_id'))->unique()->values()->toArray();
        $courseNames  = OmrCourse::whereIn('id', $allCourseIds)->pluck('name', 'id');
        $courseLabels = collect($allCourseIds)->map(fn($id) => ['id' => (int)$id, 'name' => (string)($courseNames[$id] ?? ('Ders ' . $id))])->values();

        return $this->success($this->utf8izeMixed([
            'series'        => $series,
            'course_labels' => $courseLabels,
        ]));
    }

    // ─── Private stat helpers ───────────────────────────────────────────────

    private function calcDescriptiveStats(array $values): array
    {
        $n = count($values);
        if ($n === 0) return ['mean' => 0, 'median' => 0, 'mode' => 0, 'variance' => 0, 'stddev' => 0];

        sort($values);
        $mean = array_sum($values) / $n;

        // Median
        $mid = intdiv($n, 2);
        $median = ($n % 2 === 0) ? round(($values[$mid - 1] + $values[$mid]) / 2, 2) : round($values[$mid], 2);

        // Mode (most frequent rounded-to-1dp value)
        $freq = [];
        foreach ($values as $v) {
            $key = (string)round($v, 1);
            $freq[$key] = ($freq[$key] ?? 0) + 1;
        }
        arsort($freq);
        $mode = (float)array_key_first($freq);

        // Variance
        $variance = array_sum(array_map(fn($v) => ($v - $mean) ** 2, $values)) / $n;

        return [
            'mean'     => round($mean, 2),
            'median'   => $median,
            'mode'     => round($mode, 2),
            'variance' => round($variance, 2),
            'stddev'   => round(sqrt($variance), 2),
        ];
    }

    private function pearsonCorrelation(array $x, array $y): float
    {
        $n = min(count($x), count($y));
        if ($n < 2) return 0.0;
        $x = array_slice($x, 0, $n);
        $y = array_slice($y, 0, $n);

        $meanX = array_sum($x) / $n;
        $meanY = array_sum($y) / $n;

        $num = 0.0; $denX = 0.0; $denY = 0.0;
        for ($i = 0; $i < $n; $i++) {
            $dx = $x[$i] - $meanX;
            $dy = $y[$i] - $meanY;
            $num  += $dx * $dy;
            $denX += $dx * $dx;
            $denY += $dy * $dy;
        }
        $den = sqrt($denX * $denY);
        return $den > 0 ? $num / $den : 0.0;
    }

    private function linearRegression(array $x, array $y): array
    {
        $n = min(count($x), count($y));
        if ($n < 2) return ['slope' => 0, 'intercept' => 0, 'r_squared' => 0];

        $meanX = array_sum($x) / $n;
        $meanY = array_sum($y) / $n;

        $num = 0.0; $den = 0.0;
        for ($i = 0; $i < $n; $i++) {
            $num += ($x[$i] - $meanX) * ($y[$i] - $meanY);
            $den += ($x[$i] - $meanX) ** 2;
        }
        $slope     = $den > 0 ? $num / $den : 0.0;
        $intercept = $meanY - $slope * $meanX;

        // R²
        $ssTot = array_sum(array_map(fn($yi) => ($yi - $meanY) ** 2, $y));
        $ssRes = 0.0;
        for ($i = 0; $i < $n; $i++) $ssRes += ($y[$i] - ($slope * $x[$i] + $intercept)) ** 2;
        $rSquared = $ssTot > 0 ? 1 - $ssRes / $ssTot : 0.0;

        return ['slope' => round($slope, 4), 'intercept' => round($intercept, 4), 'r_squared' => round($rSquared, 4)];
    }

    private function buildTopicDifficulty($results, $answerKeys): \Illuminate\Support\Collection
    {
        $topicStats = [];
        foreach ($results as $result) {
            $booklet = strtoupper((string)$result->booklet_type);
            foreach ($answerKeys as $ak) {
                $mappedQno = match ($booklet) {
                    'B' => $ak->booklet_b_qno,
                    'C' => $ak->booklet_c_qno,
                    'D' => $ak->booklet_d_qno,
                    default => $ak->booklet_a_qno,
                };
                if (!$mappedQno) continue;
                $rawStr = (string)($result->raw_answers[(string)$ak->course_id] ?? $result->raw_answers[$ak->course_id] ?? '');
                $given  = strtoupper($rawStr[$mappedQno - 1] ?? '');
                $expect = strtoupper((string)$ak->correct_answer);
                $status = in_array($given, ['', ' ', '-', '0'], true) ? 'blank' : ($given === $expect ? 'correct' : 'wrong');
                $tid    = (int)($ak->topic_id ?? 0);
                if (!isset($topicStats[$tid])) {
                    $topicStats[$tid] = [
                        'topic_id'   => $tid,
                        'topic_name' => (string)($ak->topic?->name ?? 'Belirtilmemiş'),
                        'course_id'  => (int)$ak->course_id,
                        'course_name'=> (string)($ak->course?->name ?? ''),
                        'correct' => 0, 'wrong' => 0, 'blank' => 0, 'total' => 0,
                    ];
                }
                $topicStats[$tid][$status]++;
                $topicStats[$tid]['total']++;
            }
        }
        return collect($topicStats)->map(function ($row) {
            $total = max(1, $row['total']);
            $row['wrong_ratio']   = round(($row['wrong'] / $total) * 100, 2);
            $row['success_ratio'] = round(($row['correct'] / $total) * 100, 2);
            return $row;
        })->sortByDesc('wrong_ratio')->values();
    }

    // SESSION MERGING
    public function sessionsIndex(): JsonResponse
    {
        if ($e = $this->ensureAccess()) return $e;
        return $this->success(['sessions' => OmrSession::where('tenant_id', $this->tenantId())->orderByDesc('id')->get()]);
    }

    public function sessionsStore(Request $request): JsonResponse
    {
        if ($e = $this->ensureAccess()) return $e;
        $data = $request->validate([
            'name' => 'required|string|max:255',
            'exam_type' => 'required|string|max:30',
            'exam_date' => 'nullable|date',
            'exam_ids' => 'required|array|min:2',
            'exam_ids.*' => 'integer|exists:omr_exams,id',
        ]);
        $data['tenant_id'] = $this->tenantId();
        $data['created_by'] = auth()->id();
        $session = OmrSession::create($data);
        $this->calculateSession($session);
        return $this->success(['session' => $session->fresh()], 'Oturum oluşturuldu ve hesaplandı.', 201);
    }

    public function sessionsShow(int $id): JsonResponse
    {
        if ($e = $this->ensureAccess()) return $e;
        $session = OmrSession::where('tenant_id', $this->tenantId())->findOrFail($id);
        return $this->success(['session' => $session]);
    }

    public function sessionsRecalculate(int $id): JsonResponse
    {
        if ($e = $this->ensureAccess()) return $e;
        $session = OmrSession::where('tenant_id', $this->tenantId())->findOrFail($id);
        $this->calculateSession($session);
        return $this->success(['session' => $session->fresh()], 'Oturum yeniden hesaplandı.');
    }

    public function sessionsDestroy(int $id): JsonResponse
    {
        if ($e = $this->ensureAccess()) return $e;
        OmrSession::where('tenant_id', $this->tenantId())->findOrFail($id)->delete();
        return $this->success([], 'Oturum silindi.');
    }

    // ─── REPORT CARD ──────────────────────────────────────────────────────────

    /**
     * Build a single student's card data from one or more OmrExam records.
     * $exams: Collection of OmrExam (with loaded examCourses.course & answerKeys.topic)
     * $result: OmrResult (single exam) OR null for multi-exam session card
     * $results: array keyed by exam_id -> OmrResult (for multi-exam)
     * $schoolRank / $schoolTotal / $classRank / $classTotal: pre-computed rank info
     */
    private function buildCardData(
        \Illuminate\Support\Collection $exams,
        array                          $resultsByExamId,
        Student                        $student,
        ?int                           $schoolRank,
        ?int                           $schoolTotal,
        ?int                           $classRank,
        ?int                           $classTotal,
        string                         $sessionName,
        string                         $season = ''
    ): array {
        $totalNet   = 0.0;
        $totalPoint = 0.0;
        $totalCorrect = 0;
        $totalWrong   = 0;
        $totalBlank   = 0;

        $courseRows  = [];
        $answerRows  = [];
        $questionTopicRows = [];
        $sessionRows = [];
        $examsMeta   = [];

        foreach ($exams as $exam) {
            $result = $resultsByExamId[$exam->id] ?? null;

            $examsMeta[] = [
                'name'      => $exam->name,
                'session'   => $exam->session,
                'exam_date' => $exam->exam_date?->format('d.m.Y'),
            ];

            // Per-session summary row (for multi-exam display)
            $sessRow = [
                'name'        => $exam->session ?? $exam->name,
                'total_net'   => $result?->total_net,
                'total_point' => $result?->total_point,
                'rank'        => $result?->rank,
                'exam_total'  => $result ? OmrResult::where('exam_id', $exam->id)->count() : null,
                'booklet_type'=> $result?->booklet_type,
            ];
            $sessionRows[] = $sessRow;

            if (!$result) {
                // No result for this exam – add N/A rows for its courses
                foreach ($exam->examCourses as $ec) {
                    $courseRows[] = [
                        'course_name' => $ec->course?->name ?? "Ders #{$ec->course_id}",
                        'session'     => $exam->session,
                        'correct'     => null,
                        'wrong'       => null,
                        'blank'       => null,
                        'net'         => null,
                    ];
                }
                continue;
            }

            $totalNet   += (float) $result->total_net;
            $totalPoint += (float) $result->total_point;

            // Course score rows
            $scores = (array) ($result->course_scores ?? []);
            foreach ($exam->examCourses->sortBy('sort_order') as $ec) {
                $cid   = (int) $ec->course_id;
                $score = $scores[$cid] ?? null;
                $courseRows[] = [
                    'course_name' => $ec->course?->name ?? "Ders #{$cid}",
                    'session'     => $exam->session,
                    'correct'     => $score['correct'] ?? null,
                    'wrong'       => $score['wrong']   ?? null,
                    'blank'       => $score['blank']   ?? null,
                    'net'         => isset($score['net']) ? (float) $score['net'] : null,
                ];
                $totalCorrect += (int) ($score['correct'] ?? 0);
                $totalWrong   += (int) ($score['wrong']   ?? 0);
                $totalBlank   += (int) ($score['blank']   ?? 0);
            }

            // Answer key comparison rows + topic/kazanım analysis (question-level unique)
            $answerKeys = OmrAnswerKey::where('exam_id', $exam->id)
                ->with(['topic:id,name', 'course:id,name'])
                ->orderBy('course_id')->orderBy('question_no')
                ->get();

            // Group by unique question key to avoid duplicated rows when same question has multi-topic mappings
            $questionGroups = $answerKeys->groupBy(fn($ak) => ((int) $ak->course_id) . '_' . ((int) $ak->question_no));

            $booklet = strtoupper((string) $result->booklet_type);
            foreach ($questionGroups as $qGroup) {
                /** @var OmrAnswerKey $first */
                $first = $qGroup->first();
                if (!$first) {
                    continue;
                }

                $courseId = (int) $first->course_id;
                $rawStr   = (string) ($result->raw_answers[$courseId] ?? '');
                $targetQ  = match ($booklet) {
                    'B' => $first->booklet_b_qno,
                    'C' => $first->booklet_c_qno,
                    'D' => $first->booklet_d_qno,
                    default => $first->booklet_a_qno,
                };
                if (!$targetQ) continue;

                $given  = strtoupper($rawStr[$targetQ - 1] ?? '');
                $expect = strtoupper((string) $first->correct_answer);
                $status = in_array($given, ['', ' ', '-', '0'], true)
                    ? 'blank' : ($given === $expect ? 'correct' : 'wrong');

                $topicNames = $qGroup
                    ->map(fn($item) => trim((string) ($item->topic?->name ?? '')))
                    ->filter(fn($name) => $name !== '')
                    ->unique()
                    ->values()
                    ->all();
                $topicLabel = count($topicNames) > 0 ? implode(', ', $topicNames) : null;

                // Cevap karşılaştırma satırı
                $answerRows[] = [
                    'exam_name'    => $exam->session ?? $exam->name,
                    'course_name'  => $first->course?->name ?? '',
                    'question_no'  => (int) $first->question_no,
                    'given_answer' => $given === '' ? '—' : $given,
                    'correct_answer' => $expect,
                    'status'       => $status,
                    'topic_name'   => $topicLabel,
                ];

                // Kazanım analizi: soru bazlı tek satır (multi-topic varsa virgülle birleştirilir)
                if ($topicLabel !== null) {
                    $questionTopicRows[] = [
                        'topic_name'  => $topicLabel,
                        'course_name' => $first->course?->name ?? '',
                        'correct'     => $status === 'correct' ? 1 : 0,
                        'wrong'       => $status === 'wrong' ? 1 : 0,
                        'blank'       => $status === 'blank' ? 1 : 0,
                    ];
                }
            }
        }

        // percentile in first exam (or combined)
        $percentile = null;
        if ($schoolTotal && $schoolRank) {
            $percentile = round((($schoolTotal - $schoolRank) / $schoolTotal) * 100, 1);
        }

        // Kazanım: topic_name boş/null olanları hariç tut; soru bazlı unique satırlar
        $filteredTopicRows = array_values(array_filter(
            $questionTopicRows,
            fn($row) => !empty($row['topic_name'])
        ));

        return [
            'student_name'  => $student->name,
            'student_no'    => $student->school_no,
            'classroom'     => $student->classroom?->name,
            'session_name'  => $sessionName,
            'season'        => $season,
            'exams_meta'    => $examsMeta,
            'sessions'      => $sessionRows,
            'total_net'     => $totalNet,
            'total_point'   => $totalPoint,
            'total_correct' => $totalCorrect,
            'total_wrong'   => $totalWrong,
            'total_blank'   => $totalBlank,
            'school_rank'   => $schoolRank,
            'school_total'  => $schoolTotal,
            'class_rank'    => $classRank,
            'class_total'   => $classTotal,
            'percentile'    => $percentile,
            'course_rows'   => $courseRows,
            'topic_rows'    => $filteredTopicRows,
            'answer_rows'   => $answerRows,
        ];
    }

    /**
     * Pre-load exam collection with required relations.
     */
    private function loadExamsForCard(array $examIds): \Illuminate\Support\Collection
    {
        return OmrExam::whereIn('id', $examIds)
            ->with(['examCourses' => fn($q) => $q->with('course:id,name')->orderBy('sort_order')])
            ->get()
            ->keyBy('id');
    }

    /**
     * Compute school & class ranks for a student within a set of exams.
     * For multi-exam: uses combined total_net sum. For single exam: uses rank column.
     */
    private function computeStudentRanks(
        int    $studentId,
        array  $examIds,
        ?int   $classroomId
    ): array {
        if (count($examIds) === 1) {
            $result = OmrResult::where('exam_id', $examIds[0])
                ->where('student_id', $studentId)->first();
            $schoolTotal = OmrResult::where('exam_id', $examIds[0])->count();
            $schoolRank  = $result?->rank;

            $classRank = null;
            $classTotal = null;
            if ($classroomId) {
                $classResults = OmrResult::where('exam_id', $examIds[0])
                    ->whereHas('student', fn($q) => $q->where('classroom_id', $classroomId))
                    ->orderByDesc('total_net')->get();
                $classTotal = $classResults->count();
                foreach ($classResults as $i => $cr) {
                    if ($cr->student_id === $studentId) { $classRank = $i + 1; break; }
                }
            }
            return [$schoolRank, $schoolTotal, $classRank, $classTotal];
        }

        // Multi-exam: sum total_net per student across all exams
        $allStudentSums = DB::table('omr_results')
            ->whereIn('exam_id', $examIds)
            ->selectRaw('student_id, SUM(total_net) as sum_net')
            ->groupBy('student_id')
            ->orderByDesc('sum_net')
            ->get();

        $schoolTotal = $allStudentSums->count();
        $schoolRank  = null;
        foreach ($allStudentSums as $i => $row) {
            if ((int) $row->student_id === $studentId) { $schoolRank = $i + 1; break; }
        }

        $classRank = null;
        $classTotal = null;
        if ($classroomId) {
            $classStudentIds = Student::where('classroom_id', $classroomId)->pluck('id')->toArray();
            $classSums = $allStudentSums->filter(fn($r) => in_array((int)$r->student_id, $classStudentIds))->values();
            $classTotal = $classSums->count();
            foreach ($classSums as $i => $row) {
                if ((int) $row->student_id === $studentId) { $classRank = $i + 1; break; }
            }
        }
        return [$schoolRank, $schoolTotal, $classRank, $classTotal];
    }

    /** GET /omr/exams/{examId}/report-card?student_id=X  — single student, single exam */
    public function reportCardExam(Request $request, int $examId): \Illuminate\Http\Response
    {
        if ($e = $this->ensureAccess()) return $e;
        $tenantId = $this->tenantId();
        $exam     = OmrExam::where('tenant_id', $tenantId)->findOrFail($examId);

        $studentId = (int) $request->input('student_id');
        $student   = Student::where('tenant_id', $tenantId)->with('classroom:id,name')->findOrFail($studentId);
        $result    = OmrResult::where('exam_id', $examId)->where('student_id', $studentId)->firstOrFail();

        $exams = $this->loadExamsForCard([$examId]);
        [$schoolRank, $schoolTotal, $classRank, $classTotal] = $this->computeStudentRanks(
            $studentId, [$examId], $student->classroom_id
        );

        $tenantName = \App\Models\Tenant::find($tenantId)?->name ?? 'Okul';
        $card = $this->buildCardData(
            $exams, [$examId => $result], $student,
            $schoolRank, $schoolTotal, $classRank, $classTotal,
            $exam->name, (string) ($exam->season ?? '')
        );

        $pdf = Pdf::loadView('omr.report_card', ['cards' => [$card], 'tenantName' => $tenantName])
            ->setPaper('a4', 'portrait');

        $filename = 'karne_' . preg_replace('/[^a-zA-Z0-9_-]/', '_', $student->name) . '.pdf';
        return $pdf->download($filename);
    }

    /** GET /omr/sessions/{id}/report-card?student_id=X  — single student, session */
    public function reportCardSession(Request $request, int $sessionId): \Illuminate\Http\Response
    {
        if ($e = $this->ensureAccess()) return $e;
        $tenantId = $this->tenantId();
        $session  = OmrSession::where('tenant_id', $tenantId)->findOrFail($sessionId);
        $examIds  = $session->exam_ids ?? [];

        $studentId = (int) $request->input('student_id');
        $student   = Student::where('tenant_id', $tenantId)->with('classroom:id,name')->findOrFail($studentId);

        $exams   = $this->loadExamsForCard($examIds);
        $results = OmrResult::whereIn('exam_id', $examIds)->where('student_id', $studentId)->get()->keyBy('exam_id');

        [$schoolRank, $schoolTotal, $classRank, $classTotal] = $this->computeStudentRanks(
            $studentId, $examIds, $student->classroom_id
        );

        $tenantName = \App\Models\Tenant::find($tenantId)?->name ?? 'Okul';
        $card = $this->buildCardData(
            $exams, $results->toArray(), $student,
            $schoolRank, $schoolTotal, $classRank, $classTotal,
            $session->name, (string) ($session->exam_type ?? '')
        );

        $pdf = Pdf::loadView('omr.report_card', ['cards' => [$card], 'tenantName' => $tenantName])
            ->setPaper('a4', 'portrait');

        $filename = 'karne_' . preg_replace('/[^a-zA-Z0-9_-]/', '_', $student->name) . '.pdf';
        return $pdf->download($filename);
    }

    /** GET /omr/exams/{examId}/report-card/bulk?classroom_id=X  — all students (optionally filtered by class) */
    public function reportCardBulkExam(Request $request, int $examId): \Illuminate\Http\Response
    {
        if ($e = $this->ensureAccess()) return $e;
        $tenantId = $this->tenantId();
        $exam     = OmrExam::where('tenant_id', $tenantId)->findOrFail($examId);

        $query = OmrResult::where('exam_id', $examId)->with(['student' => fn($q) => $q->with('classroom:id,name')]);
        if ($request->filled('classroom_id'))
            $query->whereHas('student', fn($q) => $q->where('classroom_id', (int) $request->input('classroom_id')));

        $results = $query->orderBy('rank')->get();
        if ($results->isEmpty()) abort(404, 'Bu sınav için sonuç bulunamadı.');

        $exams      = $this->loadExamsForCard([$examId]);
        $tenantName = \App\Models\Tenant::find($tenantId)?->name ?? 'Okul';
        $schoolTotal = OmrResult::where('exam_id', $examId)->count();

        $cards = [];
        foreach ($results as $result) {
            $student = $result->student;
            if (!$student) continue;

            $classRank = null; $classTotal = null;
            if ($student->classroom_id) {
                $classResults = OmrResult::where('exam_id', $examId)
                    ->whereHas('student', fn($q) => $q->where('classroom_id', $student->classroom_id))
                    ->orderByDesc('total_net')->get();
                $classTotal = $classResults->count();
                foreach ($classResults as $i => $cr) {
                    if ($cr->student_id === $student->id) { $classRank = $i + 1; break; }
                }
            }

            $cards[] = $this->buildCardData(
                $exams, [$examId => $result], $student,
                $result->rank, $schoolTotal, $classRank, $classTotal,
                $exam->name, (string) ($exam->season ?? '')
            );
        }

        $pdf = Pdf::loadView('omr.report_card', ['cards' => $cards, 'tenantName' => $tenantName])
            ->setPaper('a4', 'portrait');

        $filename = 'karne_toplu_' . preg_replace('/[^a-zA-Z0-9_-]/', '_', $exam->name) . '.pdf';
        return $pdf->download($filename);
    }

    /** GET /omr/sessions/{id}/report-card/bulk?classroom_id=X */
    public function reportCardBulkSession(Request $request, int $sessionId): \Illuminate\Http\Response
    {
        if ($e = $this->ensureAccess()) return $e;
        $tenantId = $this->tenantId();
        $session  = OmrSession::where('tenant_id', $tenantId)->findOrFail($sessionId);
        $examIds  = $session->exam_ids ?? [];
        if (empty($examIds)) abort(404, 'Oturumda sınav yok.');

        // All student IDs that participated in any exam in this session
        $studentIdQuery = OmrResult::whereIn('exam_id', $examIds)->distinct()->pluck('student_id');

        $studentsQuery = Student::where('tenant_id', $tenantId)
            ->whereIn('id', $studentIdQuery)
            ->with('classroom:id,name');
        if ($request->filled('classroom_id'))
            $studentsQuery->where('classroom_id', (int) $request->input('classroom_id'));

        $students = $studentsQuery->get();
        if ($students->isEmpty()) abort(404, 'Öğrenci bulunamadı.');

        $exams      = $this->loadExamsForCard($examIds);
        $tenantName = \App\Models\Tenant::find($tenantId)?->name ?? 'Okul';

        // Pre-compute all results keyed by [student_id][exam_id]
        $allResults = OmrResult::whereIn('exam_id', $examIds)
            ->whereIn('student_id', $students->pluck('id'))
            ->get();
        $resultMap = [];
        foreach ($allResults as $r) {
            $resultMap[$r->student_id][$r->exam_id] = $r;
        }

        // Pre-compute combined school ranks
        $allStudentSums = DB::table('omr_results')
            ->whereIn('exam_id', $examIds)
            ->selectRaw('student_id, SUM(total_net) as sum_net')
            ->groupBy('student_id')
            ->orderByDesc('sum_net')
            ->get();
        $schoolTotal = $allStudentSums->count();
        $schoolRankMap = [];
        foreach ($allStudentSums as $i => $row) {
            $schoolRankMap[(int) $row->student_id] = $i + 1;
        }

        $cards = [];
        foreach ($students as $student) {
            $studentResults = $resultMap[$student->id] ?? [];
            $schoolRank = $schoolRankMap[$student->id] ?? null;

            // Class rank among session participants
            $classRank = null; $classTotal = null;
            if ($student->classroom_id) {
                $classStudentIds = Student::where('classroom_id', $student->classroom_id)->pluck('id')->toArray();
                $classSums = $allStudentSums->filter(fn($r) => in_array((int) $r->student_id, $classStudentIds))->values();
                $classTotal = $classSums->count();
                foreach ($classSums as $i => $row) {
                    if ((int) $row->student_id === $student->id) { $classRank = $i + 1; break; }
                }
            }

            $cards[] = $this->buildCardData(
                $exams, $studentResults, $student,
                $schoolRank, $schoolTotal, $classRank, $classTotal,
                $session->name, (string) ($session->exam_type ?? '')
            );
        }

        // Sort cards by school rank
        usort($cards, fn($a, $b) => ($a['school_rank'] ?? 9999) <=> ($b['school_rank'] ?? 9999));

        $pdf = Pdf::loadView('omr.report_card', ['cards' => $cards, 'tenantName' => $tenantName])
            ->setPaper('a4', 'portrait');

        $filename = 'karne_toplu_' . preg_replace('/[^a-zA-Z0-9_-]/', '_', $session->name) . '.pdf';
        return $pdf->download($filename);
    }

    private function calculateSession(OmrSession $session): void
    {
        $examIds = $session->exam_ids ?? [];
        if (empty($examIds)) return;

        // Her sınavdaki sonuçları öğrenci bazında topla
        $studentTotals = [];
        foreach ($examIds as $examId) {
            $results = OmrResult::where('exam_id', $examId)
                ->select(['student_id', 'total_net', 'total_point', 'rank'])->get();
            foreach ($results as $r) {
                $sid = $r->student_id;
                if (!isset($studentTotals[$sid])) $studentTotals[$sid] = ['student_id' => $sid, 'total_net' => 0.0, 'total_point' => 0.0, 'exam_count' => 0];
                $studentTotals[$sid]['total_net'] += $r->total_net;
                $studentTotals[$sid]['total_point'] += $r->total_point;
                $studentTotals[$sid]['exam_count']++;
            }
        }

        // Sırala
        usort($studentTotals, fn($a, $b) => $b['total_net'] <=> $a['total_net']);
        foreach ($studentTotals as $rank => &$row) $row['rank'] = $rank + 1;

        $studentInfoMap = Student::where('tenant_id', $this->tenantId())
            ->whereIn('id', array_column($studentTotals, 'student_id'))
            ->select(['id', 'name', 'school_no', 'classroom_id'])
            ->with('classroom:id,name')
            ->get()
            ->keyBy('id');

        foreach ($studentTotals as &$row) {
            $student = $studentInfoMap[$row['student_id']] ?? null;
            $row['student_name'] = $student?->name;
            $row['student_no'] = $student?->school_no;
            $row['classroom_name'] = $student?->classroom?->name;
        }

        $session->update(['combined_results' => array_values($studentTotals), 'calculated_at' => now()]);
    }
}
