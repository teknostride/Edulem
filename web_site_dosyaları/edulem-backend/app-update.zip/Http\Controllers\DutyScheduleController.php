<?php

namespace App\Http\Controllers;

use App\Actions\CreateDutyScheduleAction;
use App\Actions\UpdateDutyScheduleAction;
use App\Http\Requests\StoreDutyScheduleRequest;
use App\Http\Requests\UpdateDutyScheduleRequest;
use App\Http\Resources\DutyScheduleResource;
use App\Models\DutySchedule;
use App\Services\ActivityLogService;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Gate;

class DutyScheduleController extends ApiController
{
    protected ActivityLogService $activityLogService;

    public function __construct(ActivityLogService $activityLogService)
    {
        $this->activityLogService = $activityLogService;
    }

    /**
     * Display a listing of duty schedules.
     */
    public function index(): JsonResponse
    {
        Gate::authorize('viewAny', DutySchedule::class);

        $query = DutySchedule::with(['user']);

        // Filtreleme
        if (request()->has('user_id')) {
            $query->where('user_id', request('user_id'));
        }

        if (request()->has('day_of_week')) {
            $query->where('day_of_week', request('day_of_week'));
        }

        if (request()->has('is_active')) {
            $query->where('is_active', request('is_active'));
        }

        if (request('active_only')) {
            $query->active();
        }

        // Sıralama
        $sortBy = request('sort_by', 'day_of_week');
        $sortOrder = request('sort_order', 'asc');
        $query->orderBy($sortBy, $sortOrder)
              ->orderBy('start_time', 'asc');

        $dutySchedules = $query->paginate(request('per_page', 50));

        $activeCount = DutySchedule::where('is_active', true)->count();
        $totalCount = DutySchedule::count();

        return $this->success([
            'items' => DutyScheduleResource::collection($dutySchedules->items()),
            'pagination' => [
                'current_page' => $dutySchedules->currentPage(),
                'last_page' => $dutySchedules->lastPage(),
                'per_page' => $dutySchedules->perPage(),
                'total' => $dutySchedules->total(),
            ],
            'active_count' => $activeCount,
            'total_count' => $totalCount,
        ], 'Nöbet çizelgesi listelendi.');
    }

    /**
     * Store a newly created duty schedule in storage.
     */
    public function store(StoreDutyScheduleRequest $request, CreateDutyScheduleAction $createDutyScheduleAction): JsonResponse
    {
        Gate::authorize('create', DutySchedule::class);

        try {
            $dutySchedule = $createDutyScheduleAction->execute($request->validated());

            return $this->success(
                new DutyScheduleResource($dutySchedule),
                'Nöbet programı başarıyla oluşturuldu.',
                201
            );
        } catch (\Exception $e) {
            return $this->error('Nöbet programı oluşturulurken bir hata oluştu: ' . $e->getMessage(), [], 422);
        }
    }

    /**
     * Display the specified duty schedule.
     */
    public function show(DutySchedule $dutySchedule): JsonResponse
    {
        Gate::authorize('view', $dutySchedule);

        return $this->success(new DutyScheduleResource($dutySchedule->load('user')));
    }

    /**
     * Update the specified duty schedule in storage.
     */
    public function update(UpdateDutyScheduleRequest $request, DutySchedule $dutySchedule, UpdateDutyScheduleAction $updateDutyScheduleAction): JsonResponse
    {
        Gate::authorize('update', $dutySchedule);

        try {
            $updatedDutySchedule = $updateDutyScheduleAction->execute($dutySchedule, $request->validated());

            return $this->success(
                new DutyScheduleResource($updatedDutySchedule),
                'Nöbet programı başarıyla güncellendi.'
            );
        } catch (\Exception $e) {
            return $this->error('Nöbet programı güncellenirken bir hata oluştu: ' . $e->getMessage(), [], 422);
        }
    }

    /**
     * Remove the specified duty schedule from storage.
     */
    public function destroy(DutySchedule $dutySchedule): JsonResponse
    {
        Gate::authorize('delete', $dutySchedule);

        $this->activityLogService->logDelete($dutySchedule);
        $dutySchedule->delete();

        return $this->success(null, 'Nöbet programı başarıyla silindi.');
    }

    /**
     * Check for conflicts with other duty schedules.
     */
    public function checkConflict(StoreDutyScheduleRequest $request): JsonResponse
    {
        Gate::authorize('create', DutySchedule::class);

        try {
            $data = $request->validated();
            
            $conflicts = DutySchedule::where('tenant_id', auth()->user()->tenant_id)
                ->where('user_id', $data['user_id'])
                ->where('day_of_week', $data['day_of_week'])
                ->where('is_active', true)
                ->get()
                ->filter(function ($existing) use ($data) {
                    $newStart = strtotime($data['start_time']);
                    $newEnd = strtotime($data['end_time']);
                    $existingStart = strtotime($existing->start_time);
                    $existingEnd = strtotime($existing->end_time);
                    
                    return !($newEnd <= $existingStart || $newStart >= $existingEnd);
                });

            if ($conflicts->isNotEmpty()) {
                return $this->success([
                    'has_conflict' => true,
                    'conflicts' => DutyScheduleResource::collection($conflicts),
                ], 'Nöbet programı çakışması tespit edildi.');
            }

            return $this->success([
                'has_conflict' => false,
                'conflicts' => [],
            ], 'Nöbet programı çakışması yok.');
        } catch (\Exception $e) {
            return $this->error('Çakışma kontrolü yapılırken bir hata oluştu: ' . $e->getMessage(), [], 500);
        }
    }
}
