<?php

namespace App\Http\Controllers;

use App\Models\Announcement;
use App\Models\AnnouncementRead;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AnnouncementController extends ApiController
{
    /**
     * Kullanıcı görünen adı: name veya email
     */
    private function userDisplayName($user): string
    {
        if (!$user) {
            return 'Sistem';
        }
        return $user->name ?? $user->email ?? 'Sistem';
    }

    /**
     * Zamanı gelen planlanmış duyuruları (scheduled_at <= now) yayınla.
     * Cron/scheduler yoksa bile; index veya unread-count çağrıldığında çalışır.
     */
    private function publishDueScheduledAnnouncements(?int $tenantId = null): void
    {
        $q = Announcement::where('status', 'scheduled')
            ->whereNotNull('scheduled_at')
            ->where('scheduled_at', '<=', now());

        if ($tenantId) {
            $q->where('tenant_id', $tenantId);
        }

        $q->update(['status' => 'published']);
    }

    /**
     * Sayfalı duyuru listesi (veritabanı)
     * mailbox: inbox, sent, starred, scheduled, drafts, important, trash
     */
    public function index(Request $request): JsonResponse
    {
        try {
            $user = $request->user() ?? (object) ['id' => 1, 'tenant_id' => 1];
            $userId = $user->id;
            $tenantId = $user->tenant_id ?? null;
            if (!$tenantId) {
                return response()->json(['status' => true, 'data' => [], 'message' => 'Duyurular başarıyla getirildi.', 'meta' => ['current_page' => 1, 'last_page' => 1, 'per_page' => 15, 'total' => 0]], 200);
            }

            $this->publishDueScheduledAnnouncements((int) $tenantId);

            $mailbox = $request->get('mailbox', 'inbox');
            $q = Announcement::query()
                ->with('creator')
                ->where('tenant_id', $tenantId)
                ->leftJoin('announcement_reads as ar_u', function ($j) use ($userId) {
                    $j->on('announcements.id', '=', 'ar_u.announcement_id')->where('ar_u.user_id', '=', $userId);
                })
                ->select('announcements.*', 'ar_u.read_at as user_read_at', 'ar_u.is_starred as is_starred', 'ar_u.is_important as is_important');

            switch ($mailbox) {
                case 'sent':
                    $q->where('announcements.status', 'published')->where('announcements.created_by', $userId);
                    break;
                case 'starred':
                    $q->where('announcements.status', 'published')->where('ar_u.is_starred', 1);
                    break;
                case 'scheduled':
                    $q->where('announcements.status', 'scheduled')->where('announcements.created_by', $userId);
                    break;
                case 'drafts':
                    $q->where('announcements.status', 'draft')->where('announcements.created_by', $userId);
                    break;
                case 'important':
                    $q->where('announcements.status', 'published')->where('ar_u.is_important', 1);
                    break;
                case 'trash':
                    $q->where('announcements.status', 'trashed')->where('announcements.created_by', $userId);
                    break;
                default: // inbox
                    $q->where('announcements.status', 'published');
                    break;
            }

            if ($request->filled('type') && $request->get('type') !== 'all') {
                $q->where('announcements.type', $request->get('type'));
            }
            if ($request->filled('search')) {
                $s = '%' . $request->get('search') . '%';
                $q->where(function ($q2) use ($s) {
                    $q2->where('announcements.title', 'like', $s)
                        ->orWhere('announcements.message', 'like', $s)
                        ->orWhereHas('creator', fn ($c) => $c->where('first_name', 'like', $s)->orWhere('last_name', 'like', $s)->orWhere('email', 'like', $s));
                });
            }

            $paginator = $q->orderBy('announcements.created_at', 'desc')->paginate((int) $request->get('per_page', 15));

            $data = collect($paginator->items())->map(function ($a) {
                return [
                    'id' => $a->id,
                    'title' => $a->title,
                    'message' => $a->message,
                    'type' => $a->type,
                    'user_name' => $this->userDisplayName($a->creator),
                    'created_at' => $a->created_at?->toISOString(),
                    'scheduled_at' => $a->scheduled_at?->toISOString(),
                    'read' => ! empty($a->user_read_at),
                    'is_starred' => (bool) ($a->is_starred ?? false),
                    'is_important' => (bool) ($a->is_important ?? false),
                ];
            })->all();

            return response()->json([
                'status' => true,
                'data' => $data,
                'message' => 'Duyurular başarıyla getirildi.',
                'meta' => [
                    'current_page' => $paginator->currentPage(),
                    'last_page' => $paginator->lastPage(),
                    'per_page' => $paginator->perPage(),
                    'total' => $paginator->total(),
                ],
            ], 200);
        } catch (\Exception $e) {
            return $this->error('Duyurular getirilirken bir hata oluştu: ' . $e->getMessage(), [], 500);
        }
    }

    /**
     * Mailbox sayıları: unread, starred, sent, scheduled, drafts, important, trash
     */
    public function unreadCount(Request $request): JsonResponse
    {
        try {
            $user = $request->user() ?? (object) ['id' => 1, 'tenant_id' => 1];
            $tenantId = $user->tenant_id ?? null;
            $userId = $user->id;
            if (!$tenantId) {
                return response()->json([
                    'status' => true,
                    'data' => [
                        'unread_count' => 0,
                        'starred_count' => 0,
                        'sent_count' => 0,
                        'scheduled_count' => 0,
                        'drafts_count' => 0,
                        'important_count' => 0,
                        'trash_count' => 0,
                    ],
                    'message' => 'Mailbox sayıları getirildi.',
                ], 200);
            }

            $tenantId = (int) $tenantId;
            $this->publishDueScheduledAnnouncements($tenantId);

            $row = DB::table('announcements as a')
                ->leftJoin('announcement_reads as ar', function ($j) use ($userId) {
                    $j->on('a.id', '=', 'ar.announcement_id')
                        ->where('ar.user_id', '=', $userId);
                })
                ->where('a.tenant_id', $tenantId)
                ->selectRaw("SUM(CASE WHEN a.status = 'published' AND (ar.read_at IS NULL) THEN 1 ELSE 0 END) as unread_count")
                ->selectRaw("SUM(CASE WHEN a.status = 'published' AND ar.is_starred = 1 THEN 1 ELSE 0 END) as starred_count")
                ->selectRaw("SUM(CASE WHEN a.status = 'published' AND a.created_by = ? THEN 1 ELSE 0 END) as sent_count", [$userId])
                ->selectRaw("SUM(CASE WHEN a.status = 'scheduled' AND a.created_by = ? THEN 1 ELSE 0 END) as scheduled_count", [$userId])
                ->selectRaw("SUM(CASE WHEN a.status = 'draft' AND a.created_by = ? THEN 1 ELSE 0 END) as drafts_count", [$userId])
                ->selectRaw("SUM(CASE WHEN a.status = 'published' AND ar.is_important = 1 THEN 1 ELSE 0 END) as important_count")
                ->selectRaw("SUM(CASE WHEN a.status = 'trashed' AND a.created_by = ? THEN 1 ELSE 0 END) as trash_count", [$userId])
                ->first();

            $data = [
                'unread_count' => (int) ($row->unread_count ?? 0),
                'starred_count' => (int) ($row->starred_count ?? 0),
                'sent_count' => (int) ($row->sent_count ?? 0),
                'scheduled_count' => (int) ($row->scheduled_count ?? 0),
                'drafts_count' => (int) ($row->drafts_count ?? 0),
                'important_count' => (int) ($row->important_count ?? 0),
                'trash_count' => (int) ($row->trash_count ?? 0),
            ];
            return response()->json(['status' => true, 'data' => $data, ...$data, 'message' => 'Mailbox sayıları getirildi.'], 200);
        } catch (\Exception $e) {
            return $this->error('Mailbox sayıları getirilirken bir hata oluştu: ' . $e->getMessage(), [], 500);
        }
    }

    public function store(Request $request): JsonResponse
    {
        try {
            $request->validate([
                'title' => 'required|string|max:255',
                'message' => 'required|string',
                'type' => 'nullable|string|in:info,success,warning,error',
                'roles' => 'nullable|array',
                'roles.*' => 'integer',
                'status' => 'nullable|string|in:draft,published,scheduled',
                'scheduled_at' => 'required_if:status,scheduled|nullable|date|after:now',
            ]);

            $user = $request->user();
            if (!$user->tenant_id) {
                return $this->error('Duyuru oluşturmak için kurum bilgisi gerekli.', [], 400);
            }

            $a = Announcement::create([
                'tenant_id' => $user->tenant_id,
                'title' => $request->title,
                'message' => $request->message,
                'type' => $request->get('type', 'info'),
                'created_by' => $user->id,
                'target_roles' => $request->get('roles'),
                'status' => $request->get('status', 'published'),
                'scheduled_at' => $request->get('scheduled_at'),
            ]);

            return $this->success([
                'id' => $a->id,
                'title' => $a->title,
                'message' => $a->message,
                'type' => $a->type,
                'user_name' => $this->userDisplayName($user),
                'created_at' => $a->created_at?->toISOString(),
                'read' => false,
            ], 'Duyuru başarıyla gönderildi.', 201);
        } catch (\Illuminate\Validation\ValidationException $e) {
            return $this->error('Geçersiz veri.', $e->errors(), 422);
        } catch (\Exception $e) {
            return $this->error('Duyuru gönderilirken bir hata oluştu: ' . $e->getMessage(), [], 500);
        }
    }

    public function show(Request $request, $id): JsonResponse
    {
        try {
            $user = $request->user();
            $a = Announcement::with('creator')->where('tenant_id', $user->tenant_id)->findOrFail($id);
            $read = (bool) $a->reads()->where('user_id', $user->id)->whereNotNull('read_at')->exists();

            return $this->success([
                'id' => $a->id,
                'title' => $a->title,
                'message' => $a->message,
                'type' => $a->type,
                'user_name' => $this->userDisplayName($a->creator),
                'created_at' => $a->created_at?->toISOString(),
                'read' => $read,
            ], 'Duyuru getirildi.');
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return $this->error('Duyuru bulunamadı.', [], 404);
        } catch (\Exception $e) {
            return $this->error('Duyuru getirilirken bir hata oluştu: ' . $e->getMessage(), [], 500);
        }
    }

    public function update(Request $request, $id): JsonResponse
    {
        try {
            $user = $request->user();
            $a = Announcement::where('tenant_id', $user->tenant_id)->findOrFail($id);
            $a->update($request->only(['title', 'message', 'type', 'target_roles']));
            return $this->success(['id' => $a->id], 'Duyuru güncellendi.');
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return $this->error('Duyuru bulunamadı.', [], 404);
        } catch (\Exception $e) {
            return $this->error('Duyuru güncellenirken bir hata oluştu: ' . $e->getMessage(), [], 500);
        }
    }

    public function destroy(Request $request, $id): JsonResponse
    {
        try {
            $user = $request->user();
            $a = Announcement::where('tenant_id', $user->tenant_id)->findOrFail($id);
            $a->delete();
            return $this->success(null, 'Duyuru silindi.');
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return $this->error('Duyuru bulunamadı.', [], 404);
        } catch (\Exception $e) {
            return $this->error('Duyuru silinirken bir hata oluştu: ' . $e->getMessage(), [], 500);
        }
    }

    public function markAsRead(Request $request, $id): JsonResponse
    {
        try {
            $user = $request->user();
            $a = Announcement::where('tenant_id', $user->tenant_id)->findOrFail($id);
            AnnouncementRead::updateOrCreate(
                ['announcement_id' => $a->id, 'user_id' => $user->id],
                ['read_at' => now()]
            );
            return $this->success([], 'Duyuru okundu olarak işaretlendi.');
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return $this->error('Duyuru bulunamadı.', [], 404);
        } catch (\Exception $e) {
            return $this->error('Duyuru işaretlenirken bir hata oluştu: ' . $e->getMessage(), [], 500);
        }
    }

    public function markAllAsRead(Request $request): JsonResponse
    {
        try {
            $user = $request->user();
            $tenantId = $user->tenant_id;
            if (!$tenantId) {
                return $this->success([], 'Tüm duyurular okundu olarak işaretlendi.');
            }
            $ids = Announcement::where('tenant_id', $tenantId)->pluck('id');
            foreach ($ids as $aid) {
                AnnouncementRead::updateOrCreate(
                    ['announcement_id' => $aid, 'user_id' => $user->id],
                    ['read_at' => now()]
                );
            }
            return $this->success([], 'Tüm duyurular okundu olarak işaretlendi.');
        } catch (\Exception $e) {
            return $this->error('Duyurular işaretlenirken bir hata oluştu: ' . $e->getMessage(), [], 500);
        }
    }

    public function statistics(Request $request): JsonResponse
    {
        try {
            $user = $request->user();
            $tenantId = $user->tenant_id;
            if (!$tenantId) {
                return $this->success(['total' => 0, 'unread' => 0, 'by_type' => []], 'İstatistikler getirildi.');
            }

            $total = Announcement::where('tenant_id', $tenantId)->count();
            $unread = Announcement::where('tenant_id', $tenantId)
                ->whereDoesntHave('reads', fn ($qr) => $qr->where('user_id', $user->id)->whereNotNull('read_at'))
                ->count();
            $byType = Announcement::where('tenant_id', $tenantId)->selectRaw('type, count(*) as c')->groupBy('type')->pluck('c', 'type')->toArray();

            return $this->success(['total' => $total, 'unread' => $unread, 'by_type' => $byType], 'İstatistikler getirildi.');
        } catch (\Exception $e) {
            return $this->error('İstatistikler getirilirken bir hata oluştu: ' . $e->getMessage(), [], 500);
        }
    }

    /**
     * Yıldız işareti aç/kapat
     */
    public function star(Request $request, $id): JsonResponse
    {
        try {
            $user = $request->user() ?? (object) ['id' => 1, 'tenant_id' => 1];
            $a = Announcement::where('tenant_id', $user->tenant_id ?? 1)->findOrFail($id);
            $value = (bool) $request->input('value', true);
            AnnouncementRead::updateOrCreate(
                ['announcement_id' => $a->id, 'user_id' => $user->id],
                ['is_starred' => $value]
            );
            return $this->success(['is_starred' => $value], 'Güncellendi.');
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return $this->error('Duyuru bulunamadı.', [], 404);
        } catch (\Exception $e) {
            return $this->error('Güncellenirken hata: ' . $e->getMessage(), [], 500);
        }
    }

    /**
     * Önemli işareti aç/kapat
     */
    public function important(Request $request, $id): JsonResponse
    {
        try {
            $user = $request->user() ?? (object) ['id' => 1, 'tenant_id' => 1];
            $a = Announcement::where('tenant_id', $user->tenant_id ?? 1)->findOrFail($id);
            $value = (bool) $request->input('value', true);
            AnnouncementRead::updateOrCreate(
                ['announcement_id' => $a->id, 'user_id' => $user->id],
                ['is_important' => $value]
            );
            return $this->success(['is_important' => $value], 'Güncellendi.');
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return $this->error('Duyuru bulunamadı.', [], 404);
        } catch (\Exception $e) {
            return $this->error('Güncellenirken hata: ' . $e->getMessage(), [], 500);
        }
    }

    /**
     * Seçili duyuruları çöpe taşı (status=trashed)
     */
    public function bulkTrash(Request $request): JsonResponse
    {
        try {
            $user = $request->user() ?? (object) ['id' => 1, 'tenant_id' => 1];
            $ids = $request->input('ids', []);
            if (! is_array($ids) || empty($ids)) {
                return $this->error('Lütfen silinecek duyuruları seçin.', [], 422);
            }
            $n = Announcement::where('tenant_id', $user->tenant_id ?? 1)
                ->whereIn('id', $ids)
                ->update(['status' => 'trashed']);
            return $this->success(['count' => $n], $n . ' duyuru çöpe taşındı.');
        } catch (\Exception $e) {
            return $this->error('İşlem sırasında hata: ' . $e->getMessage(), [], 500);
        }
    }
}
