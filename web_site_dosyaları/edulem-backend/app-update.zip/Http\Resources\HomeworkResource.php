<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;

class HomeworkResource extends ApiResource
{
    /**
     * Kurucu, Müdür, Müdür Yardımcısı tam alanları görsün (takip modu).
     */
    public function toArray($request): array
    {
        $user = $request->user();
        $roleName = $user && $user->role ? $user->role->name : null;

        if ($user && in_array($roleName, ['Öğretmen', 'Sınıf Öğretmeni', 'Rehberlik'], true)) {
            return $this->getTeacherFields();
        }

        if ($user && in_array($roleName, ['owner', 'Kurucu', 'Kurum Sahibi', 'institution_owner', 'Genel Müdür', 'Kampüs Müdürü', 'Müdür', 'Müdür Yardımcısı'], true)) {
            return $this->getAllFields();
        }
        return parent::toArray($request);
    }

    /**
     * Get public fields (visible to all authenticated users).
     *
     * @return array<string, mixed>
     */
    protected function getPublicFields(): array
    {
        $fields = [
            'id' => $this->id,
            'title' => $this->title,
            'assignment_mode' => $this->assignment_mode,
            'due_date' => $this->due_date->format('Y-m-d'),
            'is_active' => $this->is_active,
            'created_at' => $this->created_at->format('Y-m-d H:i:s'),
            'is_checked' => isset($this->checked_assignments_count) ? ((int) $this->checked_assignments_count > 0) : false,
        ];

        if ($this->relationLoaded('lesson') && $this->lesson) {
            $fields['lesson'] = [
                'id' => $this->lesson->id,
                'name' => $this->lesson->name,
                'code' => $this->lesson->code,
            ];
            $fields['lesson_id'] = $this->lesson->id;
        }

        if ($this->relationLoaded('classroom') && $this->classroom) {
            $fields['classroom'] = [
                'id' => $this->classroom->id,
                'name' => $this->classroom->name,
                'code' => $this->classroom->code,
            ];
            $fields['classroom_id'] = $this->classroom->id;
        }

        return $fields;
    }

    /**
     * Get teacher-specific fields.
     *
     * @return array<string, mixed>
     */
    protected function getTeacherFields(): array
    {
        $fields = $this->getPublicFields();
        
        if ($this->relationLoaded('lesson')) {
            $fields['lesson'] = [
                'id' => $this->lesson->id,
                'name' => $this->lesson->name,
                'code' => $this->lesson->code,
            ];
            $fields['lesson_id'] = $this->lesson->id;
        }
        
        if ($this->relationLoaded('classroom') && $this->classroom) {
            $fields['classroom'] = [
                'id' => $this->classroom->id,
                'name' => $this->classroom->name,
                'code' => $this->classroom->code,
            ];
            $fields['classroom_id'] = $this->classroom->id;
        }

        if ($this->relationLoaded('assignments')) {
            $fields['assigned_student_ids'] = $this->assignments->pluck('student_id')->map(fn ($id) => (int) $id)->values()->all();
        }
        
        $fields['description'] = $this->description;
        
        return $fields;
    }

    /**
     * Get accountant-specific fields.
     *
     * @return array<string, mixed>
     */
    protected function getAccountantFields(): array
    {
        return $this->getPublicFields();
    }

    /**
     * Get all fields (for admin).
     *
     * @return array<string, mixed>
     */
    protected function getAllFields(): array
    {
        $fields = $this->getPublicFields();
        
        if ($this->relationLoaded('lesson')) {
            $fields['lesson'] = [
                'id' => $this->lesson->id,
                'name' => $this->lesson->name,
                'code' => $this->lesson->code,
            ];
            $fields['lesson_id'] = $this->lesson->id;
        }
        
        if ($this->relationLoaded('classroom') && $this->classroom) {
            $fields['classroom'] = [
                'id' => $this->classroom->id,
                'name' => $this->classroom->name,
                'code' => $this->classroom->code,
            ];
            $fields['classroom_id'] = $this->classroom->id;
        }
        
        if ($this->relationLoaded('teacher')) {
            $fields['teacher'] = [
                'id' => $this->teacher->id,
                'name' => $this->teacher->name,
            ];
        }
        
        if ($this->relationLoaded('file') && $this->file) {
            $fields['file'] = [
                'id' => $this->file->id,
                'name' => $this->file->original_name,
                'path' => $this->file->path,
            ];
        }
        
        $fields['description'] = $this->description;
        $fields['is_online'] = $this->is_online;
        $fields['is_online_homework'] = $this->isOnline();
        if ($this->is_online) {
            $fields['question_ids'] = $this->question_ids;
        }
        $fields['is_project'] = $this->is_project;
        $fields['is_project_homework'] = $this->isProject();
        if ($this->is_project) {
            $fields['project_topics'] = $this->project_topics;
        }
        if ($this->relationLoaded('submissions')) {
            $fields['submissions_count'] = $this->submissions->count();
        }
        if (isset($this->submissions_count)) {
            $fields['submissions_count'] = $this->submissions_count;
        }
        if (isset($this->graded_count)) {
            $fields['graded_count'] = $this->graded_count;
        }
        if (isset($this->submissions_max_graded_at) && $this->submissions_max_graded_at) {
            $fields['last_graded_at'] = \Carbon\Carbon::parse($this->submissions_max_graded_at)->format('Y-m-d H:i:s');
        }
        if (isset($this->assignments_max_reviewed_at) && $this->assignments_max_reviewed_at) {
            $fields['last_graded_at'] = \Carbon\Carbon::parse($this->assignments_max_reviewed_at)->format('Y-m-d H:i:s');
        }
        if (isset($this->has_teacher_notes_count)) {
            $fields['has_teacher_notes'] = (int) $this->has_teacher_notes_count > 0;
        }
        if (isset($this->checked_assignments_count)) {
            $fields['is_checked'] = (int) $this->checked_assignments_count > 0;
        }
        if ($this->relationLoaded('assignments')) {
            $fields['assigned_student_ids'] = $this->assignments->pluck('student_id')->map(fn ($id) => (int) $id)->values()->all();
        }
        $fields['updated_at'] = $this->updated_at->format('Y-m-d H:i:s');

        return $fields;
    }
}
