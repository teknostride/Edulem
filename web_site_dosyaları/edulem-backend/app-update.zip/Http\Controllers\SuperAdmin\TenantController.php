<?php

namespace App\Http\Controllers\SuperAdmin;

use App\Http\Controllers\ApiController;
use App\Http\Requests\SuperAdmin\StoreTenantRequest;
use App\Http\Requests\SuperAdmin\UpdateTenantRequest;
use App\Http\Resources\TenantResource;
use App\Models\Tenant;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class TenantController extends ApiController
{
    /**
     * Display a listing of tenants.
     */
    public function index(): JsonResponse
    {
        try {
            $tenants = Tenant::with(['users', 'currentSubscription'])
                ->withCount(['users', 'students'])
                ->orderBy('created_at', 'desc')
                ->paginate(20);

            return $this->success([
                'tenants' => TenantResource::collection($tenants),
                'pagination' => [
                    'current_page' => $tenants->currentPage(),
                    'last_page' => $tenants->lastPage(),
                    'per_page' => $tenants->perPage(),
                    'total' => $tenants->total(),
                ],
            ], 'Kurumlar başarıyla listelendi.');

        } catch (\Exception $e) {
            return $this->error('Kurumlar listelenirken bir hata oluştu: ' . $e->getMessage(), [], 500);
        }
    }

    /**
     * Store a newly created tenant in storage.
     */
    public function store(StoreTenantRequest $request): JsonResponse
    {
        try {
            return DB::transaction(function () use ($request) {
                // Create tenant
                $tenant = Tenant::create([
                    'domain' => $request->domain,
                    'name' => $request->name,
                    'is_active' => $request->boolean('is_active', true),
                    'subscription_expires_at' => $request->subscription_expires_at,
                ]);

                // Create admin user for tenant
                $adminUser = User::create([
                    'name' => $request->admin_name,
                    'email' => $request->admin_email,
                    'password' => Hash::make($request->admin_password),
                    'tenant_id' => $tenant->id,
                    'is_active' => true,
                ]);

                // Assign owner role to admin user (if roles exist)
                if (class_exists('\Spatie\Permission\Models\Role')) {
                    $ownerRole = \Spatie\Permission\Models\Role::firstOrCreate(['name' => 'owner']);
                    $adminUser->assignRole($ownerRole);
                }

                return $this->success([
                    'tenant' => new TenantResource($tenant->load(['users', 'currentSubscription'])),
                    'admin_user' => [
                        'id' => $adminUser->id,
                        'name' => $adminUser->name,
                        'email' => $adminUser->email,
                    ]
                ], 'Kurum başarıyla oluşturuldu.');

            });
        } catch (\Exception $e) {
            return $this->error('Kurum oluşturulurken bir hata oluştu: ' . $e->getMessage(), [], 500);
        }
    }

    /**
     * Display the specified tenant.
     */
    public function show(int $id): JsonResponse
    {
        try {
            $tenant = Tenant::with(['users', 'students', 'currentSubscription', 'subscriptions'])
                ->withCount(['users', 'students'])
                ->find($id);

            if (!$tenant) {
                return $this->error('Kurum bulunamadı.', [], 404);
            }

            return $this->success([
                'tenant' => new TenantResource($tenant)
            ], 'Kurum bilgileri getirildi.');

        } catch (\Exception $e) {
            return $this->error('Kurum bilgileri alınırken bir hata oluştu: ' . $e->getMessage(), [], 500);
        }
    }

    /**
     * Update the specified tenant in storage.
     */
    public function update(UpdateTenantRequest $request, int $id): JsonResponse
    {
        try {
            $tenant = Tenant::find($id);

            if (!$tenant) {
                return $this->error('Kurum bulunamadı.', [], 404);
            }

            $tenant->update([
                'name' => $request->name ?? $tenant->name,
                'domain' => $request->domain ?? $tenant->domain,
                'is_active' => $request->boolean('is_active', $tenant->is_active),
                'subscription_expires_at' => $request->subscription_expires_at ?? $tenant->subscription_expires_at,
            ]);

            return $this->success([
                'tenant' => new TenantResource($tenant->load(['users', 'currentSubscription']))
            ], 'Kurum başarıyla güncellendi.');

        } catch (\Exception $e) {
            return $this->error('Kurum güncellenirken bir hata oluştu: ' . $e->getMessage(), [], 500);
        }
    }

    /**
     * Remove the specified tenant from storage.
     */
    public function destroy(int $id): JsonResponse
    {
        try {
            $tenant = Tenant::find($id);

            if (!$tenant) {
                return $this->error('Kurum bulunamadı.', [], 404);
            }

            return DB::transaction(function () use ($tenant) {
                // Delete all users associated with tenant
                $tenant->users()->delete();
                
                // Delete all students associated with tenant
                $tenant->students()->delete();

                // Delete tenant
                $tenant->delete();

                return $this->success([], 'Kurum ve ilişkili tüm veriler başarıyla silindi.');

            });
        } catch (\Exception $e) {
            return $this->error('Kurum silinirken bir hata oluştu: ' . $e->getMessage(), [], 500);
        }
    }

    /**
     * Toggle tenant status (activate/deactivate)
     */
    public function toggleStatus(int $id): JsonResponse
    {
        try {
            $tenant = Tenant::find($id);

            if (!$tenant) {
                return $this->error('Kurum bulunamadı.', [], 404);
            }

            $tenant->update(['is_active' => !$tenant->is_active]);

            $status = $tenant->is_active ? 'aktifleştirildi' : 'pasifleştirildi';

            return $this->success([
                'tenant' => new TenantResource($tenant)
            ], "Kurum başarıyla {$status}.");

        } catch (\Exception $e) {
            return $this->error('Kurum durumu değiştirilirken bir hata oluştu: ' . $e->getMessage(), [], 500);
        }
    }

    /**
     * Get tenant statistics
     */
    public function statistics(): JsonResponse
    {
        try {
            $stats = [
                'total_tenants' => Tenant::count(),
                'active_tenants' => Tenant::where('is_active', true)->count(),
                'inactive_tenants' => Tenant::where('is_active', false)->count(),
                'total_users' => User::count(),
                'total_students' => \App\Models\Student::count(),
                'recent_tenants' => Tenant::withCount(['users', 'students'])
                    ->orderBy('created_at', 'desc')
                    ->limit(5)
                    ->get(),
            ];

            return $this->success($stats, 'İstatistikler başarıyla getirildi.');

        } catch (\Exception $e) {
            return $this->error('İstatistikler alınırken bir hata oluştu: ' . $e->getMessage(), [], 500);
        }
    }
}
