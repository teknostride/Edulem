<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreMealMenuRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'menu_date' => ['required', 'date'],
            'meal_type' => ['required', 'in:breakfast,lunch,snack,dinner'],
            'meals' => ['required', 'array', 'min:1'],
            'meals.*.name' => ['required', 'string', 'max:255'],
            'meals.*.description' => ['nullable', 'string'],
            'target_student_ids' => ['nullable', 'array'],
            'target_student_ids.*' => ['exists:students,id'],
            'classroom_id' => ['nullable', 'exists:classrooms,id'],
            'notes' => ['nullable', 'string'],
            'is_published' => ['boolean'],
        ];
    }
}
