<?php

namespace App\Http\Controllers;

use App\Http\Resources\CityResource;
use App\Http\Resources\DistrictResource;
use App\Models\City;
use App\Models\District;
use App\Services\CacheService;
use Illuminate\Http\JsonResponse;

class LocationController extends ApiController
{
    /**
     * Get all cities (with cache).
     *
     * @param  \App\Services\CacheService  $cacheService
     * @return \Illuminate\Http\JsonResponse
     */
    public function cities(CacheService $cacheService): JsonResponse
    {
        try {
            // Cache'i atla, her zaman veritabanından al (güncel veriler için)
            $cities = City::orderBy('name')->get();

            $formatted = CityResource::collection($cities)->resolve();

            // Cache'i güncelle
            $cacheService->cacheCities($formatted);

            return $this->success(['cities' => $formatted], 'İller başarıyla getirildi.');
        } catch (\Exception $e) {
            return $this->error('İller getirilirken bir hata oluştu: ' . $e->getMessage(), [], 500);
        }
    }

    /**
     * Get districts by city ID (bağımlı seçim - with cache).
     *
     * @param  int  $cityId
     * @param  \App\Services\CacheService  $cacheService
     * @return \Illuminate\Http\JsonResponse
     */
    public function districts(int $cityId, CacheService $cacheService): JsonResponse
    {
        try {
            // Önce cache'den kontrol et
            $cached = $cacheService->getCachedDistricts($cityId);
            
            if ($cached !== null) {
                return $this->success(['districts' => $cached], 'İlçeler başarıyla getirildi (cache).');
            }

            // Cache'de yoksa veritabanından al ve cache'le
            $districts = District::where('city_id', $cityId)
                ->orderBy('name')
                ->get();

            $formatted = DistrictResource::collection($districts)->resolve();

            $cacheService->cacheDistricts($cityId, $formatted);

            return $this->success(['districts' => $formatted], 'İlçeler başarıyla getirildi.');
        } catch (\Exception $e) {
            return $this->error('İlçeler getirilirken bir hata oluştu: ' . $e->getMessage(), [], 500);
        }
    }
}
