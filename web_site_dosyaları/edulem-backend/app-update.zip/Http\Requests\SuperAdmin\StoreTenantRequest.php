<?php

namespace App\Http\Requests\SuperAdmin;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class StoreTenantRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            // Tenant fields
            'domain' => ['required', 'string', 'max:255', 'unique:tenants,domain', 'regex:/^[a-zA-Z0-9-]+$/'],
            'name' => ['required', 'string', 'max:255'],
            'is_active' => ['boolean'],
            'subscription_expires_at' => ['nullable', 'date', 'after:today'],

            // Admin user fields
            'admin_name' => ['required', 'string', 'max:255'],
            'admin_email' => ['required', 'email', 'max:255', 'unique:users,email'],
            'admin_password' => ['required', 'string', 'min:8', 'confirmed'],
        ];
    }

    /**
     * Get custom error messages for validation rules.
     *
     * @return array<string, string>
     */
    public function messages(): array
    {
        return [
            // Tenant messages
            'domain.required' => 'Domain alanı zorunludur.',
            'domain.unique' => 'Bu domain zaten kullanımda.',
            'domain.regex' => 'Domain sadece harf, rakam ve tire içerebilir.',
            'name.required' => 'Kurum adı zorunludur.',
            'subscription_expires_at.after' => 'Abonelik bitiş tarihi bugünden sonra olmalıdır.',

            // Admin user messages
            'admin_name.required' => 'Yönetici adı zorunludur.',
            'admin_email.required' => 'Yönetici emaili zorunludur.',
            'admin_email.email' => 'Geçerli bir email adresi giriniz.',
            'admin_email.unique' => 'Bu email adresi zaten kullanımda.',
            'admin_password.required' => 'Yönetici şifresi zorunludur.',
            'admin_password.min' => 'Şifre en az 8 karakter olmalıdır.',
            'admin_password.confirmed' => 'Şifre tekrarı eşleşmiyor.',
        ];
    }
}
