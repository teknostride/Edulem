<?php

namespace App\Http\Controllers\Portal;

use App\Http\Controllers\ApiController;
use App\Models\Guardian;
use App\Models\Student;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class StudentPortalController extends ApiController
{
    /**
     * Student portal login.
     */
    public function login(Request $request): JsonResponse
    {
        $request->validate([
            'email' => 'required|email',
            'password' => 'required|string',
            'device_name' => 'sometimes|string|max:255',
        ]);

        $normalizedEmail = mb_strtolower(trim((string) $request->email));

        $guardian = Guardian::query()
            ->whereRaw('LOWER(email) = ?', [$normalizedEmail])
            ->with(['students' => function ($q) {
                $q->orderBy('guardian_student.created_at')->orderBy('students.id');
            }])
            ->first();

        if (!$guardian || !Hash::check($request->password, $guardian->password)) {
            return $this->error('Giriş bilgileri hatalı.', [], 401);
        }

        if (!$guardian->is_portal_active) {
            return $this->error('Portal erişimi aktif değil.', [], 403);
        }

        $student = $guardian->students->first();
        if (!$student) {
            return $this->error('Bu veliye bağlı öğrenci bulunamadı.', [], 404);
        }

        if (isset($student->is_portal_active) && !$student->is_portal_active) {
            return $this->error('Öğrenci portal erişimi aktif değil.', [], 403);
        }

        // personal_access_tokens.tokenable_id integer olduğu için
        // guardian(uuid) yerine öğrenci üzerinden token üret.
        $token = $student->createToken($request->device_name ?? 'portal-token')->plainTextToken;

        // Son giriş tarihini güncelle
        $guardian->update(['last_login_at' => now()]);

        return $this->success([
            'student' => [
                'id' => $student->id,
                'name' => $student->name,
                'school_no' => $student->school_no,
                'email' => $guardian->email,
                'guardian_name' => $guardian->name,
            ],
            'token' => $token,
        ], 'Giriş başarılı.');
    }

    private function resolvePortalStudent(Request $request): ?Student
    {
        $actor = $request->user();

        if ($actor instanceof Student) {
            return $actor;
        }

        if ($actor instanceof Guardian) {
            return $actor->students()
                ->orderBy('guardian_student.created_at')
                ->orderBy('students.id')
                ->first();
        }

        return null;
    }

    private function resolvePortalGuardian(Request $request): ?Guardian
    {
        $actor = $request->user();

        if ($actor instanceof Guardian) {
            return $actor;
        }

        if ($actor instanceof Student) {
            return $actor->guardians()
                ->orderBy('guardian_student.created_at')
                ->orderBy('guardians.id')
                ->first();
        }

        return null;
    }

    /**
     * Get student dashboard data.
     */
    public function dashboard(Request $request): JsonResponse
    {
        $student = $this->resolvePortalStudent($request);
        if (!$student) {
            return $this->error('Portal öğrencisi bulunamadı.', [], 404);
        }
        $student->load(['classroom', 'city', 'district']);

        // Bugünün ders programı (eski verilerde day_of_week string tutulduğu için iki formu da destekle)
        $dayNameMap = [
            0 => 'sunday',
            1 => 'monday',
            2 => 'tuesday',
            3 => 'wednesday',
            4 => 'thursday',
            5 => 'friday',
            6 => 'saturday',
        ];
        $todayDayIndex = now()->dayOfWeek;
        $todayDayName = $dayNameMap[$todayDayIndex] ?? null;

        $todaySchedule = \App\Models\Schedule::where('classroom_id', $student->classroom_id)
            ->where(function ($q) use ($todayDayIndex, $todayDayName) {
                $q->where('day_of_week', $todayDayIndex);
                if ($todayDayName) {
                    $q->orWhere('day_of_week', $todayDayName);
                }
            })
            ->with(['lesson', 'teacher'])
            ->orderBy('start_time')
            ->get();

        // Ödevler (öğrenciye atanmış)
        $homeworkAssignments = \App\Models\HomeworkStudentAssignment::query()
            ->where('student_id', $student->id)
            ->with(['homework' => function ($q) {
                $q->select(['id', 'title', 'due_date', 'lesson_id', 'is_active'])
                    ->with('lesson:id,name')
                    ->where('is_active', true);
            }])
            ->get()
            ->filter(fn ($assignment) => $assignment->homework !== null)
            ->values();

        // Yaklaşan ödevler
        $upcomingHomeworks = \App\Models\Homework::whereHas('assignments', function ($q) use ($student) {
                $q->where('student_id', $student->id);
            })
            ->where('is_active', true)
            ->where('due_date', '>=', now())
            ->with(['lesson'])
            ->orderBy('due_date')
            ->take(5)
            ->get();

        // Son duyurular
        $announcements = \App\Models\Announcement::query()
            ->where('status', 'published')
            ->where('tenant_id', $student->tenant_id)
            ->where(function ($q) {
                $q->whereNull('target_roles')
                    ->orWhereJsonContains('target_roles', 'student')
                    ->orWhereJsonContains('target_roles', 'Öğrenci');
            })
            ->orderBy('created_at', 'desc')
            ->limit(5)
            ->get();

        // Günün menüsü
        $todayMenu = \App\Models\MealMenu::query()
            ->where('tenant_id', $student->tenant_id)
            ->whereDate('menu_date', now()->toDateString())
            ->where(function ($q) use ($student) {
                $q->where('classroom_id', $student->classroom_id)
                    ->orWhereJsonContains('target_student_ids', $student->id)
                    ->orWhereNull('classroom_id');
            })
            ->orderBy('meal_type')
            ->first();

        $completedHomeworkCount = $homeworkAssignments
            ->where('review_status', 'done')
            ->count();

        $pendingHomeworkCount = $homeworkAssignments->count() - $completedHomeworkCount;

        return $this->success([
            'student' => [
                'id' => $student->id,
                'name' => $student->name,
                'school_no' => $student->school_no,
                'classroom' => $student->classroom ? [
                    'id' => $student->classroom->id,
                    'name' => $student->classroom->name,
                ] : null,
            ],
            'summary' => [
                'pending_homework_count' => max(0, $pendingHomeworkCount),
                'completed_homework_count' => $completedHomeworkCount,
            ],
            'today_schedule' => $todaySchedule->map(function ($schedule) {
                return [
                    'id' => $schedule->id,
                    'day_of_week' => $schedule->day_of_week,
                    'start_time' => $schedule->start_time instanceof \DateTimeInterface
                        ? $schedule->start_time->format('H:i')
                        : (is_string($schedule->start_time) ? substr($schedule->start_time, 0, 5) : $schedule->start_time),
                    'end_time' => $schedule->end_time instanceof \DateTimeInterface
                        ? $schedule->end_time->format('H:i')
                        : (is_string($schedule->end_time) ? substr($schedule->end_time, 0, 5) : $schedule->end_time),
                    'lesson' => $schedule->lesson ? [
                        'id' => $schedule->lesson->id,
                        'name' => $schedule->lesson->name,
                    ] : null,
                    'teacher' => $schedule->teacher ? [
                        'id' => $schedule->teacher->id,
                        'name' => $schedule->teacher->name,
                    ] : null,
                ];
            }),
            'upcoming_homeworks' => $upcomingHomeworks,
            'today_menu' => $todayMenu ? [
                'id' => $todayMenu->id,
                'menu_date' => $todayMenu->menu_date?->format('Y-m-d'),
                'meal_type' => $todayMenu->meal_type,
                'meals' => $todayMenu->meals,
                'notes' => $todayMenu->notes,
            ] : null,
            'announcements' => $announcements->map(function ($announcement) {
                return [
                    'id' => $announcement->id,
                    'title' => $announcement->title,
                    'message' => $announcement->message,
                    'type' => $announcement->type,
                    'created_at' => $announcement->created_at?->toIso8601String(),
                ];
            }),
        ], 'Dashboard verileri başarıyla getirildi.');
    }

    /**
     * Get student schedule.
     */
    public function getSchedule(Request $request): JsonResponse
    {
        $student = $this->resolvePortalStudent($request);
        if (!$student) {
            return $this->error('Portal öğrencisi bulunamadı.', [], 404);
        }

        if (!$student->classroom_id) {
            return $this->error('Öğrenci bir sınıfa atanmamış.', [], 400);
        }

        $schedules = \App\Models\Schedule::where('tenant_id', $student->tenant_id)
            ->where('classroom_id', $student->classroom_id)
            ->whereHas('lesson', function ($lessonQuery) use ($student) {
                $lessonQuery->where('tenant_id', $student->tenant_id)
                    ->where('is_active', true);
            })
            ->with(['lesson', 'teacher'])
            ->orderBy('day_of_week')
            ->orderBy('start_time')
            ->get();

        return $this->success([
            'schedules' => $schedules->map(function ($schedule) {
                return [
                    'id' => $schedule->id,
                    'day_of_week' => $schedule->day_of_week,
                    'start_time' => $schedule->start_time instanceof \DateTimeInterface
                        ? $schedule->start_time->format('H:i')
                        : (is_string($schedule->start_time) ? substr($schedule->start_time, 0, 5) : $schedule->start_time),
                    'end_time' => $schedule->end_time instanceof \DateTimeInterface
                        ? $schedule->end_time->format('H:i')
                        : (is_string($schedule->end_time) ? substr($schedule->end_time, 0, 5) : $schedule->end_time),
                    'lesson' => $schedule->lesson ? [
                        'id' => $schedule->lesson->id,
                        'name' => $schedule->lesson->name,
                    ] : null,
                    'teacher' => $schedule->teacher ? [
                        'id' => $schedule->teacher->id,
                        'name' => $schedule->teacher->name,
                    ] : null,
                    'remote_link' => $schedule->remote_link,
                ];
            }),
        ], 'Ders programı başarıyla getirildi.');
    }

    /**
     * Get student homework.
     */
    public function getHomework(Request $request): JsonResponse
    {
        $student = $this->resolvePortalStudent($request);
        if (!$student) {
            return $this->error('Portal öğrencisi bulunamadı.', [], 404);
        }

        $query = \App\Models\Homework::whereHas('assignments', function ($q) use ($student) {
                $q->where('student_id', $student->id);
            })
            ->where('is_active', true)
            ->with([
                'lesson',
                'teacher',
                'assignments' => function ($q) use ($student) {
                    $q->where('student_id', $student->id);
                },
            ]);

        // Online ödevler filtresi
        if ($request->has('is_online')) {
            $query->where('is_online', $request->is_online);
        }

        // Proje ödevi filtresi
        if ($request->has('is_project')) {
            $query->where('is_project', $request->is_project);
        }

        $homeworks = $query->orderBy('due_date', 'desc')->paginate(20);

        return $this->success([
            'homeworks' => $homeworks->map(function ($homework) use ($student) {
                $submission = $homework->submissions()->where('student_id', $student->id)->first();
                $assignment = $homework->assignments->first();
                return [
                    'id' => $homework->id,
                    'title' => $homework->title,
                    'description' => $homework->description,
                    'due_date' => $homework->due_date?->format('Y-m-d'),
                    'is_online' => $homework->is_online,
                    'is_project' => $homework->is_project,
                    'project_topics' => $homework->project_topics,
                    'submission' => $submission ? [
                        'id' => $submission->id,
                        'status' => $submission->status,
                        'submitted_at' => $submission->submitted_at?->format('Y-m-d H:i'),
                        'grade' => $submission->score,
                        'selected_topic' => $submission->project_topic_id !== null && isset($homework->project_topics[$submission->project_topic_id]) 
                            ? $homework->project_topics[$submission->project_topic_id] 
                            : null,
                    ] : null,
                    'lesson' => $homework->lesson ? [
                        'id' => $homework->lesson->id,
                        'name' => $homework->lesson->name,
                    ] : null,
                    'teacher' => $homework->teacher ? [
                        'id' => $homework->teacher->id,
                        'name' => $homework->teacher->name,
                    ] : null,
                    'review' => [
                        'status' => $assignment?->review_status,
                        'status_label' => match ($assignment?->review_status) {
                            'done' => 'Yaptı',
                            'partial' => 'Yarım Yaptı',
                            'missing' => 'Eksik',
                            'not_done' => 'Yapmadı',
                            default => 'Değerlendirilmedi',
                        },
                        'teacher_note' => $assignment?->teacher_note,
                        'reviewed_at' => $assignment?->reviewed_at?->format('Y-m-d H:i'),
                    ],
                ];
            }),
            'pagination' => [
                'current_page' => $homeworks->currentPage(),
                'last_page' => $homeworks->lastPage(),
                'per_page' => $homeworks->perPage(),
                'total' => $homeworks->total(),
            ],
        ], 'Ödevler başarıyla getirildi.');
    }

    /**
     * Get student homework control report.
     */
    public function getHomeworkControlReport(Request $request): JsonResponse
    {
        $student = $this->resolvePortalStudent($request);
        if (!$student) {
            return $this->error('Portal öğrencisi bulunamadı.', [], 404);
        }

        $startDate = $request->input('start_date', now()->startOfMonth()->format('Y-m-d'));
        $endDate = $request->input('end_date', now()->endOfMonth()->format('Y-m-d'));

        $homeworks = \App\Models\Homework::whereHas('assignments', function ($q) use ($student) {
                $q->where('student_id', $student->id);
            })
            ->whereBetween('due_date', [$startDate, $endDate])
            ->with(['lesson', 'teacher', 'submissions' => function ($q) use ($student) {
                $q->where('student_id', $student->id);
            }])
            ->get();

        $totalHomeworks = $homeworks->count();
        $submittedCount = $homeworks->filter(function ($hw) {
            return $hw->submissions->isNotEmpty() && $hw->submissions->first()->status !== 'pending';
        })->count();
        $gradedCount = $homeworks->filter(function ($hw) {
            return $hw->submissions->isNotEmpty() && $hw->submissions->first()->status === 'graded';
        })->count();
        $pendingCount = $totalHomeworks - $submittedCount;
        $averageScore = $homeworks->flatMap->submissions->where('status', 'graded')->avg('score');

        return $this->success([
            'student_id' => $student->id,
            'period' => [
                'from' => $startDate,
                'to' => $endDate,
            ],
            'statistics' => [
                'total_homeworks' => $totalHomeworks,
                'submitted_count' => $submittedCount,
                'graded_count' => $gradedCount,
                'pending_count' => $pendingCount,
                'average_score' => $averageScore ? round($averageScore, 2) : null,
                'submission_rate' => $totalHomeworks > 0 ? round(($submittedCount / $totalHomeworks) * 100, 2) : 0,
                'grading_rate' => $submittedCount > 0 ? round(($gradedCount / $submittedCount) * 100, 2) : 0,
            ],
            'homeworks' => $homeworks->map(function ($homework) {
                $submission = $homework->submissions->first();
                return [
                    'id' => $homework->id,
                    'title' => $homework->title,
                    'due_date' => $homework->due_date?->format('Y-m-d'),
                    'lesson' => $homework->lesson?->name,
                    'teacher' => $homework->teacher?->name,
                    'submission_status' => $submission ? $submission->status : 'not_submitted',
                    'submitted_at' => $submission?->submitted_at?->format('Y-m-d H:i'),
                    'graded_at' => $submission?->graded_at?->format('Y-m-d H:i'),
                    'score' => $submission?->score,
                    'teacher_notes' => $submission?->teacher_notes,
                ];
            }),
        ], 'Ödev kontrol raporu başarıyla getirildi.');
    }

    /**
     * Get student attendance.
     */
    public function getAttendance(Request $request): JsonResponse
    {
        $student = $this->resolvePortalStudent($request);
        if (!$student) {
            return $this->error('Portal öğrencisi bulunamadı.', [], 404);
        }

        $startDate = $request->input('start_date', now()->startOfMonth()->format('Y-m-d'));
        $endDate = $request->input('end_date', now()->endOfMonth()->format('Y-m-d'));

        $attendances = \App\Models\Attendance::where('student_id', $student->id)
            ->whereBetween('date', [$startDate, $endDate])
            ->with(['schedule.lesson', 'teacher'])
            ->orderBy('date', 'desc')
            ->get();

        $groupedByDate = $attendances->groupBy(fn ($attendance) => optional($attendance->date)->format('Y-m-d'));

        $attendanceByDay = $groupedByDate->map(function ($dayItems, $date) {
            $statuses = $dayItems->pluck('status')->filter()->values();

            $dayStatus = 'present';
            if ($statuses->contains('absent')) {
                $dayStatus = 'absent';
            } elseif ($statuses->contains('excused') || $statuses->contains('sick')) {
                $dayStatus = 'excused';
            }

            return [
                'date' => $date,
                'status' => $dayStatus,
                'status_label' => match ($dayStatus) {
                    'absent' => 'Gelmedi',
                    'excused' => 'İzinli/Raporlu',
                    default => 'Geldi',
                },
                'entries' => $dayItems->map(function ($attendance) {
                    return [
                        'id' => $attendance->id,
                        'status' => $attendance->status,
                        'lesson' => $attendance->schedule && $attendance->schedule->lesson ? [
                            'id' => $attendance->schedule->lesson->id,
                            'name' => $attendance->schedule->lesson->name,
                        ] : null,
                    ];
                })->values(),
            ];
        })->values();

        $cameDaysCount = $attendanceByDay->where('status', 'present')->count();
        $absentDaysCount = $attendanceByDay->where('status', 'absent')->count();
        $excusedDaysCount = $attendanceByDay->where('status', 'excused')->count();

        $problemDays = $attendanceByDay
            ->whereIn('status', ['absent', 'excused'])
            ->values();

        return $this->success([
            'summary' => [
                'came_days' => $cameDaysCount,
                'absent_days' => $absentDaysCount,
                'excused_or_reported_days' => $excusedDaysCount,
            ],
            'problem_days' => $problemDays,
            'attendances' => $attendanceByDay,
            'period' => [
                'start_date' => $startDate,
                'end_date' => $endDate,
            ],
        ], 'Devamsızlık bilgileri başarıyla getirildi.');
    }

    /**
     * Get student announcements.
     */
    public function getAnnouncements(Request $request): JsonResponse
    {
        $student = $this->resolvePortalStudent($request);
        if (!$student) {
            return $this->error('Portal öğrencisi bulunamadı.', [], 404);
        }

        $announcements = \App\Models\Announcement::query()
            ->where('tenant_id', $student->tenant_id)
            ->where('status', 'published')
            ->where(function ($q) {
                $q->whereNull('target_roles')
                    ->orWhereJsonContains('target_roles', 'student')
                    ->orWhereJsonContains('target_roles', 'Öğrenci');
            })
            ->orderBy('created_at', 'desc')
            ->paginate(20);

        return $this->success([
            'announcements' => $announcements->map(function ($announcement) {
                return [
                    'id' => $announcement->id,
                    'title' => $announcement->title,
                    'message' => $announcement->message,
                    'type' => $announcement->type,
                    'created_at' => $announcement->created_at?->toIso8601String(),
                ];
            })->values(),
            'pagination' => [
                'current_page' => $announcements->currentPage(),
                'last_page' => $announcements->lastPage(),
                'per_page' => $announcements->perPage(),
                'total' => $announcements->total(),
            ],
        ], 'Duyurular başarıyla getirildi.');
    }

    /**
     * Get student grades.
     */
    public function getGrades(Request $request): JsonResponse
    {
        $student = $this->resolvePortalStudent($request);
        if (!$student) {
            return $this->error('Portal öğrencisi bulunamadı.', [], 404);
        }

        $grades = \App\Models\Grade::where('student_id', $student->id)
            ->with(['exam', 'lesson'])
            ->orderBy('created_at', 'desc')
            ->get();

        return $this->success([
            'grades' => $grades->map(function ($grade) {
                return [
                    'id' => $grade->id,
                    'score' => $grade->score,
                    'grade_type' => $grade->grade_type,
                    'exam' => $grade->exam ? [
                        'id' => $grade->exam->id,
                        'name' => $grade->exam->name,
                        'exam_date' => $grade->exam->exam_date?->format('Y-m-d'),
                    ] : null,
                    'lesson' => $grade->lesson ? [
                        'id' => $grade->lesson->id,
                        'name' => $grade->lesson->name,
                    ] : null,
                ];
            }),
        ], 'Notlar başarıyla getirildi.');
    }

    /**
     * Change password.
     */
    public function changePassword(Request $request): JsonResponse
    {
        $request->validate([
            'current_password' => 'required|string',
            'new_password' => 'required|string|min:6|confirmed',
        ]);

        $actor = $request->user();
        if (!$actor || !isset($actor->password)) {
            return $this->error('Kullanıcı bulunamadı.', [], 404);
        }

        if (!Hash::check($request->current_password, $actor->password)) {
            return $this->error('Mevcut şifre hatalı.', [], 400);
        }

        $actor->update([
            'password' => Hash::make($request->new_password),
        ]);

        return $this->success(null, 'Şifre başarıyla değiştirildi.');
    }

    /**
     * Get guardian profile for portal.
     */
    public function getProfile(Request $request): JsonResponse
    {
        $guardian = $this->resolvePortalGuardian($request);
        $student = $this->resolvePortalStudent($request);

        if (!$guardian) {
            return $this->error('Veli profili bulunamadı.', [], 404);
        }

        return $this->success([
            'id' => $guardian->id,
            'name' => $guardian->name,
            'email' => $guardian->email,
            'phone' => $guardian->phone,
            'role_name' => 'Veli',
            'student' => $student ? [
                'id' => $student->id,
                'name' => $student->name,
                'school_no' => $student->school_no,
            ] : null,
            'created_at' => $guardian->created_at?->toIso8601String(),
            'last_login_at' => $guardian->last_login_at?->toIso8601String(),
        ], 'Veli profili getirildi.');
    }

    /**
     * Update guardian profile for portal.
     */
    public function updateProfile(Request $request): JsonResponse
    {
        $guardian = $this->resolvePortalGuardian($request);
        if (!$guardian) {
            return $this->error('Veli profili bulunamadı.', [], 404);
        }

        $validated = $request->validate([
            'name' => 'sometimes|string|max:255',
            'email' => 'sometimes|email|unique:guardians,email,'.$guardian->id,
            'phone' => 'nullable|string|max:20',
        ]);

        $guardian->fill($validated);
        $guardian->save();

        return $this->success([
            'id' => $guardian->id,
            'name' => $guardian->name,
            'email' => $guardian->email,
            'phone' => $guardian->phone,
        ], 'Veli profili güncellendi.');
    }

    /**
     * Get calendar events for student.
     */
    public function getCalendar(Request $request): JsonResponse
    {
        $student = $this->resolvePortalStudent($request);
        if (!$student) {
            return $this->error('Portal öğrencisi bulunamadı.', [], 404);
        }
        
        $startDate = $request->input('start_date', now()->startOfMonth()->format('Y-m-d'));
        $endDate = $request->input('end_date', now()->endOfMonth()->format('Y-m-d'));

        // Öğrenciyle ilgili etkinlikler
        $events = \App\Models\CalendarEvent::where(function ($q) use ($student) {
            // Öğrenci katılımcı olarak eklenmiş
            $q->whereHas('participants', function ($pq) use ($student) {
                $pq->where('student_id', $student->id);
            })
            // Veya hedef kitleye students dahil
            ->orWhere(function ($sq) use ($student) {
                $sq->where('is_public', true)
                    ->where(function ($tq) use ($student) {
                        $tq->whereJsonContains('target_audience', [['type' => 'all']])
                            ->orWhereJsonContains('target_audience', [['type' => 'students']])
                            ->orWhereJsonContains('target_audience', [['type' => 'specific', 'ids' => [$student->id]]]);
                    });
            });
        })
            ->whereBetween('event_date', [$startDate, $endDate])
            ->with(['creator', 'participants'])
            ->orderBy('event_date')
            ->orderBy('start_time')
            ->get();

        return $this->success([
            'events' => $events->map(function ($event) {
                return [
                    'id' => $event->id,
                    'title' => $event->title,
                    'description' => $event->description,
                    'event_type' => $event->event_type,
                    'event_date' => $event->event_date?->format('Y-m-d'),
                    'start_time' => $event->start_time,
                    'end_time' => $event->end_time,
                    'location' => $event->location,
                    'is_all_day' => $event->is_all_day,
                    'is_public' => $event->is_public,
                ];
            }),
            'period' => [
                'start_date' => $startDate,
                'end_date' => $endDate,
            ],
        ], 'Ajanda başarıyla getirildi.');
    }

    /**
     * Get student tutoring sessions.
     */
    public function getTutoringSessions(Request $request): JsonResponse
    {
        $student = $this->resolvePortalStudent($request);
        if (!$student) {
            return $this->error('Portal öğrencisi bulunamadı.', [], 404);
        }

        $startDate = $request->input('start_date', now()->startOfMonth()->format('Y-m-d'));
        $endDate = $request->input('end_date', now()->endOfMonth()->format('Y-m-d'));

        $sessions = \App\Models\TutoringSession::whereHas('students', function ($q) use ($student) {
            $q->where('students.id', $student->id);
        })
            ->whereBetween('date', [$startDate, $endDate])
            ->with(['lesson', 'teacher'])
            ->orderBy('date')
            ->orderBy('start_time')
            ->get();

        return $this->success([
            'sessions' => $sessions->map(function ($session) use ($student) {
                $attendance = \App\Models\TutoringSessionAttendance::where('tutoring_session_id', $session->id)
                    ->where('student_id', $student->id)
                    ->first();
                return [
                    'id' => $session->id,
                    'title' => $session->title,
                    'type' => $session->type,
                    'date' => $session->date?->format('Y-m-d'),
                    'start_time' => $session->start_time?->format('H:i'),
                    'end_time' => $session->end_time?->format('H:i'),
                    'room' => $session->room,
                    'remote_link' => $session->remote_link,
                    'lesson' => $session->lesson ? [
                        'id' => $session->lesson->id,
                        'name' => $session->lesson->name,
                    ] : null,
                    'teacher' => $session->teacher ? [
                        'id' => $session->teacher->id,
                        'name' => $session->teacher->name,
                    ] : null,
                    'attendance' => $attendance ? [
                        'status' => $attendance->status,
                        'notes' => $attendance->notes,
                    ] : null,
                ];
            }),
            'period' => [
                'start_date' => $startDate,
                'end_date' => $endDate,
            ],
        ], 'Etüt bilgileri başarıyla getirildi.');
    }

    /**
     * Get student online exams.
     */
    public function getOnlineExams(Request $request): JsonResponse
    {
        $student = $this->resolvePortalStudent($request);
        if (!$student) {
            return $this->error('Portal öğrencisi bulunamadı.', [], 404);
        }

        $query = \App\Models\OnlineExam::where(function ($q) use ($student) {
            $q->where('classroom_id', $student->classroom_id)
                ->orWhereNull('classroom_id');
        })
            ->where('status', 'active')
            ->with(['lesson']);

        $exams = $query->orderBy('start_time', 'desc')->get();

        return $this->success([
            'exams' => $exams->map(function ($exam) use ($student) {
                $attempt = $exam->attempts()->where('student_id', $student->id)->latest()->first();
                return [
                    'id' => $exam->id,
                    'title' => $exam->title,
                    'description' => $exam->description,
                    'start_time' => $exam->start_time?->format('Y-m-d H:i'),
                    'end_time' => $exam->end_time?->format('Y-m-d H:i'),
                    'duration_minutes' => $exam->duration_minutes,
                    'total_points' => $exam->total_points,
                    'lesson' => $exam->lesson ? [
                        'id' => $exam->lesson->id,
                        'name' => $exam->lesson->name,
                    ] : null,
                    'attempt' => $attempt ? [
                        'id' => $attempt->id,
                        'status' => $attempt->status,
                        'score' => $attempt->score,
                        'percentage' => $attempt->percentage,
                        'submitted_at' => $attempt->submitted_at?->format('Y-m-d H:i'),
                    ] : null,
                    'can_take' => $exam->canStudentTakeExam($student->id),
                ];
            }),
        ], 'Online sınavlar başarıyla getirildi.');
    }

    /**
     * Get student appointments.
     */
    public function getAppointments(Request $request): JsonResponse
    {
        $student = $this->resolvePortalStudent($request);
        if (!$student) {
            return $this->error('Portal öğrencisi bulunamadı.', [], 404);
        }

        $startDate = $request->input('start_date', now()->startOfMonth()->format('Y-m-d'));
        $endDate = $request->input('end_date', now()->endOfMonth()->format('Y-m-d'));

        // Öğrenciyle ilgili randevular (lead üzerinden)
        $appointments = \App\Models\Appointment::whereHas('lead', function ($q) use ($student) {
            $q->where('student_id', $student->id);
        })
            ->whereBetween('appointment_date', [$startDate, $endDate])
            ->with(['lead', 'assignedUser'])
            ->orderBy('appointment_date')
            ->get();

        return $this->success([
            'appointments' => $appointments->map(function ($appointment) {
                return [
                    'id' => $appointment->id,
                    'name' => $appointment->name,
                    'phone' => $appointment->phone,
                    'appointment_date' => $appointment->appointment_date?->format('Y-m-d H:i'),
                    'status' => $appointment->status,
                    'notes' => $appointment->notes,
                    'assigned_to' => $appointment->assignedUser ? [
                        'id' => $appointment->assignedUser->id,
                        'name' => $appointment->assignedUser->name,
                    ] : null,
                ];
            }),
            'period' => [
                'start_date' => $startDate,
                'end_date' => $endDate,
            ],
        ], 'Randevular başarıyla getirildi.');
    }

    /**
     * Get student guidance notes.
     */
    public function getGuidanceNotes(Request $request): JsonResponse
    {
        $student = $this->resolvePortalStudent($request);
        if (!$student) {
            return $this->error('Portal öğrencisi bulunamadı.', [], 404);
        }

        // Öğrenci kendi notlarını görebilir (gizli olmayanlar)
        $notes = \App\Models\GuidanceNote::where('student_id', $student->id)
            ->where('is_confidential', false)
            ->where('is_admin_approved', true)
            ->with(['counselor'])
            ->orderBy('note_date', 'desc')
            ->orderBy('note_time', 'desc')
            ->get();

        return $this->success([
            'notes' => $notes->map(function ($note) {
                return [
                    'id' => $note->id,
                    'title' => $note->title,
                    'content' => $note->content,
                    'type' => $note->type,
                    'note_date' => $note->note_date?->format('Y-m-d'),
                    'note_time' => $note->note_time,
                    'counselor' => $note->counselor ? [
                        'id' => $note->counselor->id,
                        'name' => $note->counselor->name,
                    ] : null,
                ];
            }),
        ], 'Rehberlik notları başarıyla getirildi.');
    }

    /**
     * Get student meal menus.
     */
    public function getMealMenus(Request $request): JsonResponse
    {
        $student = $this->resolvePortalStudent($request);
        if (!$student) {
            return $this->error('Portal öğrencisi bulunamadı.', [], 404);
        }

        $startDate = $request->input('start_date', now()->startOfWeek()->format('Y-m-d'));
        $endDate = $request->input('end_date', now()->endOfWeek()->format('Y-m-d'));

        $menus = \App\Models\MealMenu::query()
            ->where('tenant_id', $student->tenant_id)
            ->where(function ($q) use ($student) {
                $q->where('classroom_id', $student->classroom_id)
                    ->orWhereJsonContains('target_student_ids', $student->id)
                    ->orWhereNull('classroom_id');
            })
            ->whereBetween('menu_date', [$startDate, $endDate])
            ->orderBy('menu_date')
            ->orderBy('meal_type')
            ->get();

        return $this->success([
            'menus' => $menus->map(function ($menu) {
                return [
                    'id' => $menu->id,
                    'menu_date' => $menu->menu_date?->format('Y-m-d'),
                    'meal_type' => $menu->meal_type,
                    'meals' => $menu->meals,
                    'notes' => $menu->notes,
                ];
            }),
            'period' => [
                'start_date' => $startDate,
                'end_date' => $endDate,
            ],
        ], 'Yemek menüleri başarıyla getirildi.');
    }

    /**
     * Get student bulletins and achievement certificates.
     */
    public function getBulletins(Request $request): JsonResponse
    {
        $student = $this->resolvePortalStudent($request);
        if (!$student) {
            return $this->error('Portal öğrencisi bulunamadı.', [], 404);
        }

        $bulletins = \App\Models\Bulletin::where('student_id', $student->id)
            ->where('is_published_to_guardian', true)
            ->with(['template', 'creator'])
            ->orderBy('bulletin_date', 'desc')
            ->get();

        $certificates = \App\Models\AchievementCertificate::where('student_id', $student->id)
            ->with(['template', 'creator'])
            ->orderBy('certificate_date', 'desc')
            ->get();

        return $this->success([
            'bulletins' => $bulletins->map(function ($bulletin) {
                return [
                    'id' => $bulletin->id,
                    'title' => $bulletin->title,
                    'content' => $bulletin->content,
                    'bulletin_date' => $bulletin->bulletin_date?->format('Y-m-d'),
                    'photo_ids' => $bulletin->photo_ids,
                    'teacher_comments' => $bulletin->teacher_comments,
                    'achievements' => $bulletin->achievements,
                ];
            }),
            'certificates' => $certificates->map(function ($certificate) {
                return [
                    'id' => $certificate->id,
                    'title' => $certificate->title,
                    'description' => $certificate->description,
                    'certificate_date' => $certificate->achievement_date?->format('Y-m-d'),
                    'achievement_type' => $certificate->achievement_type,
                    'photo_ids' => $certificate->photo_ids,
                ];
            }),
        ], 'Bültenler ve başarı belgeleri başarıyla getirildi.');
    }

    /**
     * Get student activities.
     */
    public function getActivities(Request $request): JsonResponse
    {
        $student = $this->resolvePortalStudent($request);
        if (!$student) {
            return $this->error('Portal öğrencisi bulunamadı.', [], 404);
        }

        $activities = \App\Models\Activity::where('is_published', true)
            ->where('is_admin_approved', true)
            ->where(function ($q) use ($student) {
                $q->where('share_type', 'all')
                    ->orWhere(function ($sq) use ($student) {
                        $sq->where('share_type', 'single_student')
                            ->whereJsonContains('target_student_ids', $student->id);
                    })
                    ->orWhere(function ($sq) use ($student) {
                        $sq->where('share_type', 'target_group')
                            ->where('classroom_id', $student->classroom_id);
                    });
            })
            ->with(['creator'])
            ->orderBy('activity_date', 'desc')
            ->orderBy('activity_time', 'desc')
            ->get();

        return $this->success([
            'activities' => $activities->map(function ($activity) {
                return [
                    'id' => $activity->id,
                    'title' => $activity->title,
                    'description' => $activity->description,
                    'category' => $activity->category,
                    'activity_date' => $activity->activity_date?->format('Y-m-d'),
                    'activity_time' => $activity->activity_time,
                    'location' => $activity->location,
                    'photo_file_ids' => $activity->photo_file_ids,
                    'video_file_ids' => $activity->video_file_ids,
                    'view_count' => $activity->view_count,
                    'like_count' => $activity->like_count,
                ];
            }),
        ], 'Sosyal etkinlikler başarıyla getirildi.');
    }

    /**
     * Get student surveys (Form and Online).
     */
    public function getSurveys(Request $request): JsonResponse
    {
        $student = $this->resolvePortalStudent($request);
        if (!$student) {
            return $this->error('Portal öğrencisi bulunamadı.', [], 404);
        }

        // Form Anketler (hedef kitleye öğrenci dahil)
        $formSurveys = \App\Models\FormSurvey::where('is_active', true)
            ->where(function ($q) use ($student) {
                $q->whereJsonContains('target_audience', [['type' => 'all']])
                    ->orWhereJsonContains('target_audience', [['type' => 'students']])
                    ->orWhereJsonContains('target_audience', [['type' => 'specific', 'ids' => [$student->id]]]);
            })
            ->where(function ($q) {
                $q->whereNull('start_date')
                    ->orWhere('start_date', '<=', now());
            })
            ->where(function ($q) {
                $q->whereNull('end_date')
                    ->orWhere('end_date', '>=', now());
            })
            ->with(['creator'])
            ->orderBy('created_at', 'desc')
            ->get();

        // Online Anketler (hedef kitleye öğrenci dahil)
        $onlineSurveys = \App\Models\OnlineSurvey::where('is_active', true)
            ->where(function ($q) use ($student) {
                $q->whereJsonContains('target_audience', [['type' => 'all']])
                    ->orWhereJsonContains('target_audience', [['type' => 'students']])
                    ->orWhereJsonContains('target_audience', [['type' => 'specific', 'ids' => [$student->id]]]);
            })
            ->where(function ($q) {
                $q->whereNull('start_date')
                    ->orWhere('start_date', '<=', now());
            })
            ->where(function ($q) {
                $q->whereNull('end_date')
                    ->orWhere('end_date', '>=', now());
            })
            ->with(['creator', 'questions'])
            ->orderBy('created_at', 'desc')
            ->get();

        return $this->success([
            'form_surveys' => $formSurveys->map(function ($survey) use ($student) {
                // FormSurveyResponse'da respondent_id ve respondent_type kontrolü
                $response = $survey->responses()
                    ->where(function ($q) use ($student) {
                        $q->where('respondent_id', $student->id)
                            ->where('respondent_type', 'student');
                    })
                    ->first();
                return [
                    'id' => $survey->id,
                    'title' => $survey->title,
                    'description' => $survey->description,
                    'survey_type' => $survey->survey_type,
                    'start_date' => $survey->start_date?->format('Y-m-d'),
                    'end_date' => $survey->end_date?->format('Y-m-d'),
                    'is_required' => false,
                    'has_responded' => $response !== null,
                    'response_id' => $response?->id,
                ];
            }),
            'online_surveys' => $onlineSurveys->map(function ($survey) use ($student) {
                // OnlineSurveyResponse'da respondent_id ve respondent_type kontrolü
                $response = $survey->responses()
                    ->where(function ($q) use ($student) {
                        $q->where('respondent_id', $student->id)
                            ->where('respondent_type', 'student');
                    })
                    ->first();
                return [
                    'id' => $survey->id,
                    'title' => $survey->title,
                    'description' => $survey->description,
                    'start_date' => $survey->start_date?->format('Y-m-d'),
                    'end_date' => $survey->end_date?->format('Y-m-d'),
                    'is_required' => $survey->is_required,
                    'question_count' => $survey->question_count,
                    'has_responded' => $response !== null,
                    'response_id' => $response?->id,
                ];
            }),
        ], 'Anketler başarıyla getirildi.');
    }

    /**
     * Get student questions (Sorum Var).
     */
    public function getQuestions(Request $request): JsonResponse
    {
        $student = $this->resolvePortalStudent($request);
        if (!$student) {
            return $this->error('Portal öğrencisi bulunamadı.', [], 404);
        }

        $questions = \App\Models\Question::where('student_id', $student->id)
            ->with(['assignedUser', 'respondedBy'])
            ->orderBy('created_at', 'desc')
            ->get();

        return $this->success([
            'questions' => $questions->map(function ($question) {
                return [
                    'id' => $question->id,
                    'subject' => $question->subject,
                    'message' => $question->message,
                    'status' => $question->status,
                    'response' => $question->response,
                    'responded_at' => $question->responded_at?->format('Y-m-d H:i'),
                    'assigned_to' => $question->assignedUser ? [
                        'id' => $question->assignedUser->id,
                        'name' => $question->assignedUser->name,
                    ] : null,
                    'responded_by' => $question->respondedBy ? [
                        'id' => $question->respondedBy->id,
                        'name' => $question->respondedBy->name,
                    ] : null,
                ];
            }),
        ], 'Sorular başarıyla getirildi.');
    }

    /**
     * Get student meal attendance.
     */
    public function getMealAttendance(Request $request): JsonResponse
    {
        $student = $this->resolvePortalStudent($request);
        if (!$student) {
            return $this->error('Portal öğrencisi bulunamadı.', [], 404);
        }

        $startDate = $request->input('start_date', now()->startOfMonth()->format('Y-m-d'));
        $endDate = $request->input('end_date', now()->endOfMonth()->format('Y-m-d'));

        $attendances = \App\Models\MealAttendance::where('student_id', $student->id)
            ->whereBetween('attendance_date', [$startDate, $endDate])
            ->with(['mealMenu'])
            ->orderBy('attendance_date', 'desc')
            ->orderBy('meal_type')
            ->get();

        return $this->success([
            'attendances' => $attendances->map(function ($attendance) {
                return [
                    'id' => $attendance->id,
                    'attendance_date' => $attendance->attendance_date?->format('Y-m-d'),
                    'meal_type' => $attendance->meal_type,
                    'status' => $attendance->status,
                    'notes' => $attendance->notes,
                    'menu' => $attendance->mealMenu ? [
                        'id' => $attendance->mealMenu->id,
                        'meals' => $attendance->mealMenu->meals,
                    ] : null,
                ];
            }),
            'period' => [
                'start_date' => $startDate,
                'end_date' => $endDate,
            ],
        ], 'Yemek yoklama bilgileri başarıyla getirildi.');
    }

    /**
     * Get student notifications and SMS.
     */
    public function getNotifications(Request $request): JsonResponse
    {
        $student = $this->resolvePortalStudent($request);
        if (!$student) {
            return $this->error('Portal öğrencisi bulunamadı.', [], 404);
        }

        // Laravel notifications (bildirimler)
        $notifications = $student->notifications()
            ->orderBy('created_at', 'desc')
            ->paginate(20);

        // SMS raporları (öğrencinin velilerine gönderilen SMS'ler - guardian telefonlarına göre)
        $guardianPhones = $student->guardians()->pluck('phone')->filter();
        $smsReports = \App\Models\SmsReport::whereIn('phone', $guardianPhones)
            ->orderBy('sent_at', 'desc')
            ->paginate(20);

        return $this->success([
            'notifications' => [
                'data' => $notifications->map(function ($notification) {
                    $data = $notification->data;
                    return [
                        'id' => $notification->id,
                        'title' => $data['title'] ?? null,
                        'message' => $data['message'] ?? null,
                        'type' => $data['type'] ?? 'info',
                        'read_at' => $notification->read_at?->format('Y-m-d H:i'),
                        'created_at' => $notification->created_at?->format('Y-m-d H:i'),
                    ];
                }),
                'pagination' => [
                    'current_page' => $notifications->currentPage(),
                    'last_page' => $notifications->lastPage(),
                    'per_page' => $notifications->perPage(),
                    'total' => $notifications->total(),
                ],
            ],
            'sms_reports' => [
                'data' => $smsReports->map(function ($sms) {
                    return [
                        'id' => $sms->id,
                        'message' => $sms->message,
                        'phone' => $sms->phone,
                        'status' => $sms->status,
                        'sent_at' => $sms->sent_at?->format('Y-m-d H:i'),
                        'error_message' => $sms->error_message,
                    ];
                }),
                'pagination' => [
                    'current_page' => $smsReports->currentPage(),
                    'last_page' => $smsReports->lastPage(),
                    'per_page' => $smsReports->perPage(),
                    'total' => $smsReports->total(),
                ],
            ],
        ], 'Bildirimler ve SMS raporları başarıyla getirildi.');
    }

    /**
     * Mark notification as read.
     */
    public function markNotificationAsRead(Request $request, string $notificationId): JsonResponse
    {
        $student = $this->resolvePortalStudent($request);
        if (!$student) {
            return $this->error('Portal öğrencisi bulunamadı.', [], 404);
        }

        $notification = $student->notifications()->where('id', $notificationId)->first();

        if (!$notification) {
            return $this->error('Bildirim bulunamadı.', [], 404);
        }

        $notification->markAsRead();

        return $this->success(null, 'Bildirim okundu olarak işaretlendi.');
    }

    /**
     * Select project homework topic.
     */
    public function selectProjectTopic(Request $request, \App\Models\Homework $homework): JsonResponse
    {
        $student = $this->resolvePortalStudent($request);
        if (!$student) {
            return $this->error('Portal öğrencisi bulunamadı.', [], 404);
        }

        if (!$homework->is_project) {
            return $this->error('Bu ödev bir proje ödevi değil.', [], 400);
        }

        if (!$homework->project_topics || empty($homework->project_topics)) {
            return $this->error('Bu ödev için proje konuları tanımlanmamış.', [], 400);
        }

        $request->validate([
            'selected_topic' => ['required', 'string'],
        ]);

        $selectedTopic = $request->input('selected_topic');

        // Seçilen konu, ödevdeki konular arasında var mı kontrol et
        if (!in_array($selectedTopic, $homework->project_topics)) {
            return $this->error('Seçilen konu geçersiz.', [], 400);
        }

        // Submission oluştur veya güncelle
        // project_topics array'indeki index'i bul
        $topicIndex = array_search($selectedTopic, $homework->project_topics);
        
        if ($topicIndex === false) {
            return $this->error('Seçilen konu geçersiz.', [], 400);
        }

        $submission = \App\Models\HomeworkSubmission::firstOrNew([
            'homework_id' => $homework->id,
            'student_id' => $student->id,
        ]);

        $submission->project_topic_id = $topicIndex;
        $submission->status = 'pending'; // Konu seçildi, henüz submit edilmedi
        $submission->save();

        return $this->success([
            'submission' => [
                'id' => $submission->id,
                'selected_topic' => $selectedTopic,
                'project_topic_id' => $submission->project_topic_id,
                'status' => $submission->status,
            ],
        ], 'Proje konusu başarıyla seçildi.');
    }
}
