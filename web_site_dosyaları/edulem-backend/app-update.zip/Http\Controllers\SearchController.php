<?php

namespace App\Http\Controllers;

use App\Models\Student;
use App\Models\Lesson;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class SearchController extends ApiController
{
    /**
     * Global arama: öğrenci, ders, kullanıcı (isim, tc, okul no, e-posta, ders kodu vb.)
     */
    public function index(Request $request): JsonResponse
    {
        $q = $request->input('q', '');
        $q = trim($q);
        if (strlen($q) < 2) {
            return $this->success([
                'students' => [],
                'lessons' => [],
                'users' => [],
            ], 'Arama en az 2 karakter olmalıdır.');
        }

        $term = '%' . $q . '%';

        $user = auth()->user();
        $tenantId = $user?->tenant_id;
        $isSuperAdmin = $user && $user->is_superadmin;

        $students = collect();
        $lessons = collect();
        $users = collect();

        try {
            $studentQuery = Student::query()
                ->where(function ($query) use ($term) {
                    $query->where('name', 'like', $term)
                        ->orWhere('tc_no', 'like', $term)
                        ->orWhere('school_no', 'like', $term)
                        ->orWhere('phone', 'like', $term)
                        ->orWhere('email', 'like', $term);
                });
            if ($tenantId && !$isSuperAdmin) {
                $studentQuery->where('tenant_id', $tenantId);
            }
            $students = $studentQuery->limit(10)->get(['id', 'name', 'school_no', 'tc_no', 'classroom_id'])->map(fn ($s) => [
                'id' => $s->id,
                'name' => $s->name,
                'school_no' => $s->school_no,
                'tc_no' => $s->tc_no,
                'url' => '/students/' . $s->id,
            ]);
        } catch (\Throwable $e) {
            // ignore
        }

        try {
            $lessonQuery = Lesson::query()
                ->where(function ($query) use ($term) {
                    $query->where('name', 'like', $term)->orWhere('code', 'like', $term);
                });
            if ($tenantId && !$isSuperAdmin) {
                $lessonQuery->where('tenant_id', $tenantId);
            }
            $lessons = $lessonQuery->limit(10)->get(['id', 'name', 'code'])->map(fn ($l) => [
                'id' => $l->id,
                'name' => $l->name,
                'code' => $l->code,
                'url' => '/lessons',
            ]);
        } catch (\Throwable $e) {
            // ignore
        }

        try {
            $userQuery = User::query()
                ->where(function ($query) use ($term) {
                    $query->where('first_name', 'like', $term)
                        ->orWhere('last_name', 'like', $term)
                        ->orWhere('name', 'like', $term)
                        ->orWhere('email', 'like', $term);
                });
            if ($tenantId && !$isSuperAdmin) {
                $userQuery->where('tenant_id', $tenantId);
            }
            $users = $userQuery->limit(10)->get(['id', 'first_name', 'last_name', 'name', 'email'])->map(fn ($u) => [
                'id' => $u->id,
                'name' => $u->name ?: trim($u->first_name . ' ' . $u->last_name),
                'email' => $u->email,
                'url' => '/users/' . $u->id,
            ]);
        } catch (\Throwable $e) {
            // ignore
        }

        return $this->success([
            'students' => $students,
            'lessons' => $lessons,
            'users' => $users,
        ], 'Arama tamamlandı.');
    }
}
