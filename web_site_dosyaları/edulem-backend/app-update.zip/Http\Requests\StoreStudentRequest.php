<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreStudentRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            // Referans: Zorunlu alanlar – Ad Soyad, Okul No, Veli E-posta, Sınıf
            'student_name' => ['required', 'string', 'max:255'],
            'school_no' => ['required', 'string', 'max:50'],
            'classroom_id' => ['required', 'integer', 'exists:classrooms,id'],
            'is_active' => ['required', 'boolean'],

            // Referans: Opsiyonel alanlar – TC, Doğum Tarihi, Cinsiyet, Şehir
            'tc_no' => [
                'nullable',
                'string',
                function ($attribute, $value, $fail) {
                    $clean = preg_replace('/\D/', '', (string) $value);
                    if ($clean === '') return;
                    if (strlen($clean) !== 11) {
                        $fail('TC Kimlik No 11 haneli olmalıdır.');
                        return;
                    }
                    (new \App\Rules\ValidTcKimlikNo())->validate($attribute, $clean, $fail);
                },
            ],
            'birth_date' => ['nullable', 'date'],
            'gender' => ['nullable', 'in:male,female'],
            'city_id' => ['nullable', 'integer', 'exists:cities,id'],

            // İletişim ve adres (opsiyonel)
            'phone' => ['nullable', 'string', 'max:20'],
            'email' => ['nullable', 'email', 'max:255'],
            'address' => ['nullable', 'string', 'max:500'],
            'district_id' => [
                'nullable',
                'integer',
                function ($attribute, $value, $fail) {
                    if ($value !== null && $value !== 0 && $value !== '0' && $value > 0) {
                        if (!\App\Models\District::where('id', $value)->exists()) {
                            $fail('Seçilen ilçe geçersiz.');
                        }
                    }
                }
            ],

            'campus_id' => ['nullable', 'integer', 'exists:campuses,id'],
            'education_level_id' => ['nullable', 'integer', 'exists:education_levels,id'],

            // Referans: Yeni kayıtta en az bir veli ve veli e-postası zorunlu (velinin giriş yapacağı e-posta)
            'guardians' => array_filter([
                $this->isMethod('post') ? 'required' : 'nullable',
                'array',
                $this->isMethod('post') ? 'min:1' : null,
            ]),
            'guardians.0.email' => [$this->isMethod('post') ? 'required' : 'nullable', 'email', 'max:255'],
            'guardians.*.name' => ['nullable', 'string', 'max:255'],
            'guardians.*.tc_no' => [
                'nullable',
                'string',
                function ($attribute, $value, $fail) {
                    $clean = preg_replace('/\D/', '', (string) $value);
                    if ($clean === '') return;
                    if (strlen($clean) !== 11) {
                        $fail('Veli TC Kimlik No 11 haneli olmalıdır.');
                        return;
                    }
                    (new \App\Rules\ValidTcKimlikNo())->validate($attribute, $clean, $fail);
                },
            ],
            'guardians.*.phone' => ['nullable', 'string', 'max:20'],
            'guardians.*.email' => ['nullable', 'email', 'max:255'],
            'guardians.*.relation_type' => ['nullable', 'string', 'in:father,mother,guardian,other'],
            'guardians.*.is_legal_guardian' => ['nullable', 'boolean'],

            'emergency_contact_info' => ['nullable', 'array'],
            'emergency_contact_info.name' => ['nullable', 'string', 'max:255'],
            'emergency_contact_info.phone' => ['nullable', 'string', 'max:20'],
            'emergency_contact_info.relation' => ['nullable', 'string', 'max:100'],
        ];
    }

    /**
     * Get custom messages for validator errors.
     *
     * @return array<string, string>
     */
    public function messages(): array
    {
        return [
            'student_name.required' => 'Ad soyad zorunludur.',
            'school_no.required' => 'Okul numarası zorunludur.',
            'classroom_id.required' => 'Sınıf seçimi zorunludur.',
            'is_active.required' => 'Öğrenci durumu zorunludur.',
            'guardians.required' => 'En az bir veli bilgisi giriniz.',
            'guardians.0.email.required' => 'Veli e-posta adresi zorunludur (velinin giriş yapacağı e-posta).',
            'guardians.0.email.email' => 'Geçerli bir veli e-posta adresi giriniz.',
            'tc_no.size' => 'TC Kimlik No 11 haneli olmalıdır.',
            'birth_date.date' => 'Geçerli bir doğum tarihi giriniz.',
            'gender.in' => 'Cinsiyet erkek veya kadın olmalıdır.',
            'email.email' => 'Geçerli bir e-posta adresi giriniz.',
        ];
    }
}
