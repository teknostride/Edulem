<?php

namespace App\Http\Controllers;

use App\Http\Resources\NotificationResource;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class NotificationController extends ApiController
{
    /**
     * Get user notifications.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function index(Request $request): JsonResponse
    {
        try {
            $user = $request->user();
            
            // Mock notifications for now since we don't have a proper notification system
            $mockNotifications = [
                [
                    'id' => '1',
                    'type' => 'info',
                    'data' => [
                        'title' => 'Yeni Duyuru',
                        'message' => 'Okulda yeni duyuru yayınlandı',
                        'user_name' => 'Admin'
                    ],
                    'read_at' => null,
                    'created_at' => '2024-01-15 10:30:00',
                ],
                [
                    'id' => '2',
                    'type' => 'warning',
                    'data' => [
                        'title' => 'Ödev Hatırlatması',
                        'message' => 'Matematik ödevi yarın son gün',
                        'user_name' => 'Öğretmen'
                    ],
                    'read_at' => '2024-01-14 16:00:00',
                    'created_at' => '2024-01-14 15:45:00',
                ],
                [
                    'id' => '3',
                    'type' => 'success',
                    'data' => [
                        'title' => 'Sınav Sonuçları',
                        'message' => 'Fizik sınav sonuçları açıklandı',
                        'user_name' => 'Sistem'
                    ],
                    'read_at' => '2024-01-13 10:00:00',
                    'created_at' => '2024-01-13 09:15:00',
                ]
            ];

            // Apply filters
            if ($request->has('unread') && $request->boolean('unread')) {
                $mockNotifications = array_filter($mockNotifications, function ($notification) {
                    return is_null($notification['read_at']);
                });
            }

            $perPage = $request->get('per_page', 15);
            $page = $request->get('page', 1);
            $total = count($mockNotifications);

            return $this->success([
                'data' => array_slice($mockNotifications, ($page - 1) * $perPage, $perPage),
                'unread_count' => count(array_filter($mockNotifications, function ($notification) {
                    return is_null($notification['read_at']);
                })),
                'meta' => [
                    'current_page' => $page,
                    'last_page' => ceil($total / $perPage),
                    'per_page' => $perPage,
                    'total' => $total,
                ],
            ], 'Bildirimler başarıyla getirildi.');
        } catch (\Exception $e) {
            return $this->error('Bildirimler getirilirken bir hata oluştu: ' . $e->getMessage(), [], 500);
        }
    }

    /**
     * Get unread notifications count.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function unreadCount(): JsonResponse
    {
        try {
            // Mock unread count for now
            $unreadCount = 1;

            return $this->success([
                'unread_count' => $unreadCount
            ], 'Okunmamış bildirim sayısı getirildi.');
        } catch (\Exception $e) {
            return $this->error('Okunmamış bildirim sayısı getirilirken bir hata oluştu: ' . $e->getMessage(), [], 500);
        }
    }

    /**
     * Mark notification as read.
     *
     * @param  string  $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function markAsRead(string $id): JsonResponse
    {
        try {
            // Mock implementation for now
            return $this->success([], 'Bildirim okundu olarak işaretlendi.');
        } catch (\Exception $e) {
            return $this->error('Bildirim güncellenirken bir hata oluştu: ' . $e->getMessage(), [], 500);
        }
    }

    /**
     * Mark all notifications as read.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function markAllAsRead(): JsonResponse
    {
        try {
            // Mock implementation for now
            return $this->success([], 'Tüm bildirimler okundu olarak işaretlendi.');
        } catch (\Exception $e) {
            return $this->error('Bildirimler güncellenirken bir hata oluştu: ' . $e->getMessage(), [], 500);
        }
    }

    /**
     * Delete notification.
     *
     * @param  string  $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function destroy(string $id): JsonResponse
    {
        try {
            // Mock implementation for now
            return $this->success([], 'Bildirim silindi.');
        } catch (\Exception $e) {
            return $this->error('Bildirim silinirken bir hata oluştu: ' . $e->getMessage(), [], 500);
        }
    }
}
