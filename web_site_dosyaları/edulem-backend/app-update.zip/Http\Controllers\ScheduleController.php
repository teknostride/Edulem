<?php

namespace App\Http\Controllers;

use App\Models\Schedule;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Database\UniqueConstraintViolationException;
use Illuminate\Database\QueryException;

class ScheduleController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request): JsonResponse
    {
        $query = Schedule::with(['classroom', 'lesson', 'teacher']);

        $user = auth()->user();
        $roleName = $user && $user->role ? $user->role->name : null;
        $teacherOnlyRoles = ['Öğretmen', 'Sınıf Öğretmeni', 'Rehberlik'];
        $isTeacherOnly = $roleName && in_array($roleName, $teacherOnlyRoles, true);

        // Filter by day of week
        if ($request->has('day_of_week')) {
            $query->where('day_of_week', $request->day_of_week);
        }

        // Filter by classroom
        if ($request->has('classroom_id')) {
            $query->where('classroom_id', $request->classroom_id);
        }

        // Filter by teacher
        if ($request->has('teacher_id')) {
            $teacherId = (int) $request->teacher_id;
            if ($isTeacherOnly && $user && $teacherId !== (int) $user->id) {
                return response()->json(['message' => 'Bu işlemi yapmaya yetkiniz yok.'], 403);
            }
            $query->where('teacher_id', $teacherId);
        }

        // Search
        if ($request->has('search')) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->whereHas('classroom', function ($subQuery) use ($search) {
                    $subQuery->where('name', 'like', "%{$search}%");
                })
                    ->orWhereHas('lesson', function ($subQuery) use ($search) {
                        $subQuery->where('name', 'like', "%{$search}%");
                    })
                    ->orWhereHas('teacher', function ($subQuery) use ($search) {
                        $subQuery->where('first_name', 'like', "%{$search}%")
                            ->orWhere('last_name', 'like', "%{$search}%");
                    });
            });
        }

        // Sınıf veya öğretmen seçiliyse tüm programı getir (sayfalama yok); start_time/end_time HH:mm formatında
        if ($request->filled('classroom_id') || $request->filled('teacher_id')) {
            $schedules = $query->orderBy('day_of_week')->orderBy('start_time')->get();
            $items = $schedules->map(function ($s) {
                $arr = $s->toArray();
                $arr['start_time'] = $s->start_time instanceof \DateTimeInterface
                    ? $s->start_time->format('H:i')
                    : (is_string($s->start_time) ? substr($s->start_time, 0, 5) : $s->start_time);
                $arr['end_time'] = $s->end_time instanceof \DateTimeInterface
                    ? $s->end_time->format('H:i')
                    : (is_string($s->end_time) ? substr($s->end_time, 0, 5) : $s->end_time);
                return $arr;
            });
            return response()->json(['data' => $items->values()->all()]);
        }

        $schedules = $query->orderBy('day_of_week')->orderBy('start_time')->paginate(15);
        return response()->json([
            'data' => $schedules->items(),
            'meta' => [
                'total' => $schedules->total(),
                'per_page' => $schedules->perPage(),
                'current_page' => $schedules->currentPage(),
                'last_page' => $schedules->lastPage()
            ]
        ]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'classroom_id' => 'required|exists:classrooms,id',
            'lesson_id' => 'required|exists:lessons,id',
            'teacher_id' => 'required|exists:users,id',
            'day_of_week' => 'required|in:monday,tuesday,wednesday,thursday,friday,saturday,sunday',
            'start_time' => 'required|date_format:H:i',
            'end_time' => 'required|date_format:H:i|after:start_time',
            'time_slot_id' => 'nullable|exists:time_slots,id',
            'is_active' => 'boolean'
        ]);

        unset($validated['time_slot_id']);
        unset($validated['is_active']);
        $validated['tenant_id'] = auth()->user()?->tenant_id ?? 1;

        // Aynı sınıf + gün + saat zaten varsa güncelle (tekrar ekleme duplicate hatası vermesin)
        $existing = Schedule::where('classroom_id', $validated['classroom_id'])
            ->where('day_of_week', $validated['day_of_week'])
            ->where('start_time', $validated['start_time'])
            ->first();

        if ($existing) {
            $existing->update($validated);
            $existing->load(['classroom', 'lesson', 'teacher']);
            return response()->json([
                'data' => $existing,
                'message' => 'Ders programı güncellendi'
            ], 200);
        }

        try {
            $schedule = Schedule::create($validated);
            $schedule->load(['classroom', 'lesson', 'teacher']);
            return response()->json([
                'data' => $schedule,
                'message' => 'Ders programına eklendi'
            ], 201);
        } catch (UniqueConstraintViolationException $e) {
            return response()->json([
                'message' => 'Bu öğretmen bu saatte zaten başka bir sınıfta ders vermektedir. Başka öğretmen seçin veya farklı saat seçin.'
            ], 422);
        } catch (QueryException $e) {
            if ($e->getCode() === '23000' || str_contains($e->getMessage(), 'teacher_schedule_unique') || str_contains($e->getMessage(), '1062')) {
                return response()->json([
                    'message' => 'Bu öğretmen bu saatte zaten başka bir sınıfta ders vermektedir. Başka öğretmen seçin veya farklı saat seçin.'
                ], 422);
            }
            throw $e;
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(Schedule $schedule): JsonResponse
    {
        $schedule->load(['classroom', 'lesson', 'teacher']);

        return response()->json([
            'data' => $schedule
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Schedule $schedule): JsonResponse
    {
        $validated = $request->validate([
            'classroom_id' => 'sometimes|exists:classrooms,id',
            'lesson_id' => 'sometimes|exists:lessons,id',
            'teacher_id' => 'sometimes|exists:users,id',
            'day_of_week' => 'sometimes|in:monday,tuesday,wednesday,thursday,friday,saturday,sunday',
            'start_time' => 'sometimes|date_format:H:i',
            'end_time' => 'sometimes|date_format:H:i|after:start_time',
            'time_slot_id' => 'sometimes|exists:time_slots,id',
            'room' => 'nullable|string|max:255',
            'remote_link' => 'nullable|url',
            'program_type' => 'nullable|in:single,double',
            'program_id' => 'nullable|integer',
            'notes' => 'nullable|string',
        ]);

        $schedule->update($validated);
        $schedule->load(['classroom', 'lesson', 'teacher']);

        return response()->json([
            'data' => $schedule,
            'message' => 'Schedule updated successfully'
        ]);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Schedule $schedule): JsonResponse
    {
        $schedule->delete();

        return response()->json([
            'message' => 'Schedule deleted successfully'
        ]);
    }
}
