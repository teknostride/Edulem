<?php

namespace App\Http\Controllers;

use App\Actions\CreateStudentAction;
use App\Http\Requests\StoreStudentRequest;
use App\Http\Resources\StudentResource;
use App\Models\Classroom;
use App\Models\Schedule;
use App\Models\Student;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use Symfony\Component\HttpFoundation\StreamedResponse;
use Barryvdh\DomPDF\Facade\Pdf;

class StudentController extends ApiController
{
    private const TEACHER_ROLES = ['Öğretmen', 'Sınıf Öğretmeni', 'teacher', 'Rehberlik', 'guidance', 'Rehber Öğretmen', 'rehber_teacher', 'guidance_teacher'];
    private const GUIDANCE_ROLE_IDS = [6];

    private function isTeacherRole(?string $roleName): bool
    {
        return $roleName && in_array($roleName, self::TEACHER_ROLES, true);
    }

    private function isGuidanceRole($user): bool
    {
        if ($user && !empty($user->role_id) && in_array((int) $user->role_id, self::GUIDANCE_ROLE_IDS, true)) {
            return true;
        }

        $roleName = $user && $user->role ? $user->role->name : null;
        return $roleName && in_array($roleName, ['Rehberlik', 'guidance', 'Rehber Öğretmen', 'rehber_teacher', 'guidance_teacher'], true);
    }

    private function teacherAllowedClassroomIds($user): array
    {
        if ($this->isGuidanceRole($user)) {
            $educationLevelIds = array_filter(array_map('intval', (array) ($user->education_level_ids ?? [])));
            if (empty($educationLevelIds)) {
                return [];
            }

            $campusIds = array_filter(array_map('intval', (array) ($user->campus_ids ?? [])));

            $query = Classroom::query()
                ->where('tenant_id', $user->tenant_id)
                ->whereIn('grade_level', $educationLevelIds);

            if (!empty($campusIds)) {
                $query->whereHas('educationLevel', function ($q) use ($campusIds) {
                    $q->whereIn('campus_id', $campusIds);
                });
            }

            return $query
                ->pluck('id')
                ->map(fn ($id) => (int) $id)
                ->filter(fn ($id) => $id > 0)
                ->unique()
                ->values()
                ->all();
        }

        return Schedule::query()
            ->where('tenant_id', $user->tenant_id)
            ->where('teacher_id', $user->id)
            ->whereNotNull('classroom_id')
            ->pluck('classroom_id')
            ->map(fn ($id) => (int) $id)
            ->filter(fn ($id) => $id > 0)
            ->unique()
            ->values()
            ->all();
    }

    private function teacherCannotAccessStudent(Student $student): bool
    {
        $user = auth()->user();
        $roleName = $user && $user->role ? $user->role->name : null;
        if (! $user || ! $this->isTeacherRole($roleName)) {
            return false;
        }

        $allowedClassroomIds = $this->teacherAllowedClassroomIds($user);
        return ! in_array((int) $student->classroom_id, $allowedClassroomIds, true);
    }

    private function teacherCannotAccessClassroom(int $classroomId): bool
    {
        $user = auth()->user();
        $roleName = $user && $user->role ? $user->role->name : null;
        if (! $user || ! $this->isTeacherRole($roleName)) {
            return false;
        }

        $allowedClassroomIds = $this->teacherAllowedClassroomIds($user);
        return ! in_array($classroomId, $allowedClassroomIds, true);
    }

    /**
     * Display a listing of students.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function index(): JsonResponse
    {
        try {
            $query = Student::with([
                'city',
                'district',
                'classroom' => function ($q) {
                    $q->with([
                        'branch' => function ($q2) {
                            $q2->with('campus');
                        },
                        'educationLevel' => function ($q2) {
                            $q2->with('campus');
                        },
                    ]);
                }
            ]);

            // Tenant kontrolü - Giriş yapan kullanıcının tenant_id'sine göre filtrele
            // SuperAdmin için tenant kontrolü yapma
            $user = auth()->user();
            $userTenantId = $user ? $user->tenant_id : null;
            $isSuperAdmin = $user && $user->is_superadmin;

            // Eğer kullanıcı giriş yapmışsa ve SuperAdmin değilse tenant kontrolü yap
            if ($user && !$isSuperAdmin && $userTenantId) {
                $query->where('tenant_id', $userTenantId);
            }

            // Müdür / Müdür Yardımcısı: Sadece kurum tarafından atandığı kampüs ve kademelerdeki öğrencileri görebilir
            // Kampüs eşlemesi: Öğrenci listesindeki kampüs filtresiyle aynı mantık – kademenin (education_level) campus_id'si
            $roleName = $user && $user->role ? $user->role->name : null;
            if ($this->isTeacherRole($roleName) && $user) {
                $allowedClassroomIds = $this->teacherAllowedClassroomIds($user);
                if (empty($allowedClassroomIds)) {
                    $query->whereRaw('1 = 0');
                } else {
                    $query->whereIn('classroom_id', $allowedClassroomIds);
                }
            }

            if (in_array($roleName, ['Müdür', 'Müdür Yardımcısı', 'Öğrenci İşleri', 'student_affairs'], true) && $user) {
                $campusIds = array_filter(array_map('intval', (array) ($user->campus_ids ?? [])));
                $educationLevelIds = array_filter(array_map('intval', (array) ($user->education_level_ids ?? [])));
                if (empty($campusIds) && empty($educationLevelIds)) {
                    $query->whereRaw('1 = 0');
                } else {
                    $query->whereHas('classroom', function ($q) use ($campusIds, $educationLevelIds) {
                        if (!empty($campusIds)) {
                            $q->whereHas('educationLevel', function ($qEl) use ($campusIds) {
                                $qEl->whereIn('campus_id', $campusIds);
                            });
                        }
                        if (!empty($educationLevelIds)) {
                            $q->whereIn('grade_level', $educationLevelIds);
                        }
                    });
                }
            }

            // Filtreleme: Kampüs = kademenin (education_level) kayıtlı olduğu kampüs; kademe filtresi = classroom.grade_level
            $campusId = request()->input('campus_id');
            if ($campusId !== null && $campusId !== '') {
                $campusId = (int) $campusId;
                $query->whereHas('classroom.educationLevel', function ($q) use ($campusId) {
                    $q->where('campus_id', $campusId);
                });
            }

            $educationLevelId = request()->input('education_level_id');
            if ($educationLevelId !== null && $educationLevelId !== '') {
                $query->whereHas('classroom', function ($q) use ($educationLevelId) {
                    $q->where('grade_level', $educationLevelId);
                });
            }

            $classroomId = request()->input('classroom_id');
            if ($classroomId !== null && $classroomId !== '') {
                $query->where('classroom_id', (int) $classroomId);
            }

            $classIds = request()->input('class_ids');
            if ($classIds !== null) {
                if (is_string($classIds)) {
                    $classIds = array_filter(array_map('trim', explode(',', $classIds)));
                }

                if (is_array($classIds)) {
                    $classIds = array_filter(array_map('intval', $classIds), static fn ($id) => $id > 0);
                    if (! empty($classIds)) {
                        $query->whereIn('classroom_id', $classIds);
                    }
                }
            }

            $isActive = request()->input('is_active');
            if ($isActive !== null && $isActive !== '') {
                $isActiveBool = in_array($isActive, ['1', 1, true, 'true'], true);
                $query->where('is_active', $isActiveBool);
            }

            $search = request()->input('search');
            if ($search !== null) {
                $search = trim((string) $search);
                if ($search !== '') {
                    $query->where(function ($q) use ($search) {
                        $q->where('student_name', 'like', '%' . $search . '%')
                            ->orWhere('tc_no', 'like', '%' . $search . '%')
                            ->orWhere('school_no', 'like', '%' . $search . '%')
                            ->orWhereHas('classroom', function ($q2) use ($search) {
                                $q2->where('name', 'like', '%' . $search . '%');
                            });
                    });
                }
            }

            $perPage = (int) request()->get('per_page', 15);
            if ($perPage <= 0) {
                $perPage = 15;
            }
            $perPage = min($perPage, 100);
            $students = $query->paginate($perPage);

            return $this->success([
                'students' => StudentResource::collection($students),
                'pagination' => [
                    'current_page' => $students->currentPage(),
                    'last_page' => $students->lastPage(),
                    'per_page' => $students->perPage(),
                    'total' => $students->total(),
                ],
            ], 'Öğrenciler başarıyla listelendi.');
        } catch (\Exception $e) {
            return $this->error('Öğrenciler listelenirken bir hata oluştu: ' . $e->getMessage(), [], 500);
        }
    }

    public function export(Request $request): StreamedResponse|JsonResponse
    {
        try {
            $format = (string) $request->input('format', 'excel');
            if (! in_array($format, ['excel', 'pdf'], true)) {
                return $this->error('Geçersiz format. Sadece excel veya pdf desteklenir.', [], 422);
            }

            $scope = (string) $request->input('scope', 'all');
            if (! in_array($scope, ['all', 'classrooms', 'students'], true)) {
                return $this->error('Geçersiz kapsam (scope).', [], 422);
            }

            $requestedColumns = $request->input('columns', []);
            if (! is_array($requestedColumns) || empty($requestedColumns)) {
                return $this->error('En az 1 sütun seçmelisiniz.', [], 422);
            }

            $user = $request->user();
            $roleName = $user && $user->role ? $user->role->name : null;
            $isTeacherRole = $this->isTeacherRole($roleName);

            $allowedColumns = [
                'student_name' => ['label' => 'Ad Soyad'],
                'school_no' => ['label' => 'Öğrenci No'],
                'tc_no' => ['label' => 'TC Kimlik'],
                'classroom_name' => ['label' => 'Sınıf'],
                'campus_name' => ['label' => 'Kampüs'],
                'education_level_name' => ['label' => 'Kademe'],
                'phone' => ['label' => 'Telefon'],
                'email' => ['label' => 'E-posta'],
                'address' => ['label' => 'Adres'],
                'birth_date' => ['label' => 'Doğum Tarihi'],
                'gender' => ['label' => 'Cinsiyet'],
                'is_active' => ['label' => 'Durum'],
                'guardian1_name' => ['label' => 'Veli 1 Adı'],
                'guardian1_phone' => ['label' => 'Veli 1 Telefon'],
                'guardian2_name' => ['label' => 'Veli 2 Adı'],
                'guardian2_phone' => ['label' => 'Veli 2 Telefon'],
            ];

            if (! $isTeacherRole) {
                $allowedColumns['emergency_phone'] = ['label' => 'Acil Durum Telefon'];
            }

            $columns = array_values(array_filter(array_map(static fn ($c) => is_string($c) ? trim($c) : '', $requestedColumns)));
            $columns = array_values(array_unique($columns));
            $columns = array_values(array_filter($columns, static fn ($c) => $c !== '' && array_key_exists($c, $allowedColumns)));

            if (empty($columns)) {
                return $this->error('Geçerli sütun bulunamadı.', [], 422);
            }

            if ($isTeacherRole) {
                $columns = array_values(array_filter($columns, static fn ($c) => $c !== 'tc_no'));
                if (empty($columns)) {
                    return $this->error('Yetkiniz dahilinde dışa aktarılabilecek sütun bulunamadı.', [], 403);
                }
            }

            $query = Student::query();

            $userTenantId = $user ? $user->tenant_id : null;
            $isSuperAdmin = $user && $user->is_superadmin;
            if ($user && ! $isSuperAdmin && $userTenantId) {
                $query->where('tenant_id', $userTenantId);
            }

            if ($isTeacherRole && $user) {
                $allowedClassroomIds = $this->teacherAllowedClassroomIds($user);
                if (empty($allowedClassroomIds)) {
                    $query->whereRaw('1 = 0');
                } else {
                    $query->whereIn('classroom_id', $allowedClassroomIds);
                }
            }

            if (in_array($roleName, ['Müdür', 'Müdür Yardımcısı', 'Öğrenci İşleri', 'student_affairs'], true) && $user) {
                $campusIds = array_filter(array_map('intval', (array) ($user->campus_ids ?? [])));
                $educationLevelIds = array_filter(array_map('intval', (array) ($user->education_level_ids ?? [])));
                if (empty($campusIds) && empty($educationLevelIds)) {
                    $query->whereRaw('1 = 0');
                } else {
                    $query->whereHas('classroom', function ($q) use ($campusIds, $educationLevelIds) {
                        if (!empty($campusIds)) {
                            $q->whereHas('educationLevel', function ($qEl) use ($campusIds) {
                                $qEl->whereIn('campus_id', $campusIds);
                            });
                        }
                        if (!empty($educationLevelIds)) {
                            $q->whereIn('grade_level', $educationLevelIds);
                        }
                    });
                }
            }

            if ($scope === 'classrooms') {
                $classroomIds = $request->input('classroom_ids', []);
                if (! is_array($classroomIds) || empty($classroomIds)) {
                    return $this->error('Seçili sınıflar için classroom_ids zorunludur.', [], 422);
                }
                $classroomIds = array_values(array_unique(array_filter(array_map('intval', $classroomIds), static fn ($id) => $id > 0)));
                if (empty($classroomIds)) {
                    return $this->error('Geçerli classroom_ids bulunamadı.', [], 422);
                }
                $query->whereIn('classroom_id', $classroomIds);
            }

            if ($scope === 'students') {
                $studentIds = $request->input('student_ids', []);
                if (! is_array($studentIds) || empty($studentIds)) {
                    return $this->error('Seçili öğrenciler için student_ids zorunludur.', [], 422);
                }
                $studentIds = array_values(array_unique(array_filter(array_map('intval', $studentIds), static fn ($id) => $id > 0)));
                if (empty($studentIds)) {
                    return $this->error('Geçerli student_ids bulunamadı.', [], 422);
                }
                $query->whereIn('id', $studentIds);
            }

            $campusId = $request->input('campus_id');
            if ($campusId !== null && $campusId !== '') {
                $campusId = (int) $campusId;
                $query->whereHas('classroom.educationLevel', function ($q) use ($campusId) {
                    $q->where('campus_id', $campusId);
                });
            }

            $educationLevelId = $request->input('education_level_id');
            if ($educationLevelId !== null && $educationLevelId !== '') {
                $query->whereHas('classroom', function ($q) use ($educationLevelId) {
                    $q->where('grade_level', $educationLevelId);
                });
            }

            $classroomId = $request->input('classroom_id');
            if ($classroomId !== null && $classroomId !== '') {
                $query->where('classroom_id', (int) $classroomId);
            }

            $isActive = $request->input('is_active');
            if ($isActive !== null && $isActive !== '') {
                $isActiveBool = in_array($isActive, ['1', 1, true, 'true'], true);
                $query->where('is_active', $isActiveBool);
            }

            $needsClassroom = (bool) array_intersect($columns, ['classroom_name', 'campus_name', 'education_level_name']);
            $needsGuardians = (bool) array_intersect($columns, ['guardian1_name', 'guardian1_phone', 'guardian2_name', 'guardian2_phone']);

            $baseSelect = ['id', 'tenant_id', 'classroom_id', 'name', 'school_no', 'phone', 'email', 'address', 'birth_date', 'gender', 'is_active'];
            if (in_array('tc_no', $columns, true)) {
                $baseSelect[] = 'tc_no';
            }
            if (in_array('emergency_phone', $columns, true)) {
                $baseSelect[] = 'emergency_contact_info';
            }

            $query->select(array_values(array_unique($baseSelect)));

            $with = [];
            if ($needsClassroom) {
                $with['classroom'] = function ($q) {
                    $q->with([
                        'branch' => function ($q2) {
                            $q2->with('campus');
                        },
                        'educationLevel' => function ($q2) {
                            $q2->with('campus');
                        },
                    ]);
                };
            }
            if ($needsGuardians) {
                $with[] = 'guardians';
            }
            if (! empty($with)) {
                $query->with($with);
            }

            $students = $query->orderBy('name')->get();

            $headers = array_map(static fn ($c) => $allowedColumns[$c]['label'], $columns);
            $rows = [];
            foreach ($students as $student) {
                $classroom = $student->relationLoaded('classroom') ? $student->classroom : null;
                $guardians = $student->relationLoaded('guardians') ? $student->guardians : collect();

                $campusName = $classroom?->educationLevel?->campus?->name
                    ?? $classroom?->branch?->campus?->name
                    ?? null;

                $row = [];
                foreach ($columns as $c) {
                    $row[] = match ($c) {
                        'student_name' => (string) ($student->name ?? ''),
                        'school_no' => (string) ($student->school_no ?? ''),
                        'tc_no' => (string) ($student->tc_no ?? ''),
                        'classroom_name' => (string) ($classroom?->name ?? ''),
                        'campus_name' => (string) ($campusName ?? ''),
                        'education_level_name' => (string) ($classroom?->educationLevel?->name ?? ''),
                        'phone' => (string) ($student->phone ?? ''),
                        'email' => (string) ($student->email ?? ''),
                        'address' => (string) ($student->address ?? ''),
                        'birth_date' => $student->birth_date ? $student->birth_date->format('Y-m-d') : '',
                        'gender' => (string) ($student->gender ?? ''),
                        'is_active' => $student->is_active ? 'Aktif' : 'Pasif',
                        'guardian1_name' => (string) ($guardians->first()?->name ?? ''),
                        'guardian1_phone' => (string) ($guardians->first()?->phone ?? ''),
                        'guardian2_name' => (string) ($guardians->skip(1)->first()?->name ?? ''),
                        'guardian2_phone' => (string) ($guardians->skip(1)->first()?->phone ?? ''),
                        'emergency_phone' => (string) (data_get($student->emergency_contact_info, 'phone') ?? ''),
                        default => '',
                    };
                }
                $rows[] = $row;
            }

            $tenantId = $user ? ($user->tenant_id ?? 'default') : 'default';
            $tenant = $tenantId ? \App\Models\Tenant::find($tenantId) : null;

            if ($format === 'excel') {
                $spreadsheet = new Spreadsheet();
                $sheet = $spreadsheet->getActiveSheet();

                $headerStyle = [
                    'font' => [
                        'bold' => true,
                        'color' => ['rgb' => 'FFFFFF'],
                        'size' => 12,
                    ],
                    'fill' => [
                        'fillType' => Fill::FILL_SOLID,
                        'startColor' => ['rgb' => '4472C4'],
                    ],
                    'alignment' => [
                        'horizontal' => Alignment::HORIZONTAL_CENTER,
                        'vertical' => Alignment::VERTICAL_CENTER,
                        'wrapText' => true,
                    ],
                    'borders' => [
                        'allBorders' => [
                            'borderStyle' => Border::BORDER_THIN,
                            'color' => ['rgb' => 'D1D5DB'],
                        ],
                    ],
                ];

                $zebraFill = [
                    'fill' => [
                        'fillType' => Fill::FILL_SOLID,
                        'startColor' => ['rgb' => 'F3F4F6'],
                    ],
                ];

                $cellStyle = [
                    'alignment' => [
                        'vertical' => Alignment::VERTICAL_CENTER,
                        'wrapText' => true,
                    ],
                    'borders' => [
                        'allBorders' => [
                            'borderStyle' => Border::BORDER_THIN,
                            'color' => ['rgb' => 'E5E7EB'],
                        ],
                    ],
                ];

                $rowIndex = 1;
                $col = 'A';
                foreach ($headers as $header) {
                    $sheet->setCellValue($col.$rowIndex, $header);
                    $sheet->getStyle($col.$rowIndex)->applyFromArray($headerStyle);
                    $col++;
                }

                $rowIndex = 2;
                foreach ($rows as $rowData) {
                    $col = 'A';
                    foreach ($rowData as $cellValue) {
                        $sheet->setCellValue($col.$rowIndex, (string) $cellValue);
                        $sheet->getStyle($col.$rowIndex)->applyFromArray($cellStyle);
                        $col++;
                    }

                    if ($rowIndex % 2 === 0) {
                        $lastCol = Coordinate::stringFromColumnIndex(max(count($headers), 1));
                        $sheet->getStyle('A'.$rowIndex.':'.$lastCol.$rowIndex)->applyFromArray($zebraFill);
                    }
                    $rowIndex++;
                }

                $col = 'A';
                foreach ($headers as $_header) {
                    $sheet->getColumnDimension($col)->setAutoSize(true);
                    $col++;
                }

                $safeTenantName = preg_replace('/[^a-zA-Z0-9_\-]/', '_', (string) ($tenant?->name ?? 'kurum'));
                $fileName = 'ogrenciler_'.$safeTenantName.'_'.now()->format('Ymd_His').'.xlsx';

                return response()->streamDownload(function () use ($spreadsheet) {
                    $writer = new Xlsx($spreadsheet);
                    $writer->save('php://output');
                }, $fileName, [
                    'Content-Type' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                ]);
            }

            $data = [
                'title' => 'Öğrenci Listesi Raporu',
                'students' => $students,
                'export' => [
                    'columns' => $columns,
                    'headers' => $headers,
                    'rows' => $rows,
                ],
            ];

            $pdf = Pdf::loadView('reports.students', [
                'data' => $data,
                'parameters' => $request->all(),
                'tenant' => $tenant,
                'generatedAt' => now()->format('d.m.Y H:i'),
            ])->setPaper('a4', 'landscape');

            $safeTenantName = preg_replace('/[^a-zA-Z0-9_\-]/', '_', (string) ($tenant?->name ?? 'kurum'));
            $fileName = 'ogrenciler_'.$safeTenantName.'_'.now()->format('Ymd_His').'.pdf';

            return response()->streamDownload(function () use ($pdf) {
                echo $pdf->output();
            }, $fileName, [
                'Content-Type' => 'application/pdf',
            ]);
        } catch (\Exception $e) {
            return $this->error('Export sırasında hata oluştu: ' . $e->getMessage(), [], 500);
        }
    }

    /**
     * Store a newly created student in storage.
     *
     * @param  \App\Http\Requests\StoreStudentRequest  $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function store(StoreStudentRequest $request): JsonResponse
    {
        try {
            // CreateStudentAction zaten JsonResponse döndürüyor, direkt return et
            return (new CreateStudentAction())->execute($request->validated());
        } catch (\Exception $e) {
            return $this->error('Öğrenci eklenirken bir hata oluştu: ' . $e->getMessage(), [], 500);
        }
    }

    /**
     * Display the specified student.
     *
     * @param  int  $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function show(int $id): JsonResponse
    {
        $student = Student::with([
            'city',
            'district',
            'guardians',
            'classroom' => function ($q) {
                $q->with([
                    'branch' => function ($q2) {
                        $q2->with('campus');
                    },
                    'educationLevel' => function ($q2) {
                        $q2->with('campus');
                    }
                ]);
            }
        ])->find($id);

        if (!$student) {
            return $this->error('Öğrenci bulunamadı.', [], 404);
        }

        if ($this->mudurCannotAccessStudent($student)) {
            return $this->error('Bu öğrenciye erişim yetkiniz yok.', [], 403);
        }

        if ($this->teacherCannotAccessStudent($student)) {
            return $this->error('Bu öğrenciye erişim yetkiniz yok.', [], 403);
        }

        return $this->success(['student' => new StudentResource($student)], 'Öğrenci bilgileri getirildi.');
    }

    /**
     * Müdür rolündeki kullanıcının bu öğrenciye (kampüs/kademe kapsamında) erişip erişemeyeceğini kontrol eder.
     */
    private function mudurCannotAccessStudent(Student $student): bool
    {
        $user = auth()->user();
        if (!$user || !$user->role || !in_array($user->role->name, ['Müdür', 'Müdür Yardımcısı', 'Öğrenci İşleri', 'student_affairs'], true)) {
            return false;
        }
        $student->load(['classroom.educationLevel']);
        $classroom = $student->classroom;
        if (!$classroom) {
            return true;
        }
        $campusIds = array_filter(array_map('intval', (array) ($user->campus_ids ?? [])));
        $educationLevelIds = array_filter(array_map('intval', (array) ($user->education_level_ids ?? [])));
        $campusOk = empty($campusIds) || ($classroom->educationLevel && in_array((int) $classroom->educationLevel->campus_id, $campusIds, true));
        $levelOk = empty($educationLevelIds) || in_array((int) $classroom->grade_level, $educationLevelIds, true);
        return !$campusOk || !$levelOk;
    }

    /**
     * Öğretmen için sadece yetkili olduğu sınıfları döner.
     */
    public function teacherClassrooms(Request $request): JsonResponse
    {
        $user = $request->user();
        $roleName = $user && $user->role ? $user->role->name : null;

        if (! $this->isTeacherRole($roleName)) {
            return $this->error('Bu endpoint sadece öğretmen kullanıcılar içindir.', [], 403);
        }

        $classroomIds = $this->teacherAllowedClassroomIds($user);

        $classrooms = Classroom::query()
            ->where('tenant_id', $user->tenant_id)
            ->whereIn('id', $classroomIds)
            ->orderBy('name')
            ->get(['id', 'name']);

        return $this->success([
            'classrooms' => $classrooms,
        ], 'Öğretmen sınıf listesi başarıyla getirildi.');
    }

    /**
     * Öğretmenin seçtiği sınıftaki öğrencileri (TC olmadan) döner.
     */
    public function teacherStudentsByClassroom(Request $request, Classroom $classroom): JsonResponse
    {
        $user = $request->user();
        $roleName = $user && $user->role ? $user->role->name : null;

        if (! $this->isTeacherRole($roleName)) {
            return $this->error('Bu endpoint sadece öğretmen kullanıcılar içindir.', [], 403);
        }

        if ((int) $classroom->tenant_id !== (int) $user->tenant_id) {
            return $this->error('Sınıf bulunamadı.', [], 404);
        }

        if ($this->teacherCannotAccessClassroom((int) $classroom->id)) {
            return $this->error('Bu sınıfa erişim yetkiniz yok.', [], 403);
        }

        $students = Student::query()
            ->with(['classroom.educationLevel.campus', 'classroom.branch.campus', 'guardians', 'city', 'district'])
            ->where('tenant_id', $user->tenant_id)
            ->where('classroom_id', $classroom->id)
            ->orderBy('name')
            ->get();

        return $this->success([
            'classroom' => [
                'id' => $classroom->id,
                'name' => $classroom->name,
            ],
            'students' => StudentResource::collection($students),
        ], 'Sınıf öğrenci listesi başarıyla getirildi.');
    }

    /**
     * Müdür rolündeki kullanıcının bu sınıfa (kampüs/kademe kapsamında) erişip erişemeyeceğini kontrol eder.
     */
    private function mudurCannotAccessClassroom(int $classroomId): bool
    {
        $user = auth()->user();
        if (!$user || !$user->role || !in_array($user->role->name, ['Müdür', 'Müdür Yardımcısı', 'Öğrenci İşleri', 'student_affairs'], true)) {
            return false;
        }
        $classroom = \App\Models\Classroom::with('educationLevel')->find($classroomId);
        if (!$classroom) {
            return true;
        }
        $campusIds = array_filter(array_map('intval', (array) ($user->campus_ids ?? [])));
        $educationLevelIds = array_filter(array_map('intval', (array) ($user->education_level_ids ?? [])));
        $campusOk = empty($campusIds) || ($classroom->educationLevel && in_array((int) $classroom->educationLevel->campus_id, $campusIds, true));
        $levelOk = empty($educationLevelIds) || in_array((int) $classroom->grade_level, $educationLevelIds, true);
        return !$campusOk || !$levelOk;
    }

    /**
     * Update the specified student in storage.
     *
     * @param  \App\Http\Requests\StoreStudentRequest  $request
     * @param  int  $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function update(StoreStudentRequest $request, int $id): JsonResponse
    {
        $student = Student::find($id);

        if (!$student) {
            return $this->error('Öğrenci bulunamadı.', [], 404);
        }

        if ($this->mudurCannotAccessStudent($student)) {
            return $this->error('Bu öğrenciye erişim yetkiniz yok.', [], 403);
        }

        $data = $request->validated();
        // Müdür öğrenciyi sadece kendi kapsamındaki bir sınıfa taşıyabilir
        if (!empty($data['classroom_id']) && $this->mudurCannotAccessClassroom((int) $data['classroom_id'])) {
            return $this->error('Bu sınıfa atama yetkiniz yok.', [], 403);
        }

        try {
            if (isset($data['student_name'])) {
                $data['name'] = $data['student_name'];
                unset($data['student_name']);
            }
            $guardians = $data['guardians'] ?? null;
            unset($data['guardians']);
            $student->update($data);

            $guardianPasswords = (new \App\Actions\CreateStudentAction())->syncGuardiansForStudent($student, $guardians);
            $student->load([
                'guardians',
                'classroom' => function ($q) {
                    $q->with([
                        'branch' => function ($q2) {
                            $q2->with('campus');
                        },
                        'educationLevel'
                    ]);
                }
            ]);

            $response = ['student' => new StudentResource($student)];
            if (!empty($guardianPasswords)) {
                $response['guardian_passwords'] = $guardianPasswords;
            }
            return $this->success($response, 'Öğrenci başarıyla güncellendi.');
        } catch (\Exception $e) {
            return $this->error('Öğrenci güncellenirken bir hata oluştu: ' . $e->getMessage(), [], 500);
        }
    }

    /**
     * Remove the specified student from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function destroy(int $id): JsonResponse
    {
        $student = Student::find($id);

        if (!$student) {
            return $this->error('Öğrenci bulunamadı.', [], 404);
        }

        if ($this->mudurCannotAccessStudent($student)) {
            return $this->error('Bu öğrenciye erişim yetkiniz yok.', [], 403);
        }

        try {
            $student->delete();
            return $this->success([], 'Öğrenci başarıyla silindi.');
        } catch (\Exception $e) {
            return $this->error('Öğrenci silinirken bir hata oluştu: ' . $e->getMessage(), [], 500);
        }
    }
}
