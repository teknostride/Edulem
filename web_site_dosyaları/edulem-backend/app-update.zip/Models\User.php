<?php

namespace App\Models;

use App\Traits\BelongsToTenant;
use App\Traits\HasCampusPermissions;
use App\Traits\HasBranchPermissions;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasFactory, Notifiable, BelongsToTenant, HasApiTokens, HasCampusPermissions, HasBranchPermissions;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'tenant_id',
        'name',
        'first_name',
        'last_name',
        'birth_date',
        'wedding_anniversary_date',
        'email',
        'username',
        'phone',
        'password',
        'role_id',
        'is_superadmin',
        'theme_preference',
        'monochrome_mode',
        'campus_ids',
        'education_level_ids',
        'subjects',
        'teacher_type',
        'department',
        'is_active',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * Get the attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'birth_date' => 'date',
            'wedding_anniversary_date' => 'date',
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
            'is_superadmin' => 'boolean',
            'monochrome_mode' => 'boolean',
            'campus_ids' => 'array',
            'education_level_ids' => 'array',
            'subjects' => 'array',
            'is_active' => 'boolean',
            'theme_updated_at' => 'datetime',
        ];
    }

    /**
     * JSON alanları (subjects, campus_ids, education_level_ids) veritabanına
     * Türkçe karakterler escape edilmeden (Beden Eğitimi, Müzik) yazılsın.
     */
    protected function asJson($value): string
    {
        return json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }

    /**
     * Get the tenant that owns the user.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function tenant()
    {
        return $this->belongsTo(Tenant::class);
    }

    /**
     * Get the role that the user has.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function role()
    {
        return $this->belongsTo(Role::class);
    }

    public function counselingStudents(): HasMany
    {
        return $this->hasMany(CounselingStudent::class, 'counselor_id');
    }

    public function counselingSessions(): HasMany
    {
        return $this->hasMany(CounselingSession::class, 'counselor_id');
    }

    /**
     * Check if user has a specific permission.
     *
     * @param  string  $permissionName
     * @return bool
     */
    public function hasPermission(string $permissionName): bool
    {
        // SuperAdmin tüm izinlere sahiptir
        if ($this->is_superadmin) {
            return true;
        }

        if (!$this->role) {
            return false;
        }

        return $this->role->hasPermission($permissionName);
    }

    /**
     * Check if user has any of the given permissions.
     *
     * @param  array  $permissionNames
     * @return bool
     */
    public function hasAnyPermission(array $permissionNames): bool
    {
        // SuperAdmin tüm izinlere sahiptir
        if ($this->is_superadmin) {
            return true;
        }

        if (!$this->role) {
            return false;
        }

        return $this->role->permissions()
            ->whereIn('name', $permissionNames)
            ->exists();
    }

    /**
     * Check if user is SuperAdmin.
     *
     * @return bool
     */
    public function isSuperAdmin(): bool
    {
        return $this->is_superadmin === true;
    }

    /**
     * Check if user can access tenant data (SuperAdmin can access all).
     *
     * @param  int  $tenantId
     * @return bool
     */
    public function canAccessTenant(int $tenantId): bool
    {
        if ($this->is_superadmin) {
            return true;
        }

        return $this->tenant_id === $tenantId;
    }

    /**
     * Get the campuses that the user manages.
     */
    public function managedCampuses()
    {
        return $this->hasMany(Campus::class, 'manager_id');
    }

    /**
     * Get the branches that the user manages.
     */
    public function managedBranches()
    {
        return $this->hasMany(Branch::class, 'manager_id');
    }

    /**
     * Get campus permissions for the user.
     */
    public function campusPermissions()
    {
        return $this->hasMany(UserCampusPermission::class);
    }

    /**
     * Get branch permissions for the user.
     */
    public function branchPermissions()
    {
        return $this->hasMany(UserBranchPermission::class);
    }

    /**
     * Get module permissions for the user.
     */
    public function modulePermissions()
    {
        return $this->hasMany(UserModulePermission::class);
    }

    /**
     * Get campus/branch assignments for the user.
     */
    public function campusBranchAssignments()
    {
        return $this->hasMany(UserCampusBranchAssignment::class);
    }

    /**
     * Check if user is a branch manager.
     */
    public function isBranchManager(): bool
    {
        return $this->managedBranches()->exists();
    }

    /**
     * Get managed branch IDs.
     */
    public function getManagedBranchIds(): array
    {
        return $this->managedBranches()->pluck('id')->toArray();
    }

    /**
     * Scope query to filter by branch manager's branches.
     * 
     * @param \Illuminate\Database\Eloquent\Builder $query
     * @param \App\Models\User $user
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeForBranchManager($query, User $user)
    {
        if ($user->isBranchManager()) {
            $branchIds = $user->getManagedBranchIds();
            return $query->whereHas('classroom', function ($q) use ($branchIds) {
                $q->whereIn('branch_id', $branchIds);
            });
        }
        
        return $query;
    }

    /**
     * Get user's theme preference.
     */
    public function getThemePreference(): string
    {
        return $this->theme_preference ?? 'light';
    }

    /**
     * Check if user has monochrome mode enabled.
     */
    public function hasMonochromeMode(): bool
    {
        return $this->monochrome_mode ?? false;
    }

    /**
     * Update user's theme preference.
     */
    public function updateThemePreference(string $theme, bool $monochrome = false): bool
    {
        $this->theme_preference = $theme;
        $this->monochrome_mode = $monochrome;
        $this->theme_updated_at = now();
        
        return $this->save();
    }

    /**
     * Get theme settings as array.
     */
    public function getThemeSettings(): array
    {
        return [
            'theme' => $this->getThemePreference(),
            'monochrome' => $this->hasMonochromeMode(),
            'updated_at' => $this->theme_updated_at,
        ];
    }

    /**
     * Get staff duties assigned to this user.
     */
    public function staffDuties()
    {
        return $this->belongsToMany(StaffDuty::class, 'staff_duty_assignments', 'user_id', 'duty_id')
            ->withPivot(['assigned_by', 'assigned_at', 'expires_at', 'is_active', 'notes'])
            ->wherePivot('is_active', true)
            ->where(function ($query) {
                $query->whereNull('expires_at')
                    ->orWhere('expires_at', '>', now());
            });
    }

    /**
     * Get all staff duties including inactive ones.
     */
    public function allStaffDuties()
    {
        return $this->belongsToMany(StaffDuty::class, 'staff_duty_assignments', 'user_id', 'duty_id')
            ->withPivot(['assigned_by', 'assigned_at', 'expires_at', 'is_active', 'notes']);
    }

    /**
     * Assign a staff duty to this user.
     */
    public function assignStaffDuty($dutyId, $assignedBy = null, $expiresAt = null, $notes = null)
    {
        return $this->staffDuties()->attach($dutyId, [
            'assigned_by' => $assignedBy ?? auth()->id(),
            'assigned_at' => now(),
            'expires_at' => $expiresAt,
            'notes' => $notes,
        ]);
    }

    /**
     * Remove a staff duty from this user.
     */
    public function removeStaffDuty($dutyId)
    {
        return $this->staffDuties()->detach($dutyId);
    }

    /**
     * Check if user has specific duty.
     */
    public function hasStaffDuty($dutyName): bool
    {
        return $this->staffDuties()->where('name', $dutyName)->exists();
    }

    /**
     * Check if user has duties in specific category.
     */
    public function hasDutiesInCategory($category): bool
    {
        return $this->staffDuties()->where('category', $category)->exists();
    }

    /**
     * Get user's role display name.
     */
    public function getRoleDisplayName(): string
    {
        return $this->role ? $this->role->display_name : 'Bilinmeyen Rol';
    }

    /**
     * Get user's hierarchy level.
     */
    public function getHierarchyLevel(): int
    {
        // roles tablosunda hiyerarşi alanı `level` olarak tutuluyor.
        // Daha küçük level = daha üst rol.
        return $this->role ? (int) ($this->role->level ?? 0) : 0;
    }

    /**
     * Smaller role level means higher privilege.
     */
    public function getRoleLevel(): int
    {
        // Role yoksa en alt kabul edelim.
        return $this->role ? (int) ($this->role->level ?? 999) : 999;
    }

    /**
     * Smaller sort_order means higher privilege when level is equal.
     */
    public function getRoleSortOrder(): int
    {
        return $this->role ? (int) ($this->role->sort_order ?? 999) : 999;
    }

    /**
     * Rank tuple for comparing role privilege.
     */
    private function getRoleRank(): array
    {
        return [$this->getRoleLevel(), $this->getRoleSortOrder()];
    }

    /**
     * Can current user edit target user based on role hierarchy.
     * Rule: lower roles cannot edit higher roles.
     */
    public function canEditUser(User $target): bool
    {
        if ($this->is_superadmin) {
            return true;
        }

        if ((int) $this->id === (int) $target->id) {
            return true;
        }

        $myRoleName = $this->role?->name;
        $targetRoleName = $target->role?->name;

        // Öğrenci İşleri: üst rolleri asla yönetemez; ancak alt personeli (öğretmen vb.) yönetebilsin.
        if (in_array($myRoleName, ['Öğrenci İşleri', 'student_affairs'], true)) {
            $blocked = ['owner', 'Genel Müdür', 'Kampüs Müdürü', 'Müdür', 'Müdür Yardımcısı'];
            if ($targetRoleName && in_array($targetRoleName, $blocked, true)) {
                return false;
            }

            // Hedef rol tanımsızsa güvenli tarafta kal.
            if (!$targetRoleName) {
                return false;
            }

            // Student Affairs kendi seviyesindeki öğretmen/personel gibi rolleri yönetebilsin.
            $allowTargets = ['Öğretmen', 'Sınıf Öğretmeni', 'Rehberlik', 'Muhasebe'];
            if (in_array($targetRoleName, $allowTargets, true)) {
                return true;
            }
        }

        // Genel kural: daha üst rol (rank daha küçük) düzenleyebilir.
        $myRank = $this->getRoleRank();
        $targetRank = $target->getRoleRank();
        return $myRank < $targetRank;
    }

    /**
     * Check if user can manage other user.
     */
    public function canManageUser(User $user): bool
    {
        // Backward compatible: manage = edit logic
        return $this->canEditUser($user);
    }

    /**
     * Get user's permissions from role and duties.
     */
    public function getAllPermissions(): array
    {
        $rolePermissions = $this->role ? $this->role->permissions ?? [] : [];
        
        $dutyPermissions = $this->staffDuties()
            ->where('is_active', true)
            ->get()
            ->pluck('permissions')
            ->flatten()
            ->filter()
            ->toArray();

        return array_unique(array_merge($rolePermissions, $dutyPermissions));
    }

    /**
     * Check if user has all of the given permissions.
     */
    public function hasAllPermissions(array $permissions): bool
    {
        foreach ($permissions as $permission) {
            if (!$this->hasPermission($permission)) {
                return false;
            }
        }
        return true;
    }
}
