<?php

namespace App\Http\Controllers;

use App\Models\TimeSlot;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;

class TimeSlotController extends Controller
{
    /**
     * Display a listing of the resource.
     * Kademe (education_level_id) ile filtrelenir; farklı kademeler farklı ders saatlerine sahip olabilir.
     */
    public function index(Request $request): JsonResponse
    {
        $query = TimeSlot::query();

        $tenantId = auth()->user()?->tenant_id ?? null;
        if ($tenantId) {
            $query->where(function ($q) use ($tenantId) {
                $q->where('tenant_id', $tenantId)->orWhereNull('tenant_id');
            });
        }

        if ($request->filled('education_level_id')) {
            $query->where('education_level_id', $request->education_level_id);
        }

        if ($request->filled('campus_id')) {
            $query->whereHas('educationLevel', function ($q) use ($request) {
                $q->where('campus_id', $request->campus_id);
            });
        }

        if ($request->has('is_active')) {
            $query->where('is_active', $request->boolean('is_active'));
        }

        if ($request->filled('search')) {
            $query->where('name', 'like', '%' . $request->search . '%');
        }

        $timeSlots = $query->orderBy('order', 'asc')->paginate(15);

        return response()->json([
            'data' => $timeSlots->items(),
            'meta' => [
                'total' => $timeSlots->total(),
                'per_page' => $timeSlots->perPage(),
                'current_page' => $timeSlots->currentPage(),
                'last_page' => $timeSlots->lastPage()
            ]
        ]);
    }

    /**
     * Store a newly created resource in storage.
     * education_level_id zorunludur; ders saati ilgili kademeye bağlanır.
     */
    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'education_level_id' => 'required|exists:education_levels,id',
            'campus_id' => 'nullable|exists:campuses,id',
            'name' => 'required|string|max:255',
            'start_time' => 'required|date_format:H:i',
            'end_time' => 'required|date_format:H:i|after:start_time',
            'break_duration' => 'nullable|integer|min:0',
            'order' => 'required|integer|min:1',
            'is_active' => 'nullable|boolean'
        ]);

        $validated['tenant_id'] = auth()->user()?->tenant_id;
        $validated['is_active'] = $validated['is_active'] ?? true;
        unset($validated['campus_id']);
        unset($validated['break_duration']); // time_slots tablosunda kolon yok; ileride eklenebilir

        $timeSlot = TimeSlot::create($validated);

        return response()->json([
            'data' => $timeSlot,
            'message' => 'Time slot created successfully'
        ], 201);
    }

    /**
     * Display the specified resource.
     */
    public function show(TimeSlot $timeSlot): JsonResponse
    {
        $this->authorizeTenant($timeSlot);
        return response()->json([
            'data' => $timeSlot
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, TimeSlot $timeSlot): JsonResponse
    {
        $this->authorizeTenant($timeSlot);
        $validated = $request->validate([
            'name' => 'sometimes|string|max:255',
            'start_time' => 'sometimes|date_format:H:i',
            'end_time' => 'sometimes|date_format:H:i|after:start_time',
            'break_duration' => 'sometimes|integer|min:0',
            'order' => 'sometimes|integer|min:1',
            'is_active' => 'boolean'
        ]);

        $timeSlot->update($validated);

        return response()->json([
            'data' => $timeSlot,
            'message' => 'Time slot updated successfully'
        ]);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(TimeSlot $timeSlot): JsonResponse
    {
        $this->authorizeTenant($timeSlot);
        $timeSlot->delete();

        return response()->json([
            'message' => 'Time slot deleted successfully'
        ]);
    }

    private function authorizeTenant(TimeSlot $timeSlot): void
    {
        $tenantId = auth()->user()?->tenant_id;
        if ($tenantId !== null && $timeSlot->tenant_id !== null && (int) $timeSlot->tenant_id !== (int) $tenantId) {
            abort(403, 'Unauthorized');
        }
    }
}
