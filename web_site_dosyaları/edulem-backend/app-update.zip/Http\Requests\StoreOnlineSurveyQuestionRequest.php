<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreOnlineSurveyQuestionRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'online_survey_id' => ['required', 'exists:online_surveys,id'],
            'question' => ['required', 'string'],
            'question_type' => ['required', 'in:multiple_choice,single_choice,text,rating,scale'],
            'options' => ['required_if:question_type,multiple_choice,single_choice', 'array'],
            'is_required' => ['boolean'],
            'order' => ['nullable', 'integer', 'min:0'],
        ];
    }
}
