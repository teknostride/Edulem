<?php

namespace App\Jobs;

use App\Contracts\SmsServiceInterface;
use App\Services\NetgsmService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;

class SendSmsJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * The number of times the job may be attempted.
     *
     * @var int
     */
    public $tries = 3;

    /**
     * The number of seconds to wait before retrying the job.
     *
     * @var int
     */
    public $backoff = 60;

    /**
     * Phone numbers to send SMS to.
     *
     * @var string|array
     */
    protected string|array $phones;

    /**
     * SMS message content.
     *
     * @var string
     */
    protected string $message;

    /**
     * Tenant ID for SMS notification control.
     *
     * @var int|null
     */
    protected ?int $tenantId;

    /**
     * Create a new job instance.
     *
     * @param  string|array  $phones
     * @param  string  $message
     * @param  int|null  $tenantId
     */
    public function __construct(string|array $phones, string $message, ?int $tenantId = null)
    {
        $this->phones = $phones;
        $this->message = $message;
        $this->tenantId = $tenantId;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle(): void
    {
        try {
            // Kurucu kontrolü: Eğer tenant_id varsa ve SMS bildirimleri kapalıysa, SMS gönderme
            if ($this->tenantId !== null) {
                $tenant = \App\Models\Tenant::find($this->tenantId);
                
                if ($tenant && !$tenant->isSmsNotificationEnabled()) {
                    Log::info('SMS gönderimi atlandı - Kurucu SMS bildirimlerini kapalı tutmuş', [
                        'tenant_id' => $this->tenantId,
                        'tenant_name' => $tenant->name,
                        'phones' => $this->phones,
                    ]);
                    
                    // SMS gönderilmedi ama job başarılı sayılır (hata değil)
                    return;
                }

                // Kara liste kontrolü (RED seçeneği)
                $phones = is_array($this->phones) ? $this->phones : [$this->phones];
                $filteredPhones = [];
                
                foreach ($phones as $phone) {
                    if (!\App\Models\SmsBlacklist::isBlacklisted($phone, $this->tenantId)) {
                        $filteredPhones[] = $phone;
                    } else {
                        Log::info('SMS gönderimi atlandı - Telefon kara listede', [
                            'tenant_id' => $this->tenantId,
                            'phone' => $phone,
                        ]);
                    }
                }

                // Eğer tüm telefonlar kara listedeyse, job'ı başarılı say (hata değil)
                if (empty($filteredPhones)) {
                    return;
                }

                // Filtrelenmiş telefonlarla devam et
                $this->phones = count($filteredPhones) === 1 ? $filteredPhones[0] : $filteredPhones;
            }

            $smsService = $this->getSmsService();

            $result = $smsService->send($this->phones, $this->message);

            // SMS raporlarını kaydet
            $phones = is_array($this->phones) ? $this->phones : [$this->phones];

            foreach ($phones as $phone) {
                \App\Models\SmsReport::create([
                    'tenant_id' => $this->tenantId,
                    'phone' => $phone,
                    'message' => $this->message,
                    'status' => $result['success'] ? 'sent' : 'failed',
                    'message_id' => $result['message_id'] ?? null,
                    'error_code' => $result['error_code'] ?? null,
                    'error_message' => $result['success'] ? null : ($result['message'] ?? null),
                    'sent_at' => $result['success'] ? now() : null,
                    'sender_type' => $this->senderType ?? 'manual',
                    'sender_id' => $this->senderId ?? null,
                    'created_by' => null, // Job içinde user context yok, sender_id ile takip edilebilir
                ]);
            }

            if (!$result['success']) {
                Log::error('SMS gönderim başarısız', [
                    'phones' => $this->phones,
                    'error' => $result['message'],
                ]);

                // Hata durumunda job'ı fail et
                throw new \Exception($result['message']);
            }

            Log::info('SMS başarıyla gönderildi', [
                'phones' => $this->phones,
                'tenant_id' => $this->tenantId,
                'result' => $result,
            ]);
        } catch (\Exception $e) {
            Log::error('SMS Job hatası', [
                'phones' => $this->phones,
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);

            throw $e;
        }
    }

    /**
     * Get the SMS service instance based on database settings.
     *
     * @return \App\Contracts\SmsServiceInterface
     */
    protected function getSmsService(): SmsServiceInterface
    {
        // Veritabanından SMS ayarlarını oku
        // Şimdilik config'den okuyoruz, ileride settings tablosundan okunabilir
        $driver = config('sms.driver', 'netgsm');
        
        // Settings tablosundan okuma örneği (ileride eklenebilir)
        // $settings = DB::table('settings')->where('key', 'sms_driver')->first();
        // $driver = $settings?->value ?? 'netgsm';

        return match ($driver) {
            'netgsm' => $this->createNetgsmService(),
            default => throw new \Exception("Desteklenmeyen SMS sürücüsü: {$driver}"),
        };
    }

    /**
     * Create NetGSM service instance.
     *
     * @return \App\Services\NetgsmService
     */
    protected function createNetgsmService(): NetgsmService
    {
        // Config'den veya veritabanından ayarları al
        $username = config('sms.netgsm.username');
        $password = config('sms.netgsm.password');
        $msgheader = config('sms.netgsm.msgheader');

        // Eğer config'de yoksa, veritabanından oku (settings tablosu)
        // $settings = DB::table('settings')->pluck('value', 'key');
        // $username = $settings['sms_netgsm_username'] ?? '';
        // $password = $settings['sms_netgsm_password'] ?? '';
        // $msgheader = $settings['sms_netgsm_msgheader'] ?? '';

        if (empty($username) || empty($password) || empty($msgheader)) {
            throw new \Exception('NetGSM ayarları eksik. Lütfen SMS ayarlarını kontrol edin.');
        }

        return new NetgsmService($username, $password, $msgheader);
    }

    /**
     * Handle a job failure.
     *
     * @param  \Throwable  $exception
     * @return void
     */
    public function failed(\Throwable $exception): void
    {
        Log::error('SMS Job kalıcı olarak başarısız oldu', [
            'phones' => $this->phones,
            'message' => $this->message,
            'error' => $exception->getMessage(),
        ]);
    }
}
