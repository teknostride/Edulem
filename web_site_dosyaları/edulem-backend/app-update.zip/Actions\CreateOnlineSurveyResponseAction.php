<?php

namespace App\Actions;

use App\Models\OnlineSurvey;
use App\Models\OnlineSurveyResponse;
use App\Services\ActivityLogService;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class CreateOnlineSurveyResponseAction
{
    protected ActivityLogService $activityLogService;

    public function __construct(ActivityLogService $activityLogService)
    {
        $this->activityLogService = $activityLogService;
    }

    /**
     * Execute the action to create an online survey response.
     *
     * @param  array  $responseData
     * @return \App\Models\OnlineSurveyResponse
     * @throws \Exception
     */
    public function execute(array $responseData): OnlineSurveyResponse
    {
        return DB::transaction(function () use ($responseData) {
            $survey = OnlineSurvey::findOrFail($responseData['online_survey_id']);

            // Anket aktif mi kontrolü
            if (!$survey->isActive()) {
                throw new \Exception('Bu anket aktif değil veya süresi dolmuş.');
            }

            $isAnonymous = $responseData['is_anonymous'] ?? false;

            // Anonim izni kontrolü
            if ($isAnonymous && !$survey->allow_anonymous) {
                throw new \Exception('Bu anket anonim cevap kabul etmiyor.');
            }

            // Duplicate kontrolü (anonim hariç)
            if (!$isAnonymous && $responseData['respondent_id'] ?? Auth::id()) {
                $respondentId = $responseData['respondent_id'] ?? Auth::id();
                if ($survey->hasUserResponded($respondentId)) {
                    throw new \Exception('Bu ankete zaten cevap verdiniz.');
                }
            }

            $response = OnlineSurveyResponse::create([
                'online_survey_id' => $responseData['online_survey_id'],
                'respondent_id' => $isAnonymous ? null : ($responseData['respondent_id'] ?? Auth::id()),
                'respondent_type' => $responseData['respondent_type'] ?? null,
                'answers' => $responseData['answers'],
                'notes' => $responseData['notes'] ?? null,
                'is_anonymous' => $isAnonymous,
                'created_by' => Auth::id(),
            ]);

            // Activity log
            $this->activityLogService->logCreate($response);

            // İlişkileri yükle
            $response->load(['onlineSurvey', 'respondent', 'creator']);

            return $response;
        });
    }
}
