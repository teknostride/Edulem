<?php

namespace App\Jobs;

use App\Models\Student;
use App\Models\Guardian;
use App\Models\User;
use App\Models\Tenant;
use App\Jobs\SendSmsJob;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Carbon\Carbon;

class SendBirthdaySmsJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public $tries = 3;
    public $backoff = 60;

    /**
     * Execute the job.
     */
    public function handle(): void
    {
        try {
            $today = now();
            $day = $today->day;
            $month = $today->month;

            // Tüm aktif tenant'ları al
            $tenants = Tenant::where('is_active', true)->get();

            foreach ($tenants as $tenant) {
                // Tenant'ın SMS gönderim izni var mı kontrol et
                $smsEnabled = DB::table('settings')
                    ->where('tenant_id', $tenant->id)
                    ->where('key', 'sms.enabled')
                    ->where('value', 'true')
                    ->exists();

                if (!$smsEnabled) {
                    continue;
                }

                // Öğrenciler için doğum günü kutlama
                $students = Student::where('tenant_id', $tenant->id)
                    ->where('is_active', true)
                    ->whereNotNull('birth_date')
                    ->whereRaw('DAY(birth_date) = ?', [$day])
                    ->whereRaw('MONTH(birth_date) = ?', [$month])
                    ->with('guardians')
                    ->get();

                foreach ($students as $student) {
                    $guardians = $student->guardians;
                    
                    if ($guardians->isEmpty()) {
                        continue;
                    }

                    $age = $today->diffInYears($student->birth_date);
                    $message = "Sayın Veli, {$student->name} öğrencimizin doğum gününü kutlar, sağlık ve mutluluklar dileriz. Yaş: {$age}";

                    $phones = $guardians->pluck('phone')->filter()->toArray();

                    if (!empty($phones)) {
                        SendSmsJob::dispatch($phones, $message, $tenant->id);
                    }
                }

                // Veli doğum günü kutlama
                $guardians = Guardian::whereHas('students', function ($query) use ($tenant) {
                    $query->where('tenant_id', $tenant->id);
                })
                    ->whereNotNull('birth_date')
                    ->whereRaw('DAY(birth_date) = ?', [$day])
                    ->whereRaw('MONTH(birth_date) = ?', [$month])
                    ->get();

                foreach ($guardians as $guardian) {
                    $age = $today->diffInYears($guardian->birth_date);
                    $message = "Sayın {$guardian->name}, doğum gününüzü kutlar, sağlık ve mutluluklar dileriz. Yaş: {$age}";

                    if ($guardian->phone) {
                        SendSmsJob::dispatch([$guardian->phone], $message, $tenant->id);
                    }
                }

                // Öğretmen doğum günü kutlama
                $teachers = User::where('tenant_id', $tenant->id)
                    ->whereNotNull('birth_date')
                    ->whereRaw('DAY(birth_date) = ?', [$day])
                    ->whereRaw('MONTH(birth_date) = ?', [$month])
                    ->get();

                foreach ($teachers as $teacher) {
                    // Öğretmen telefon numarası yoksa atla (User modelinde phone alanı yok, email kullanılabilir)
                    // Bu durumda SMS gönderilemez, sadece loglama yapılabilir
                    Log::info("Teacher birthday: {$teacher->name} (ID: {$teacher->id})");
                }
            }

            Log::info('Birthday SMS job completed successfully.');
        } catch (\Exception $e) {
            Log::error('Birthday SMS job failed: ' . $e->getMessage());
            throw $e;
        }
    }
}
