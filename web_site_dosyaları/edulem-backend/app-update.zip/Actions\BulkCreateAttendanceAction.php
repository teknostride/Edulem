<?php

namespace App\Actions;

use App\Jobs\SendSmsJob;
use App\Models\Attendance;
use App\Models\Student;
use App\Services\ActivityLogService;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class BulkCreateAttendanceAction
{
    protected ActivityLogService $activityLogService;

    public function __construct(ActivityLogService $activityLogService)
    {
        $this->activityLogService = $activityLogService;
    }

    /**
     * Execute the action to create multiple attendance records.
     *
     * @param  array  $bulkData
     * @return array  ['created' => int, 'attendances' => Collection]
     * @throws \Exception
     */
    public function execute(array $bulkData): array
    {
        return DB::transaction(function () use ($bulkData) {
            $createdAttendances = [];
            $absentStudents = [];

            foreach ($bulkData['attendances'] as $attendanceData) {
                $attendance = Attendance::updateOrCreate(
                    [
                        'tenant_id' => Auth::user()->tenant_id,
                        'student_id' => $attendanceData['student_id'],
                        'schedule_id' => $bulkData['schedule_id'] ?? null,
                        'date' => $bulkData['date'],
                    ],
                    [
                        'teacher_id' => Auth::id(),
                        'status' => $attendanceData['status'],
                        'notes' => $attendanceData['notes'] ?? null,
                    ]
                );

                $createdAttendances[] = $attendance;

                // Devamsızlık durumunda öğrenciyi kaydet
                if ($attendance->status === 'absent') {
                    $absentStudents[] = $attendance;
                }
            }

            // Devamsız öğrenciler için toplu SMS gönder
            if (!empty($absentStudents)) {
                $this->sendBulkAbsenceSms($absentStudents, $bulkData['date']);
            }

            // İlişkileri yükle
            foreach ($createdAttendances as $attendance) {
                $attendance->load(['student', 'schedule' => function ($q) {
                    $q->with('lesson');
                }, 'teacher']);
            }

            return [
                'created' => count($createdAttendances),
                'attendances' => collect($createdAttendances),
            ];
        });
    }

    /**
     * Send bulk SMS to guardians for absent students.
     *
     * @param  array  $absentAttendances
     * @param  string  $date
     * @return void
     */
    protected function sendBulkAbsenceSms(array $absentAttendances, string $date): void
    {
        $tenantId = Auth::user()->tenant_id;
        $smsMessages = [];

        foreach ($absentAttendances as $attendance) {
            $student = $attendance->student()->with('guardians')->first();
            $guardians = $student->guardians;

            if ($guardians->isEmpty()) {
                continue;
            }

            $lessonName = $attendance->schedule?->lesson?->name ?? 'Ders';
            $message = "Sayın Veli, {$student->name} öğrencimiz {$date} tarihinde {$lessonName} dersinde devamsızdır.";

            // Her veliye ayrı SMS gönder
            foreach ($guardians as $guardian) {
                if ($guardian->phone) {
                    SendSmsJob::dispatch($guardian->phone, $message, $tenantId);
                }
            }
        }
    }
}
