<?php

namespace App\Http\Resources;

use App\Http\Resources\LessonResource;
use App\Http\Resources\HomeworkResource;
use App\Http\Resources\StudentResource;
use App\Http\Resources\TutoringSessionAttendanceResource;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class TutoringSessionResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $user = $request->user();

        return [
            'id' => $this->id,
            'type' => $this->type,
            'type_label' => $this->getTypeLabel(),
            'title' => $this->title,
            'date' => $this->date?->format('Y-m-d'),
            'start_time' => $this->start_time?->format('H:i'),
            'end_time' => $this->end_time?->format('H:i'),
            'duration' => $this->duration,
            'room' => $this->room,
            'remote_link' => $this->when($this->hasRemoteLink(), $this->remote_link),
            'max_students' => $this->max_students,
            'available_spots' => $this->getAvailableSpots(),
            'is_full' => $this->isFull(),
            'weekly_max_count' => $this->weekly_max_count,
            'is_active' => $this->is_active,
            'notes' => $this->when($user->hasPermission('tutoring.view_notes') || $user->is_superadmin, $this->notes),
            'teacher' => $this->whenLoaded('teacher', fn() => [
                'id' => $this->teacher->id,
                'name' => $this->teacher->name,
                'email' => $this->teacher->email,
            ]),
            'lesson' => $this->whenLoaded('lesson', fn() => new LessonResource($this->lesson)),
            'homework' => $this->whenLoaded('homework', fn() => new HomeworkResource($this->homework)),
            'students' => StudentResource::collection($this->whenLoaded('students')),
            'students_count' => $this->whenLoaded('students', fn() => $this->students->count()),
            'attendances' => TutoringSessionAttendanceResource::collection($this->whenLoaded('attendances')),
            'creator' => $this->whenLoaded('creator', fn() => [
                'id' => $this->creator->id,
                'name' => $this->creator->name,
                'email' => $this->creator->email,
            ]),
            'created_at' => $this->created_at?->toISOString(),
            'updated_at' => $this->updated_at?->toISOString(),
        ];
    }

    /**
     * Get type label in Turkish.
     *
     * @return string
     */
    protected function getTypeLabel(): string
    {
        return match ($this->type) {
            'tutoring' => 'Etüt',
            'extra_lesson' => 'Ek Ders',
            'private_lesson' => 'Özel Ders',
            'class_tutoring' => 'Sınıf Etüdü',
            'seminar' => 'Seminer',
            default => $this->type,
        };
    }
}
